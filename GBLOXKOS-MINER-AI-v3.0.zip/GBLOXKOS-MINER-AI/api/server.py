import threading
import time

_api_server = None
_lock = threading.Lock()


def _resource_snapshot(orchestrator) -> dict:
    """Return live CPU/RAM/temperature telemetry for the dashboard gauges."""
    snapshot = {
        "cpu_percent": 0.0,
        "memory_percent": 0.0,
        "memory_available_gb": 0.0,
        "temperature": 0.0,
        "swap_percent": 0.0,
        "load_avg": [0, 0, 0],
        "cores_logical": 0,
        "cores_physical": 0,
    }
    if not orchestrator:
        return snapshot
    try:
        profile = orchestrator.get_resource_profile()
        if profile:
            snapshot.update({
                "cpu_percent": round(float(profile.cpu_percent or 0), 2),
                "memory_percent": round(float(profile.memory_percent or 0), 2),
                "memory_available_gb": round(float(profile.memory_available_gb or 0), 2),
                "temperature": round(float(profile.temperature or 0), 1),
                "swap_percent": round(float(profile.swap_percent or 0), 2),
                "load_avg": list(profile.load_avg or (0, 0, 0)),
                "cores_logical": int(profile.cores_logical or 0),
                "cores_physical": int(profile.cores_physical or 0),
            })
            return snapshot
    except Exception:
        pass
    try:
        from ai.analyzer import SystemMonitor
        p = SystemMonitor(interval=0.1).profile()
        snapshot.update({
            "cpu_percent": round(float(p.cpu_percent or 0), 2),
            "memory_percent": round(float(p.memory_percent or 0), 2),
            "memory_available_gb": round(float(p.memory_available_gb or 0), 2),
            "temperature": round(float(p.temperature or 0), 1),
            "swap_percent": round(float(p.swap_percent or 0), 2),
            "load_avg": list(p.load_avg or (0, 0, 0)),
            "cores_logical": int(p.cores_logical or 0),
            "cores_physical": int(p.cores_physical or 0),
        })
    except Exception:
        pass
    return snapshot


class APIServer:
    def __init__(self, orchestrator=None, host: str = "127.0.0.1", port: int = 8765):
        self.orchestrator = orchestrator
        self.host = host
        self.port = port
        self._app = None
        self._server = None
        self._thread = None
        self._running = False

    def start(self):
        try:
            import uvicorn
            from fastapi import FastAPI, HTTPException
            from fastapi.middleware.cors import CORSMiddleware
            from pydantic import BaseModel
        except ImportError:
            raise ImportError("FastAPI / uvicorn not installed. Run: pip install fastapi uvicorn pydantic")

        app = FastAPI(title="GBLOXK OS · MINER AI API", version="3.0.0",
                      description="GBLOXK OS MINER AI — Autonomous AI Mining Operating System REST API")

        app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

        orch = self.orchestrator
        start_time = time.time()

        class ConfigUpdate(BaseModel):
            key: str
            value: object

        class FeedbackCreate(BaseModel):
            content: str
            rating: int = 5

        class WithdrawRequest(BaseModel):
            satoshi: int
            btc_address: str

        class AddressUpdate(BaseModel):
            btc_address: str

        class AutopayUpdate(BaseModel):
            enabled: bool = True
            threshold_satoshi: int = 100000
            btc_address: str = ""

        class SessionStart(BaseModel):
            difficulty: int = 4

        @app.get("/")
        def root():
            return {"name": "GBLOXK OS · MINER AI", "version": "3.0.0", "status": "running"}

        @app.get("/health")
        def health():
            return {"status": "healthy", "uptime": time.time() - start_time}

        @app.get("/api/v1/stats")
        def get_stats():
            if not orch:
                raise HTTPException(404, "Orchestrator not available")
            stats = orch.get_stats()
            stats["resources"] = _resource_snapshot(orch)
            return stats

        @app.get("/api/v1/resources")
        def get_resources():
            if not orch:
                raise HTTPException(404, "Orchestrator not available")
            return _resource_snapshot(orch)

        @app.get("/api/v1/chart")
        def get_chart():
            if not orch:
                raise HTTPException(404, "Orchestrator not available")
            data = orch.get_chart_data()
            return {
                "timestamps": data.get("timestamps", [])[-60:],
                "hashrates": data.get("hashrates", [])[-60:],
                "difficulties": data.get("difficulties", [])[-60:],
                "blocks": data.get("blocks", [])[-60:],
                "cpu_usage": data.get("cpu_usage", [])[-60:],
                "memory_usage": data.get("memory_usage", [])[-60:],
                "temperatures": data.get("temperatures", [])[-60:],
            }

        @app.get("/api/v1/status")
        def get_status():
            if not orch:
                raise HTTPException(404, "Orchestrator not available")
            from mining.orchestrator import OrchestratorState
            return {
                "state": orch.state.value if hasattr(orch.state, 'value') else str(orch.state),
                "mining": orch.state in (OrchestratorState.MINING,),
                "uptime": time.time() - start_time,
            }

        @app.post("/api/v1/start")
        def start_mining(req: SessionStart = SessionStart()):
            if not orch:
                raise HTTPException(404, "Orchestrator not available")
            orch.start()
            return {"status": "started", "difficulty": req.difficulty}

        @app.post("/api/v1/stop")
        def stop_mining():
            if not orch:
                raise HTTPException(404, "Orchestrator not available")
            orch.stop()
            return {"status": "stopped"}

        @app.get("/api/v1/config")
        def get_config():
            if not orch:
                raise HTTPException(404, "Orchestrator not available")
            return orch.config.__dict__ if hasattr(orch.config, '__dict__') else {}

        @app.post("/api/v1/config")
        def update_config(upd: ConfigUpdate):
            if not orch:
                raise HTTPException(404, "Orchestrator not available")
            if hasattr(orch.config, upd.key):
                setattr(orch.config, upd.key, upd.value)
                orch.config.save()
                return {"status": "updated", "key": upd.key, "value": upd.value}
            raise HTTPException(400, f"Unknown config key: {upd.key}")

        @app.get("/api/v1/profitability")
        def get_profitability(hashrate: float = 1000000, power: float = 65, cost: float = 0.12, fee: float = 0.02):
            if not orch:
                raise HTTPException(404, "Orchestrator not available")
            return orch.get_profitability(hashrate, power, cost, fee)

        @app.get("/api/v1/self")
        def get_self_status():
            if not orch:
                raise HTTPException(404, "Orchestrator not available")
            return orch.get_self_status()

        @app.get("/api/v1/ai/ecosystem")
        def get_ai_ecosystem():
            if not orch:
                raise HTTPException(404, "Orchestrator not available")
            return orch.get_ai_ecosystem()

        @app.get("/api/v1/ai/advice")
        def get_ai_advice():
            if not orch:
                raise HTTPException(404, "Orchestrator not available")
            try:
                return {"advice": orch.get_ai_advice()}
            except Exception as e:
                return {"advice": "AI advisor unavailable", "error": str(e)}

        @app.get("/api/v1/blocks")
        def get_blocks():
            if not orch:
                raise HTTPException(404, "Orchestrator not available")
            if orch.db:
                hist = orch.db.get_session_history(orch.user_id) if orch.user_id else []
                return {"blocks": hist}
            return {"blocks": []}

        @app.get("/api/v1/coins")
        def get_coins():
            from mining.coin_switcher import CoinSwitcher
            cs = CoinSwitcher()
            items = cs.get_profitability(1000000)
            return {
                "coins": [
                    {
                        "key": c.coin_key,
                        "name": c.name,
                        "symbol": c.symbol,
                        "algorithm": c.algorithm,
                        "price_usd": c.price_usd,
                        "block_reward": c.block_reward,
                        "block_time_seconds": c.block_time_seconds,
                        "network_hashrate": c.network_hashrate,
                        "daily_revenue_usd": c.daily_revenue_usd,
                        "profitability_score": c.profitability_score,
                    }
                    for c in items
                ]
            }

        @app.get("/api/v1/stratum")
        def get_stratum():
            if not orch:
                raise HTTPException(404, "Orchestrator not available")
            if hasattr(orch, 'stratum_server') and orch.stratum_server:
                return orch.stratum_server.get_stats()
            return {"status": "not_initialized"}

        @app.post("/api/v1/feedback")
        def submit_feedback(fb: FeedbackCreate):
            if not orch or not orch.db:
                raise HTTPException(404, "Database not available")
            uid = orch.user_id or 1
            orch.db.save_feedback(uid, fb.content, fb.rating)
            return {"status": "submitted"}

        @app.get("/api/v1/wallet")
        def get_wallet():
            if not orch or not orch.db:
                raise HTTPException(404, "Database not available")
            uid = orch.user_id or 1
            return orch.db.get_wallet(uid)

        @app.post("/api/v1/wallet/withdraw")
        def withdraw(req: WithdrawRequest):
            if not orch or not orch.db:
                raise HTTPException(404, "Database not available")
            uid = orch.user_id or 1
            from utils.helpers import valid_crypto_address
            if not valid_crypto_address(req.btc_address):
                raise HTTPException(400, "Invalid BTC address")
            success = orch.db.withdraw_wallet(uid, req.satoshi, req.btc_address)
            if not success:
                raise HTTPException(400, "Insufficient balance")
            return {"status": "withdrawal_requested", "satoshi": req.satoshi, "address": req.btc_address}

        @app.get("/api/v1/wallet/address")
        def get_wallet_address():
            if not orch or not orch.db:
                raise HTTPException(404, "Database not available")
            uid = orch.user_id or 1
            w = orch.db.get_wallet(uid)
            return {
                "btc_address": w.get("btc_address"),
                "auto_payout_enabled": bool(w.get("auto_payout_enabled")),
                "payout_threshold_satoshi": w.get("payout_threshold_satoshi", 100000),
                "last_payout_at": w.get("last_payout_at"),
            }

        @app.post("/api/v1/wallet/address")
        def set_wallet_address(req: AddressUpdate):
            if not orch or not orch.db:
                raise HTTPException(404, "Database not available")
            uid = orch.user_id or 1
            from utils.helpers import valid_crypto_address
            if not valid_crypto_address(req.btc_address):
                raise HTTPException(400, "Invalid wallet address format")
            orch.db.set_wallet_address(uid, req.btc_address)
            return {"status": "address_saved", "btc_address": req.btc_address}

        @app.post("/api/v1/wallet/autopay")
        def configure_autopay(req: AutopayUpdate):
            if not orch or not orch.db:
                raise HTTPException(404, "Database not available")
            uid = orch.user_id or 1
            if req.btc_address:
                from utils.helpers import valid_crypto_address
                if not valid_crypto_address(req.btc_address):
                    raise HTTPException(400, "Invalid wallet address format")
                orch.db.set_wallet_address(uid, req.btc_address)
            orch.db.set_auto_payout(uid, req.enabled, req.threshold_satoshi)
            return {
                "status": "autopay_configured",
                "enabled": req.enabled,
                "threshold_satoshi": max(10000, req.threshold_satoshi),
            }

        @app.get("/api/v1/wallet/transactions")
        def wallet_transactions():
            if not orch or not orch.db:
                raise HTTPException(404, "Database not available")
            uid = orch.user_id or 1
            autopay = orch.auto_payout.get_stats() if hasattr(orch, "auto_payout") else {}
            return {
                "withdrawals": orch.db.get_withdrawals(uid),
                "wallet": orch.db.get_wallet(uid),
                "autopay": autopay,
            }

        @app.get("/api/v1/history")
        def get_history():
            if not orch or not orch.db:
                raise HTTPException(404, "Database not available")
            uid = orch.user_id or 1
            return {"sessions": orch.db.get_session_history(uid)}

        self._app = app
        self._running = True
        config = uvicorn.Config(app, host=self.host, port=self.port, log_level="warning")
        self._server = uvicorn.Server(config)
        self._thread = threading.Thread(target=self._server.run, daemon=True, name="api-server")
        self._thread.start()

    def stop(self):
        self._running = False
        if self._server:
            self._server.should_exit = True
            self._server = None

    def is_running(self) -> bool:
        return self._running


def start_api(orchestrator=None, host: str = "127.0.0.1", port: int = 8765) -> APIServer:
    global _api_server
    with _lock:
        if _api_server is None:
            _api_server = APIServer(orchestrator, host, port)
            _api_server.start()
        return _api_server


def stop_api():
    global _api_server
    with _lock:
        if _api_server:
            _api_server.stop()
            _api_server = None
