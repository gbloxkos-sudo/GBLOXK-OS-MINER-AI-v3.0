import json
import os
from dataclasses import dataclass, asdict

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "config.json")


@dataclass
class AppConfig:
    theme: str = "dark"
    color_theme: str = "green"
    default_difficulty: int = 2
    max_nonce: int = 50000
    workers: int = 2
    max_workers: int = 4
    ollama_model: str = "huihui_ai/qwen3-abliterated:1.7b"
    ollama_host: str = "http://localhost:11434"
    db_path: str = os.path.join(os.path.dirname(__file__), "data", "miner.db")
    log_level: str = "INFO"
    auto_save_interval: int = 30
    block_reward: float = 3.125
    auto_tune_ai: bool = True
    enable_notifications: bool = True
    dark_theme_only: bool = True
    low_memory_mode: bool = False
    auto_throttle: bool = True
    air_gapped: bool = False
    real_mining: bool = True
    default_pool: str = "slushpool"
    default_worker: str = "gbloxk_os.1"

    def save(self):
        os.makedirs(os.path.dirname(CONFIG_PATH) or ".", exist_ok=True)
        with open(CONFIG_PATH, "w") as f:
            json.dump(asdict(self), f, indent=2)

    @classmethod
    def load(cls):
        if os.path.exists(CONFIG_PATH):
            with open(CONFIG_PATH) as f:
                data = json.load(f)
            data = {k: v for k, v in data.items() if k in cls.__dataclass_fields__}
            if not cls._usable_db_path(data.get("db_path")):
                data.pop("db_path", None)
            return cls(**data)
        return cls()

    @staticmethod
    def _usable_db_path(path) -> bool:
        if not path or not isinstance(path, str):
            return False
        parent = os.path.dirname(path)
        if not parent:
            return False
        if os.path.isdir(parent):
            return os.access(parent, os.W_OK)
        try:
            os.makedirs(parent, exist_ok=True)
            return True
        except OSError:
            return False
