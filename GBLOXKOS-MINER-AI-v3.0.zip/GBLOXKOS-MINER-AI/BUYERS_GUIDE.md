# GBLOXK OS · MINER AI — Buyer & Investor Guide

## The Autonomous AI Mining Operating System

---

## 1. What It Is

**GBLOXK OS · MINER AI** is a production-grade autonomous mining operating system. It turns any modern CPU into a continuously optimizing SHA-256 mining node that runs itself.

Unlike simulators and static dashboards, GBLOXK OS runs a **living AI layer** — eight cooperating agents that watch the system, learn from it, heal it, and settle your earnings without supervision.

| | |
|---|---|
| **Version** | 3.0 |
| **Language** | Python 3.9+ (backend) · React 18 (dashboard) |
| **License** | MIT |
| **Hardware** | Any x86-64 / ARM64 CPU, 1 core minimum |
| **Network** | Fully air-gap capable after install |
| **Dependencies** | Zero cloud services required |

---

## 2. The Eight AI Agents

Every agent runs continuously in a real background thread — none is cosmetic.

| Agent | Role | What It Actually Does |
|---|---|---|
| **Self-Awareness** | System Consciousness | Maintains baselines, detects anomalies, tracks stability index |
| **Self-Learning** | Pattern Recognition | Records every observation, discovers optimal worker counts and difficulty levels |
| **Self-Healing** | Autonomous Recovery | Detects crashes, zero-hashrate stalls and pressure events, restarts workers automatically |
| **AI Advisor** | Strategy & Reasoning | Local LLM (Ollama) produces on-demand optimization strategy |
| **Pool Analyzer** | Profit Optimization | Scores pools by fee, acceptance rate, payout model and latency; auto-switches |
| **Profitability Engine** | Market Intelligence | Live price feed, revenue, cost and ROI projection |
| **Auto-Payout** | Treasury & Settlement | Automatically sends earned coins to your wallet when threshold is reached |
| **Alert Sentinel** | Anomaly Watch | Watches resource ceilings and raises throttled, de-duplicated alerts |

---

## 3. Core Capabilities

### Real Mining
- Double-SHA256 mining with full block header construction (version, prev-hash, merkle root, ntime, nbits, nonce)
- Stratum V1 **and** V2 — a built-in stratum server accepts external ASIC/GPU miners
- Connects to SlushPool, F2Pool, AntPool, ViaBTC, Poolin, Binance, NiceHash, CKPool
- Share submission, acceptance tracking and wallet auto-credit on every accepted share

### Multi-Coin
Profitability-scored switching across BTC, BCH, BSV, LTC, DASH, DOGE, ZEC using a live CoinGecko price feed.

### Auto-Payout (Treasury)
1. Save any BTC, ETH, LTC, bech32 or base58 wallet address — validated server-side
2. Set a payout threshold
3. When balance crosses the threshold, the treasury agent settles the full balance automatically

```bash
gbloxk-os wallet address --address bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4
gbloxk-os wallet autopay --on --threshold 100000
```

### Intelligence Dashboard
A 7-view enterprise fintech SPA rendered live from the orchestrator:

- **Command Center** — hash rate, blocks, price, profit, AI health, live CPU/RAM/temperature
- **Mining** — engine control, operating profiles, live telemetry, stratum server status
- **AI Ecosystem** — animated neural mesh of all 8 agents, consciousness core, decision log, live activity stream
- **Analytics** — profitability model, revenue projections, multi-coin market intelligence
- **Wallet** — balance, auto-send configuration, manual withdrawal, payout ledger
- **Ledger** — immutable session history with CSV export
- **Settings** — live configuration, applied without restart

### REST API
25 endpoints on FastAPI + Uvicorn with full OpenAPI docs, CORS enabled, and JSON everywhere.

---

## 4. Why It Is Different

| Capability | GBLOXK OS · MINER AI | Typical Miner |
|---|---|---|
| AI layer | 8 cooperating agents, real threads | One static config file |
| Self-repair | Restarts crashed/stalled workers | Crashes and stays crashed |
| Pool selection | Scored by fee/acceptance/latency, auto-switches | Manual selection |
| Payout | Auto-send on threshold + full ledger | Manual withdrawal only |
| Dashboard | Live operating system, 7 views | Static charts |
| AI reasoning | Local Ollama LLM | None |
| Cloud dependency | None | Often required |
| API | 25 documented endpoints | None |

---

## 5. Deployment

### Single command
```bash
pip install -e .
gbloxk-os start
```

### Docker
```bash
docker compose up -d
```

| Service | Port |
|---|---|
| REST API | 8765 |
| Dashboard | 3000 |
| Stratum V1 | 3333 |
| Stratum V2 | 3334 |

### Requirements
- Python 3.9+ (3.11 recommended)
- Node.js 18+ (dashboard only)
- ~150 MB RAM baseline
- Ollama optional (only for LLM reasoning features)

---

## 6. Commercial Positioning

GBLOXK OS is a **complete operating system for autonomous mining**, not a miner script. The value proposition rests on four pillars:

1. **Autonomy** — the system diagnoses, adapts and recovers without operator intervention
2. **Economics** — pool scoring, coin switching and auto-payout maximise realised yield
3. **Observability** — every decision the AI layer makes is visible and auditable in real time
4. **Sovereignty** — runs entirely on your hardware; no cloud account, no telemetry, no keys leave the machine

---

## 7. Roadmap

| Version | Focus |
|---|---|
| 3.0 (current) | Autonomous AI layer · Auto-Payout · Neural mesh dashboard · Stratum V2 |
| 3.1 | GPU-accelerated SHA-256 backend · multi-agent task queue |
| 3.2 | Cross-pool portfolio arbitration · predictive fee optimisation |
| 4.0 | Federated fleet management across multiple nodes |

---

## 8. Support

- **Documentation** — see `README.md` and `USER_GUIDE.md`
- **Issues** — open a ticket on the project tracker
- **Community** — Discord and Telegram links in the repository

---

<div align="center">

**GBLOXK OS · MINER AI v3.0**

*Mine on.*

</div>
