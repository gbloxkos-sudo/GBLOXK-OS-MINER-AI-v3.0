import platform
import re
import psutil


def get_system_info() -> dict:
    return {
        "platform": platform.platform(),
        "python_version": platform.python_version(),
        "cpu_count": psutil.cpu_count(logical=True),
        "cpu_usage": psutil.cpu_percent(interval=0.1),
        "memory_total": psutil.virtual_memory().total,
        "memory_available": psutil.virtual_memory().available,
        "memory_percent": psutil.virtual_memory().percent,
    }


def format_hash_rate(hash_rate: float) -> str:
    for unit in ["H/s", "KH/s", "MH/s", "GH/s", "TH/s"]:
        if hash_rate < 1000:
            return f"{hash_rate:.2f} {unit}"
        hash_rate /= 1000
    return f"{hash_rate:.2f} PH/s"


def format_duration(seconds: float) -> str:
    m, s = divmod(int(seconds), 60)
    h, m = divmod(m, 60)
    if h:
        return f"{h}h {m}m {s}s"
    if m:
        return f"{m}m {s}s"
    return f"{s}s"


# Crypto address patterns: BTC (legacy / P2SH / bech32), generic bech32
# (LTC etc.), ETH/EVM (0x…), and misc base58 chains (LTC legacy, Dash, ZEC).
_ETH_RE = re.compile(r"^0x[a-fA-F0-9]{40}$")
_BTC_RE = re.compile(r"^(bc1|tb1|1|3)[a-zA-Z0-9]{25,62}$")
_BECH32_RE = re.compile(r"^[a-z0-9]{1,6}1[a-z0-9]{20,90}$")
_BASE58_RE = re.compile(r"^[LM3DTZ][a-km-zA-HJ-NP-Z1-9]{25,40}$")


def valid_crypto_address(addr: str) -> bool:
    """Validate a cryptocurrency payout address (BTC-first, other chains allowed)."""
    if not isinstance(addr, str):
        return False
    a = addr.strip()
    if not (20 <= len(a) <= 95):
        return False
    return bool(_ETH_RE.match(a) or _BTC_RE.match(a) or _BECH32_RE.match(a) or _BASE58_RE.match(a))
