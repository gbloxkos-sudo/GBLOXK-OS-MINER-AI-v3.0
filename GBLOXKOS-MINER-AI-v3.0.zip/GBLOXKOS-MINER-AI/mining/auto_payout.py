import time
import threading
from utils.logger import setup_logger

logger = setup_logger(__name__)


class AutoPayoutEngine:
    """Treasury agent that automatically sends earned coins to the configured wallet.

    Runs as a background watchdog: whenever the wallet balance crosses the
    configured threshold (and a valid payout address is set), the full balance
    is queued as an on-chain payout to that address.
    """

    _instance = None
    _instance_lock = threading.Lock()

    @classmethod
    def activate(cls, db, user_id: int, ecosystem=None, interval: float = 20.0):
        """Return (or create) the single running AutoPayoutEngine for this process."""
        with cls._instance_lock:
            if cls._instance and cls._instance._running:
                engine = cls._instance
                engine.db = db
                engine.user_id = user_id
                engine.ecosystem = ecosystem or engine.ecosystem
                return engine
            engine = cls(db, user_id, ecosystem=ecosystem, interval=interval)
            cls._instance = engine
            return engine

    def __init__(self, db, user_id: int, ecosystem=None, interval: float = 20.0):
        self.db = db
        self.user_id = user_id
        self.ecosystem = ecosystem
        self.interval = interval
        self._running = False
        self._thread = None
        self.payouts_sent = 0
        self.last_check = 0.0
        self.last_result = {}

    def start(self):
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True, name="auto-payout")
        self._thread.start()
        logger.info("Auto-Payout Engine activated")
        if self.ecosystem:
            try:
                self.ecosystem.announce("payout", "Auto-Payout Engine activated — watching balance thresholds")
            except Exception:
                pass

    def stop(self):
        self._running = False

    def _loop(self):
        while self._running:
            try:
                self.check_and_payout()
                time.sleep(self.interval)
            except Exception as e:
                logger.error(f"Auto-payout error: {e}")
                time.sleep(self.interval)

    def check_and_payout(self) -> dict:
        """Check the wallet and, if eligible, auto-send the balance to the payout address."""
        self.last_check = time.time()
        wallet = self.db.get_wallet(self.user_id)
        self.last_result = {
            "action": "none",
            "balance_satoshi": int(wallet.get("balance_satoshi") or 0),
            "threshold_satoshi": int(wallet.get("payout_threshold_satoshi") or 100000),
            "auto_payout_enabled": bool(wallet.get("auto_payout_enabled")),
            "btc_address": wallet.get("btc_address"),
        }
        result = self.last_result

        if not result["auto_payout_enabled"]:
            result["reason"] = "auto-payout disabled"
            return result
        address = result["btc_address"]
        if not address:
            result["reason"] = "no payout address configured"
            return result
        if result["balance_satoshi"] < result["threshold_satoshi"]:
            result["reason"] = (
                f"balance {result['balance_satoshi']:,} < threshold {result['threshold_satoshi']:,}"
            )
            return result

        ok = self.db.withdraw_wallet(self.user_id, result["balance_satoshi"], address)
        if not ok:
            result["reason"] = "payout insert failed"
            logger.error("Auto-payout: withdrawal could not be recorded")
            return result

        self.db.mark_withdrawal_completed(self.user_id)
        self.payouts_sent += 1
        result["action"] = "payout"
        result["amount_satoshi"] = result["balance_satoshi"]
        logger.info(
            f"Auto-payout: sent {result['balance_satoshi']:,} sats to {address} "
            f"(payout #{self.payouts_sent})"
        )
        if self.ecosystem:
            try:
                self.ecosystem.record_decision(
                    "payout",
                    f"Auto-payout: {result['balance_satoshi']:,} sats sent",
                    f"Balance crossed threshold {result['threshold_satoshi']:,} — "
                    f"queued on-chain settlement to {address}",
                    "positive",
                )
            except Exception:
                pass
        return result

    def get_stats(self) -> dict:
        wallet = {}
        try:
            wallet = self.db.get_wallet(self.user_id)
        except Exception:
            pass
        return {
            "enabled": bool(wallet.get("auto_payout_enabled")),
            "btc_address": wallet.get("btc_address"),
            "threshold_satoshi": int(wallet.get("payout_threshold_satoshi") or 100000),
            "balance_satoshi": int(wallet.get("balance_satoshi") or 0),
            "payouts_sent": self.payouts_sent,
            "last_payout_at": wallet.get("last_payout_at"),
            "last_check": self.last_check,
            "running": self._running,
        }
