import json
import time
import threading
from typing import Optional
from dataclasses import dataclass


SHA256_COINS = {
    "bitcoin": {
        "name": "Bitcoin",
        "symbol": "BTC",
        "algorithm": "sha256",
        "block_reward": 3.125,
        "block_time_seconds": 600,
        "coingecko_id": "bitcoin",
    },
    "bitcoin_cash": {
        "name": "Bitcoin Cash",
        "symbol": "BCH",
        "algorithm": "sha256",
        "block_reward": 6.25,
        "block_time_seconds": 600,
        "coingecko_id": "bitcoin-cash",
    },
    "bitcoin_sv": {
        "name": "Bitcoin SV",
        "symbol": "BSV",
        "algorithm": "sha256",
        "block_reward": 6.25,
        "block_time_seconds": 600,
        "coingecko_id": "bitcoin-csv",
    },
    "doge": {
        "name": "Dogecoin",
        "symbol": "DOGE",
        "algorithm": "scrypt",
        "block_reward": 10000,
        "block_time_seconds": 60,
        "coingecko_id": "dogecoin",
    },
    "litecoin": {
        "name": "Litecoin",
        "symbol": "LTC",
        "algorithm": "scrypt",
        "block_reward": 6.25,
        "block_time_seconds": 150,
        "coingecko_id": "litecoin",
    },
    "dash": {
        "name": "Dash",
        "symbol": "DASH",
        "algorithm": "x11",
        "block_reward": 2.88,
        "block_time_seconds": 150,
        "coingecko_id": "dash",
    },
    "zcash": {
        "name": "Zcash",
        "symbol": "ZEC",
        "algorithm": "equihash",
        "block_reward": 3.125,
        "block_time_seconds": 75,
        "coingecko_id": "zcash",
    },
}

MINING_ALGORITHMS = {
    "sha256": ["bitcoin", "bitcoin_cash", "bitcoin_sv"],
    "scrypt": ["doge", "litecoin"],
    "x11": ["dash"],
    "equihash": ["zcash"],
}


@dataclass
class CoinProfitability:
    coin_key: str
    name: str
    symbol: str
    algorithm: str
    price_usd: float
    block_reward: float
    block_time_seconds: float
    daily_reward_per_mhs: float
    daily_revenue_usd: float
    network_hashrate: float
    profitability_score: float
    timestamp: float


class CoinSwitcher:
    def __init__(self, supported_algorithm: str = "sha256"):
        self.supported_algorithm = supported_algorithm
        self._cache = {}
        self._cache_time = 0
        self._cache_ttl = 120
        self._lock = threading.Lock()
        self._current_coin = "bitcoin"
        self._auto_switch = False
        self._switch_threshold = 0.05
        self._min_switch_interval = 300
        self._last_switch = 0

    @property
    def current_coin(self) -> str:
        return self._current_coin

    @current_coin.setter
    def current_coin(self, coin_key: str):
        if coin_key in SHA256_COINS:
            self._current_coin = coin_key

    @property
    def auto_switch_enabled(self) -> bool:
        return self._auto_switch

    def enable_auto_switch(self, threshold: float = 0.05, min_interval: int = 300):
        self._auto_switch = True
        self._switch_threshold = threshold
        self._min_switch_interval = min_interval

    def disable_auto_switch(self):
        self._auto_switch = False

    def get_eligible_coins(self) -> list:
        result = []
        for key, info in SHA256_COINS.items():
            if self.supported_algorithm == "all" or info["algorithm"] == self.supported_algorithm:
                result.append({"key": key, **info})
        return result

    def fetch_prices(self) -> dict:
        now = time.time()
        if now - self._cache_time < self._cache_ttl and self._cache:
            return self._cache
        prices = {}
        for coin_key, info in SHA256_COINS.items():
            if self.supported_algorithm != "all" and info["algorithm"] != self.supported_algorithm:
                continue
            coin_id = info["coingecko_id"]
            try:
                import urllib.request
                url = f"https://api.coingecko.com/api/v3/simple/price?ids={coin_id}&vs_currencies=usd"
                resp = urllib.request.urlopen(url, timeout=5)
                data = json.loads(resp.read().decode())
                prices[coin_key] = data.get(coin_id, {}).get("usd", 0)
            except:
                prices[coin_key] = 0
        self._cache = prices
        self._cache_time = now
        return prices

    def get_profitability(self, hashrate_hs: float = 1000000) -> list:
        prices = self.fetch_prices()
        results = []
        for coin_key, info in SHA256_COINS.items():
            if self.supported_algorithm != "all" and info["algorithm"] != self.supported_algorithm:
                continue
            price = prices.get(coin_key, 0)
            reward_per_block = info["block_reward"]
            block_time = info["block_time_seconds"]
            net_hash = max(info.get("network_hashrate_estimate", 6e20) or 6e20, 1)
            blocks_per_day = 86400 / block_time
            our_share = hashrate_hs / net_hash
            daily_coins = our_share * blocks_per_day * reward_per_block
            daily_revenue = daily_coins * price
            profitability_score = daily_revenue / max(hashrate_hs, 1) * 1e12
            results.append(CoinProfitability(
                coin_key=coin_key,
                name=info["name"],
                symbol=info["symbol"],
                algorithm=info["algorithm"],
                price_usd=price,
                block_reward=reward_per_block,
                block_time_seconds=block_time,
                daily_reward_per_mhs=daily_coins,
                daily_revenue_usd=daily_revenue,
                network_hashrate=info.get("network_hashrate_estimate", 0),
                profitability_score=profitability_score,
                timestamp=time.time(),
            ))
        results.sort(key=lambda r: r.profitability_score, reverse=True)
        return results

    def get_best_coin(self, hashrate_hs: float = 1000000) -> Optional[CoinProfitability]:
        results = self.get_profitability(hashrate_hs)
        return results[0] if results else None

    def should_switch(self, hashrate_hs: float = 1000000) -> Optional[str]:
        if not self._auto_switch:
            return None
        now = time.time()
        if now - self._last_switch < self._min_switch_interval:
            return None
        results = self.get_profitability(hashrate_hs)
        if not results:
            return None
        best = results[0]
        current_price_usd = 0
        for r in results:
            if r.coin_key == self._current_coin:
                current_price_usd = r.daily_revenue_usd
                break
        if current_price_usd > 0 and best.daily_revenue_usd > current_price_usd * (1 + self._switch_threshold):
            self._current_coin = best.coin_key
            self._last_switch = now
            return best.coin_key
        return None

    def get_coin_config(self) -> dict:
        info = SHA256_COINS.get(self._current_coin, SHA256_COINS["bitcoin"])
        return {
            "key": self._current_coin,
            **info,
        }
