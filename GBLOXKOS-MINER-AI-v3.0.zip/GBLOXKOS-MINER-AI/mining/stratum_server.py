import socket
import threading
import json
import time
import hashlib


class StratumClient:
    def __init__(self, conn, addr, server):
        self.conn = conn
        self.addr = addr
        self.server = server
        self.subscribed = False
        self.authorized = False
        self.worker_name = None
        self.difficulty = server.difficulty
        self.extra_nonce1 = None
        self.extra_nonce2_size = 4
        self.buffer = b""

    def send(self, msg: dict):
        data = json.dumps(msg) + "\n"
        try:
            self.conn.sendall(data.encode())
        except:
            pass

    def handle(self):
        while True:
            try:
                data = self.conn.recv(4096)
                if not data:
                    break
                self.buffer += data
                while b"\n" in self.buffer:
                    line, self.buffer = self.buffer.split(b"\n", 1)
                    if line.strip():
                        self._process(json.loads(line.decode()))
            except (json.JSONDecodeError, ConnectionResetError, BrokenPipeError, OSError):
                break
        self.server.remove_client(self)

    def _process(self, msg):
        method = msg.get("method", "")
        params = msg.get("params", [])
        msg_id = msg.get("id")

        if method == "mining.subscribe":
            self.subscribed = True
            self.extra_nonce1 = hashlib.md5(str(time.time()).encode()).hexdigest()[:8]
            self.send({
                "id": msg_id,
                "result": [
                    [["mining.set_difficulty", self.extra_nonce1],
                     ["mining.notify", self.extra_nonce1]],
                    self.extra_nonce1,
                    self.extra_nonce2_size
                ],
                "error": None
            })
            self.send({
                "id": None,
                "method": "mining.set_difficulty",
                "params": [self.difficulty]
            })

        elif method == "mining.authorize":
            self.authorized = True
            self.worker_name = params[0] if params else "unknown"
            self.send({"id": msg_id, "result": True, "error": None})
            self.server.on_authorize(self)

        elif method == "mining.submit":
            job_id = params[1] if len(params) > 1 else ""
            extra_nonce2 = params[2] if len(params) > 2 else ""
            ntime = params[3] if len(params) > 3 else ""
            nonce = params[4] if len(params) > 4 else ""
            self.server.on_submit(self, job_id, extra_nonce2, ntime, nonce)

        elif method == "minimining.subscribe":
            self.subscribed = True
            self.send({
                "id": msg_id,
                "result": (True,),
                "error": None
            })

        elif method == "minimining.authorize":
            self.authorized = True
            self.worker_name = params[0] if params else "unknown"
            self.send({"id": msg_id, "result": True, "error": None})
            self.server.on_authorize(self)

        elif method == "minimining.submit":
            job_id = params[0] if len(params) > 0 else ""
            nonce = params[1] if len(params) > 1 else ""
            self.server.on_submit(self, job_id, "", "", nonce)

    def notify(self, job_id: str, prev_hash: str, coinbase1: str, coinbase2: str,
               merkle_branches: list, version: str, nbits: str, ntime: str, clean_jobs: bool):
        if not self.subscribed:
            return
        self.send({
            "id": None,
            "method": "mining.notify",
            "params": [job_id, prev_hash, coinbase1, coinbase2, merkle_branches,
                       version, nbits, ntime, clean_jobs]
        })

    def set_difficulty(self, diff: float):
        self.difficulty = diff
        self.send({
            "id": None,
            "method": "mining.set_difficulty",
            "params": [diff]
        })

    def close(self):
        try:
            self.conn.close()
        except:
            pass


class StratumServer:
    def __init__(self, host: str = "0.0.0.0", port: int = 3333, difficulty: float = 1):
        self.host = host
        self.port = port
        self.difficulty = difficulty
        self.clients = []
        self._lock = threading.Lock()
        self._server_sock = None
        self._running = False
        self._thread = None
        self.on_share_callback = None
        self._current_job_id = 0

    def start(self):
        self._server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._server_sock.bind((self.host, self.port))
        self._server_sock.listen(128)
        self._server_sock.settimeout(1.0)
        self._running = True
        self._thread = threading.Thread(target=self._accept_loop, daemon=True, name="stratum-accept")
        self._thread.start()

    def stop(self):
        self._running = False
        with self._lock:
            for c in self.clients[:]:
                c.close()
            self.clients.clear()
        if self._server_sock:
            try:
                self._server_sock.close()
            except:
                pass

    @property
    def active_clients(self) -> int:
        with self._lock:
            return len(self.clients)

    def _accept_loop(self):
        while self._running:
            try:
                conn, addr = self._server_sock.accept()
                client = StratumClient(conn, addr, self)
                with self._lock:
                    self.clients.append(client)
                t = threading.Thread(target=client.handle, daemon=True, name=f"stratum-client-{addr[0]}")
                t.start()
            except socket.timeout:
                continue
            except OSError:
                break

    def remove_client(self, client):
        with self._lock:
            if client in self.clients:
                self.clients.remove(client)

    def on_authorize(self, client):
        pass

    def on_submit(self, client, job_id: str, extra_nonce2: str, ntime: str, nonce: str):
        if self.on_share_callback:
            self.on_share_callback(client.worker_name or str(client.addr), nonce, job_id)

    def broadcast_job(self, job_id: str, prev_hash: str, coinbase1: str, coinbase2: str,
                      merkle_branches: list, version: str, nbits: str, ntime: str, clean_jobs: bool = True):
        with self._lock:
            for c in self.clients:
                c.notify(job_id, prev_hash, coinbase1, coinbase2, merkle_branches,
                         version, nbits, ntime, clean_jobs)

    def broadcast_difficulty(self, diff: float):
        with self._lock:
            for c in self.clients:
                c.set_difficulty(diff)

    def get_stats(self) -> dict:
        with self._lock:
            return {
                "host": self.host,
                "port": self.port,
                "active_clients": len(self.clients),
                "difficulty": self.difficulty,
                "clients": [{"addr": str(c.addr), "worker": c.worker_name,
                             "subscribed": c.subscribed, "authorized": c.authorized}
                            for c in self.clients]
            }


class StratumV2Server(StratumServer):
    def __init__(self, host: str = "0.0.0.0", port: int = 3334, difficulty: float = 1):
        super().__init__(host, port, difficulty)

    def on_submit(self, client, job_id: str, extra_nonce2: str, ntime: str, nonce: str):
        if self.on_share_callback:
            self.on_share_callback(client.worker_name or str(client.addr), nonce, job_id)
