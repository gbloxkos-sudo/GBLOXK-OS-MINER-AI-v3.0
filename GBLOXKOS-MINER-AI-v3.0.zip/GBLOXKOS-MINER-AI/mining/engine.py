from hashlib import sha256
import time
import logging
from typing import Optional
from multiprocessing import Process, Queue, cpu_count, Value
import ctypes

logger = logging.getLogger(__name__)


def sha256_hash(text: str) -> str:
    return sha256(text.encode("ascii")).hexdigest()


def mine_range(block_number: int, transactions: str, previous_hash: str,
               difficulty: int, start_nonce: int, end_nonce: int,
               result_queue: Queue, stop_flag):
    try:
        prefix = "0" * difficulty
        for nonce in range(start_nonce, end_nonce):
            if stop_flag.value:
                return
            text = f"{block_number}{transactions}{previous_hash}{nonce}"
            h = sha256_hash(text)
            if h.startswith(prefix):
                result_queue.put((nonce, h))
                return
    except Exception as e:
        logger.error(f"Miner process error: {e}")


class MiningEngine:
    def __init__(self, workers: int = None):
        self.workers = max(1, workers or max(1, cpu_count() - 1))
        self._stop_flag = None
        self._result_queue = None

    def mine_block(self, block_number: int, transactions: str,
                   previous_hash: str, difficulty: int,
                   max_nonce: int = 100000, timeout: float = 300) -> Optional[tuple[int, str]]:
        if max_nonce < 1:
            max_nonce = 100000
        if difficulty < 1:
            difficulty = 1
        if timeout < 1:
            timeout = 300

        self._stop_flag = Value(ctypes.c_bool, False)
        self._result_queue = Queue()

        chunk = max(1, max_nonce // self.workers)
        processes = []
        try:
            for i in range(self.workers):
                start = i * chunk
                end = max_nonce if i == self.workers - 1 else (i + 1) * chunk
                if start >= end:
                    continue
                p = Process(
                    target=mine_range,
                    args=(block_number, transactions, previous_hash,
                          difficulty, start, end, self._result_queue, self._stop_flag),
                )
                p.daemon = True
                p.start()
                processes.append(p)

            result = None
            start_time = time.time()
            while time.time() - start_time < timeout:
                try:
                    nonce, h = self._result_queue.get(timeout=0.1)
                    result = (nonce, h)
                    break
                except Exception:
                    continue

            self._stop_flag.value = True
            for p in processes:
                try:
                    if p.is_alive():
                        p.terminate()
                        p.join(timeout=2)
                except Exception:
                    pass
        except Exception as e:
            logger.error(f"Mining engine error: {e}")
            self._stop_flag.value = True
            for p in processes:
                try:
                    if p.is_alive():
                        p.terminate()
                        p.join(timeout=1)
                except Exception:
                    pass

        return result

    def stop(self):
        if self._stop_flag is not None:
            try:
                self._stop_flag.value = True
            except Exception:
                pass
