import time
import threading
from mining.engine import MiningEngine
from mining.blockchain import Blockchain
from config import AppConfig


class MiningWorker(threading.Thread):
    def __init__(self, config: AppConfig, blockchain: Blockchain,
                 on_block_found=None, on_status=None):
        super().__init__(daemon=True)
        self.config = config
        self.blockchain = blockchain
        self.on_block_found = on_block_found
        self.on_status = on_status
        self.running = False
        self.paused = False
        self.engine = MiningEngine(workers=config.workers)
        self.stats = {
            "total_hashes": 0,
            "blocks_found": 0,
            "start_time": None,
            "hash_rate": 0.0,
            "current_difficulty": config.default_difficulty,
        }

    def run(self):
        self.running = True
        self.stats["start_time"] = time.time()
        txn_counter = 0

        while self.running:
            if self.paused:
                time.sleep(0.5)
                continue

            txn_counter += 1
            transactions = f"tx_{txn_counter}:miner->pool->reward"

            block = self.blockchain.add_block(
                transactions, max_nonce=self.config.max_nonce
            )

            self.stats["total_hashes"] += self.config.max_nonce
            elapsed = time.time() - self.stats["start_time"]
            self.stats["hash_rate"] = self.stats["total_hashes"] / elapsed if elapsed > 0 else 0

            if block:
                self.stats["blocks_found"] += 1
                if self.on_block_found:
                    self.on_block_found(block)
            else:
                if self.on_status:
                    self.on_status("Mining round completed - no block found")

            if self.on_status:
                self.on_status(f"Mining... hash rate: {self.stats['hash_rate']:.0f} H/s")

            if self.config.auto_tune_ai:
                difficulty = max(1, min(8, int(self.stats["hash_rate"] / 1000)))
                self.blockchain.difficulty = difficulty
                self.stats["current_difficulty"] = difficulty

    def stop(self):
        self.running = False
        self.engine.stop()

    def pause(self):
        self.paused = True

    def resume(self):
        self.paused = False

    def get_stats(self) -> dict:
        return {**self.stats}
