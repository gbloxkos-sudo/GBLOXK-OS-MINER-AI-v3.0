import time
import threading
from typing import Optional, Callable
from mining.worker import MiningWorker
from mining.blockchain import Blockchain
from ai.advisor import AIAdvisor
from ai.analyzer import SystemMonitor, ResourceProfile
from ai.profitability import ProfitabilityCalculator, fetch_btc_price
from ai.stratum import StratumV2Simulator
from ai.alerts import AlertManager
from ai.self_healing import SelfHealingEngine
from ai.self_learning import SelfLearningEngine
from ai.self_aware import SelfAwarenessEngine
from ai.ecosystem import AIEcosystem
from ai.pool_analyzer import PoolAnalyzer
from mining.auto_payout import AutoPayoutEngine
from database.storage import DatabaseManager
from config import AppConfig
from utils.logger import setup_logger

logger = setup_logger(__name__)


class OrchestratorState:
    STOPPED = "stopped"
    MINING = "mining"
    PAUSED = "paused"


class MiningOrchestrator:
    def __init__(self, config: AppConfig, db: DatabaseManager, user_id: int):
        self.config = config
        self.db = db
        self.user_id = user_id
        self.state = OrchestratorState.STOPPED
        self.blockchain = Blockchain(difficulty=config.default_difficulty)
        self.ai = AIAdvisor(config)
        self.monitor = SystemMonitor()
        self.profitability = ProfitabilityCalculator(config)
        self.stratum = StratumV2Simulator(config.default_difficulty)
        self.alerts = AlertManager()
        self.learning = SelfLearningEngine(config)
        self.healing = SelfHealingEngine(config, self.alerts)
        self.awareness = SelfAwarenessEngine(config, self.learning, self.alerts)
        self.pool_analyzer = PoolAnalyzer(config)
        self.ecosystem = AIEcosystem(self)
        self.auto_payout = AutoPayoutEngine.activate(self.db, self.user_id, ecosystem=self.ecosystem)
        self.auto_payout.start()
        self.worker: Optional[MiningWorker] = None
        self.session_id: Optional[int] = None
        self._resource_profile: Optional[ResourceProfile] = None
        self._stats_history: list = []
        self._chart_data: dict = {
            "timestamps": [], "hashrates": [], "difficulties": [],
            "blocks": [], "cpu_usage": [], "memory_usage": [], "temperatures": [],
        }
        self._callbacks = {
            "on_block": None, "on_status": None, "on_stats": None,
            "on_resource": None, "on_alert": None, "on_chart_data": None,
        }
        self._coin_switcher = None
        self._pool_client = None
        self._stratum_server = None
        self._api_server = None
        self.pool_real_miner = None

        self.healing.on_restart(self._restart_worker)
        # Telemetry runs continuously (even when idle) so the AI engines always
        # have live observations, real resource telemetry and chart history.
        self._telemetry_thread = threading.Thread(
            target=self._telemetry_loop, daemon=True, name="telemetry"
        )
        self._telemetry_thread.start()

    def set_callback(self, name: str, cb: Callable):
        self._callbacks[name] = cb

    def start(self):
        if self.state == OrchestratorState.MINING:
            return
        if self.config.real_mining:
            self._start_real_mining()
        else:
            self.start_mining()

    def _start_real_mining(self):
        if self.state == OrchestratorState.MINING:
            return
        from ai.auto_real_miner import AutoRealMiner
        from mining.pool_client import KNOWN_POOLS
        pool_name = self.config.default_pool
        host = KNOWN_POOLS.get(pool_name, {}).get("host", pool_name)
        port = KNOWN_POOLS.get(pool_name, {}).get("port", 3333)
        worker = self.config.default_worker

        self.pool_real_miner = AutoRealMiner(self.config, self.db, self.user_id)
        self.session_id = self.db.create_session(self.user_id, self.config.default_difficulty)

        success = self.pool_real_miner.start(pool_name, host, port, worker)
        if success:
            self.state = OrchestratorState.MINING
            logger.info(f"Real mining started: {pool_name} as {worker}")
        else:
            logger.warning("Real mining failed, falling back to solo mode")
            self.pool_real_miner = None
            self.start_mining()

    def start_mining(self):
        if self.worker and self.worker.running:
            return
        self.session_id = self.db.create_session(self.user_id, self.config.default_difficulty)
        self.blockchain = Blockchain(difficulty=self.config.default_difficulty)

        self.worker = MiningWorker(
            config=self.config,
            blockchain=self.blockchain,
            on_block_found=self._on_block_found,
            on_status=self._on_status,
        )
        self.worker.start()
        self.healing.register_worker(self.worker)
        self.healing.start()

        self.alerts.on_alert = self._on_alert
        self.state = OrchestratorState.MINING

        if self.config.auto_tune_ai:
            logger.info("AI Auto-Mining: enabled | Self-Healing: active | Self-Learning: active | Self-Awareness: active")

    def _restart_worker(self):
        if self.worker:
            self.worker.stop()
            time.sleep(0.5)
        self.blockchain = Blockchain(difficulty=self.config.default_difficulty)
        self.worker = MiningWorker(
            config=self.config,
            blockchain=self.blockchain,
            on_block_found=self._on_block_found,
            on_status=self._on_status,
        )
        self.worker.start()
        self.healing.register_worker(self.worker)
        logger.info("Worker restarted by self-healing engine")

    def stop(self):
        if self.pool_real_miner and self.pool_real_miner._running:
            self.pool_real_miner.stop()
            self.pool_real_miner = None
        self.stop_mining()

    def stop_mining(self):
        if self.worker:
            self.worker.stop()
            self.worker = None
        if self.session_id:
            stats = self.get_stats()
            self.db.end_session(self.session_id, stats)
            self.session_id = None
        self.state = OrchestratorState.STOPPED
        logger.info("Mining stopped")

    def pause_mining(self):
        if self.worker:
            self.worker.pause()

    def resume_mining(self):
        if self.worker:
            self.worker.resume()

    def _on_block_found(self, block):
        logger.info(f"Block found: #{block.index} hash={block.hash[:16]}...")
        if self.session_id:
            self.db.save_block(self.session_id, block.to_dict(), self.config.block_reward)
        self.stratum.create_job(block.transactions, block.previous_hash)
        self.ecosystem.record_decision(
            "awareness",
            f"Block #{block.index} mined",
            f"Nonce {block.nonce} produced a valid hash at difficulty {block.difficulty}",
            "positive",
        )
        if self._callbacks["on_block"]:
            self._callbacks["on_block"](block)

    def _on_status(self, status: str):
        if self._callbacks["on_status"]:
            self._callbacks["on_status"](status)

    def _on_alert(self, alert):
        try:
            self.ecosystem.announce("alerts", alert.message, alert.severity)
        except Exception:
            pass
        if self._callbacks["on_alert"]:
            self._callbacks["on_alert"](alert)

    def _telemetry_loop(self):
        """Continuous telemetry + AI observation loop.

        Runs for the whole lifetime of the orchestrator (mining or not) so the
        self-awareness, self-learning and alerting engines always operate on
        real data instead of stalling with "unknown" state.
        """
        while True:
            try:
                profile = self.monitor.profile()
                self._resource_profile = profile
                stats = self.get_stats()

                self.awareness.observe(profile,
                                       stats.get("hash_rate", 0),
                                       stats.get("blocks_found", 0))
                self.learning.record_observation(
                    hash_rate=stats.get("hash_rate", 0),
                    difficulty=self.blockchain.difficulty,
                    workers=self.worker.engine.workers if self.worker else self.config.workers,
                    cpu_usage=profile.cpu_percent,
                    memory_usage=profile.memory_percent,
                    temperature=profile.temperature or 0,
                    blocks_found=stats.get("blocks_found", 0),
                    mode="auto",
                )

                if self._callbacks["on_resource"]:
                    self._callbacks["on_resource"](profile)
                if self._callbacks["on_stats"]:
                    self._callbacks["on_stats"](stats)

                self.alerts.check(profile, stats)
                self._update_chart_data(stats, profile)

                if self.config.auto_tune_ai and self.worker and self.worker.running:
                    self._auto_tune()

                time.sleep(1)
            except Exception as e:
                logger.error(f"Telemetry error: {e}")
                time.sleep(5)

    def _auto_tune(self):
        profile = self._resource_profile
        worker = self.worker

        optimal_workers = self.learning.get_optimal_workers("auto")
        optimal_diff = self.learning.get_optimal_difficulty("auto")

        recommended_workers = self.monitor.recommended_workers(profile)
        recommended_diff = self.monitor.optimal_difficulty(profile)

        if optimal_workers:
            recommended_workers = min(recommended_workers, optimal_workers)
        if optimal_diff:
            recommended_diff = optimal_diff

        cpu = profile.cpu_percent
        mem = profile.memory_percent
        temp = profile.temperature or 0

        if cpu > 80 or mem > 85 or temp > 75:
            recommended_workers = max(1, recommended_workers // 2)
            recommended_diff = max(1, recommended_diff - 1)
        if temp > 80:
            recommended_workers = 1
            recommended_diff = 1
            self._on_status("🔥 CRITICAL: Temperature too high - minimum mining")

        if cpu < 30 and mem < 50 and temp < 60:
            recommended_workers = min(profile.cores_logical, recommended_workers + 1)

        worker.engine.workers = max(1, min(recommended_workers, profile.cores_logical))
        self.blockchain.difficulty = max(1, min(8, recommended_diff))
        self.worker.stats["current_difficulty"] = self.blockchain.difficulty
        self.stratum.difficulty = self.blockchain.difficulty

    def _update_chart_data(self, stats: dict, profile: ResourceProfile):
        d = self._chart_data
        d["timestamps"].append(time.time())
        d["hashrates"].append(stats.get("hash_rate", 0))
        d["difficulties"].append(stats.get("current_difficulty", 4))
        d["blocks"].append(stats.get("blocks_found", 0))
        d["cpu_usage"].append(profile.cpu_percent if profile else 0)
        d["memory_usage"].append(profile.memory_percent if profile else 0)
        d["temperatures"].append(profile.temperature if profile and profile.temperature else 0)

        for key in d:
            if len(d[key]) > 300:
                d[key] = d[key][-300:]

        if self._callbacks["on_chart_data"]:
            self._callbacks["on_chart_data"](d)

    def get_stats(self) -> dict:
        base = {
            "blocks_found": 0,
            "total_hashes": 0,
            "hash_rate": 0.0,
            "current_difficulty": self.blockchain.difficulty,
            "chain_length": len(self.blockchain.chain),
            "elapsed": 0,
            "acceptance_rate": 100.0,
            "btc_price": fetch_btc_price(),
            "state": self.state,
        }

        if self.pool_real_miner and self.pool_real_miner._running:
            ps = self.pool_real_miner.get_stats()
            base["hash_rate"] = ps.get("hashrate", 0)
            base["blocks_found"] = ps.get("shares_accepted", 0)
            base["total_shares"] = ps.get("shares_found", 0)
            base["elapsed"] = ps.get("uptime", 0)
            base["pool"] = ps.get("pool", "unknown")
            base["worker"] = ps.get("worker", "unknown")
            base["earnings_satoshi"] = ps.get("estimated_earnings_satoshi", 0)
        elif self.worker:
            ws = self.worker.get_stats()
            base.update(ws)
            if ws.get("start_time"):
                base["elapsed"] = time.time() - ws["start_time"]

        stratum_stats = self.stratum.get_stats()
        base["acceptance_rate"] = stratum_stats["acceptance_rate"]
        base["total_shares"] = base.get("total_shares", 0) or stratum_stats["total_shares"]

        return base

    def get_chart_data(self) -> dict:
        return self._chart_data

    def get_resource_profile(self) -> Optional[ResourceProfile]:
        return self._resource_profile

    def ai_analyze(self) -> str:
        stats = self.get_stats()
        profile = self._resource_profile
        if profile:
            stats["cpu_usage"] = profile.cpu_percent
            stats["memory_usage"] = profile.memory_percent
            stats["temperature"] = profile.temperature

        awareness_insight = self.awareness.get_consciousness_report()
        learning_insight = self.learning.get_insights()
        healing_stats = self.healing.get_stats()

        prompt = (
            "Analyze this Bitcoin mining telemetry and provide concise, actionable optimization advice.\n\n"
            f"Mining Stats: {stats}\n\n"
            f"Self-Awareness Report:\n{awareness_insight}\n\n"
            f"Learning Insights:\n{learning_insight}\n\n"
            f"Incidents Handled: {healing_stats['total_incidents']}"
        )
        base = self.ai.chat(prompt)
        return (f"{base}\n\n🧠 Self-Aware: {self.awareness.state.overall_health}\n"
                f"📚 Learned: {learning_insight}")

    def ai_chat(self, message: str) -> str:
        return self.ai.chat(message)

    def get_profitability(self, hash_rate: float = 0, power_watts: float = 0, electricity_cost: float = 0, pool_fee: float = 0) -> dict:
        stats = self.get_stats()
        hr = hash_rate or stats.get("hash_rate", 1000000)
        pw = power_watts or (self._resource_profile.cores_logical * 15 if self._resource_profile else 65)
        ec = electricity_cost or 0.12
        pf = pool_fee or 0.02
        return self.profitability.calculate(hash_rate=hr, power_watts=pw, electricity_cost=ec, pool_fee=pf)

    def get_self_status(self) -> dict:
        return {
            "healing": self.healing.get_stats(),
            "learning": self.learning.get_stats(),
            "awareness": self.awareness.get_stats(),
            "consciousness": self.awareness.get_consciousness_report(),
        }

    def get_ai_ecosystem(self) -> dict:
        try:
            return self.ecosystem.snapshot()
        except Exception as e:
            logger.error(f"Ecosystem snapshot error: {e}")
            return {"agents": [], "nodes": [], "edges": [], "events": [],
                    "decisions": [], "consciousness": {}, "metrics": {}, "error": str(e)}

    def get_ai_advice(self) -> str:
        try:
            result = []
            thread = threading.Thread(target=lambda: result.append(self.ai_analyze()), daemon=True)
            thread.start()
            thread.join(timeout=5)
            if result:
                return result[0]
            return "AI Advisor is currently unavailable (timeout). The system continues to operate autonomously with self-healing, self-learning, and self-awareness engines running in the background."
        except Exception as e:
            return f"AI Advisor unavailable: {e}. Autonomous systems still active."

    def get_session_history(self) -> list:
        return self.db.get_session_history(self.user_id)
