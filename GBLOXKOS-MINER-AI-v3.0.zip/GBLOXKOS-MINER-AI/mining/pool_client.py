import socket
import json
import threading
from typing import Optional


KNOWN_POOLS = {
    "slushpool": {"host": "stratum.slushpool.com", "port": 3333, "type": "stratum"},
    "f2pool": {"host": "btc.f2pool.com", "port": 1314, "type": "stratum"},
    "antpool": {"host": "stratum.antpool.com", "port": 3333, "type": "stratum"},
    "viabtc": {"host": "stratum.viabtc.com", "port": 3333, "type": "stratum"},
    "poolin": {"host": "stratum.poolin.com", "port": 3333, "type": "stratum"},
    "binance_pool": {"host": "stratum.binance.com", "port": 3333, "type": "stratum"},
    "nicehash": {"host": "stratum+tcp://daggerhashimoto.usa.nicehash.com", "port": 3353, "type": "stratum"},
    "ckpool": {"host": "ckpool.org", "port": 3333, "type": "stratum"},
}


class PoolClient:
    def __init__(self, host: str, port: int, worker: str, password: str = "x"):
        self.host = host
        self.port = port
        self.worker = worker
        self.password = password
        self._sock = None
        self._running = False
        self._thread = None
        self._lock = threading.Lock()
        self._current_job = None
        self._buffer = b""
        self._msg_id = 0
        self._extra_nonce1 = None
        self._extra_nonce2_size = 4
        self._subscribed = False
        self._authorized = False
        self.shares_found = 0
        self.shares_accepted = 0
        self.earned_satoshi = 0

        self.on_job = None
        self.on_difficulty = None
        self.on_set_target = None
        self.disconnected_callback = None

    def connect(self) -> bool:
        try:
            self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._sock.settimeout(10)
            self._sock.connect((self.host, self.port))
            self._sock.settimeout(None)
            self._msg_id = 0
            self._buffer = b""
            self._subscribed = False
            self._authorized = False
            self.subscribe()
            self.authorize()
            self._running = True
            self._thread = threading.Thread(target=self._recv_loop, daemon=True)
            self._thread.start()
            return True
        except (socket.timeout, ConnectionRefusedError, OSError) as e:
            if self.disconnected_callback:
                self.disconnected_callback(str(e))
            return False

    def disconnect(self):
        self._running = False
        try:
            if self._sock:
                self._sock.close()
        except:
            pass

    @property
    def connected(self) -> bool:
        return self._running and self._sock is not None

    def subscribe(self):
        self._msg_id += 1
        self._send({
            "id": self._msg_id,
            "method": "mining.subscribe",
            "params": ["gbloxk-os-miner/3.0.0"]
        })

    def authorize(self):
        self._msg_id += 1
        self._send({
            "id": self._msg_id,
            "method": "mining.authorize",
            "params": [self.worker, self.password]
        })

    def submit(self, job_id: str, extra_nonce2: str, ntime: str, nonce: str):
        self._msg_id += 1
        self._send({
            "id": self._msg_id,
            "method": "mining.submit",
            "params": [self.worker, job_id, extra_nonce2, ntime, nonce]
        })

    def submit_hash(self, job_id: str, nonce: str):
        self._msg_id += 1
        self._send({
            "id": self._msg_id,
            "method": "mining.submit",
            "params": [self.worker, job_id, "00000000", "00000000", nonce]
        })

    def _send(self, msg: dict):
        data = json.dumps(msg) + "\n"
        try:
            with self._lock:
                if self._sock:
                    self._sock.sendall(data.encode())
        except:
            pass

    def _recv_loop(self):
        while self._running:
            try:
                data = self._sock.recv(65536)
                if not data:
                    break
                self._buffer += data
                while b"\n" in self._buffer:
                    line, self._buffer = self._buffer.split(b"\n", 1)
                    if line.strip():
                        self._handle_message(json.loads(line.decode()))
            except (json.JSONDecodeError, ConnectionResetError, BrokenPipeError, OSError):
                break
        self._running = False
        if self.disconnected_callback:
            self.disconnected_callback("Connection lost")

    def _handle_message(self, msg: dict):
        method = msg.get("method")
        params = msg.get("params", [])

        if method == "mining.notify":
            job_id = params[0]
            prev_hash = params[1]
            coinbase1 = params[2]
            coinbase2 = params[3]
            merkle_branches = params[4] if len(params) > 4 else []
            version = params[5] if len(params) > 5 else ""
            nbits = params[6] if len(params) > 6 else ""
            ntime = params[7] if len(params) > 7 else ""
            clean_jobs = params[8] if len(params) > 8 else True
            self._current_job = {
                "job_id": job_id, "prev_hash": prev_hash,
                "coinbase1": coinbase1, "coinbase2": coinbase2,
                "merkle_branches": merkle_branches,
                "version": version, "nbits": nbits, "ntime": ntime,
                "clean_jobs": clean_jobs,
            }
            if self.on_job:
                try:
                    from mining.real_miner import PoolJob
                    pj = PoolJob(job_id, prev_hash, coinbase1, coinbase2,
                                 merkle_branches, version, nbits, ntime, clean_jobs)
                    self.on_job(pj)
                except Exception:
                    self.on_job(self._current_job)

        elif method == "mining.set_difficulty":
            difficulty = params[0] if params else 1
            if self.on_difficulty:
                self.on_difficulty(difficulty)

        elif method == "mining.set_target":
            target = params[0] if params else ""
            if self.on_set_target:
                self.on_set_target(target)

        elif "result" in msg:
            if msg.get("id") == 2:
                self._subscribed = True
            elif msg.get("id") == 3:
                self._authorized = msg["result"] is True

    @property
    def current_job(self) -> Optional[dict]:
        return self._current_job

    @property
    def is_authorized(self) -> bool:
        return self._authorized
