import time
import threading
from typing import Optional
from mining.pool_client import PoolClient, KNOWN_POOLS
from mining.real_miner import RealMiner, PoolJob
from database.storage import DatabaseManager
from config import AppConfig
from utils.logger import setup_logger

logger = setup_logger(__name__)


class PoolMiner:
    def __init__(self, config: AppConfig, db: DatabaseManager, user_id: int):
        self.config = config
        self.db = db
        self.user_id = user_id
        self.pool_client: Optional[PoolClient] = None
        self.real_miner: Optional[RealMiner] = None
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()
        self.shares_found = 0
        self.shares_accepted = 0
        self.shares_rejected = 0
        self.estimated_earnings_satoshi = 0
        self.pool_url = ""
        self.worker_name = ""
        self.start_time = 0
        self.on_share = None
        self.on_status = None
        self.on_earnings = None
        self._reconnect_delay = 5

    @property
    def running(self) -> bool:
        return self._running

    @property
    def hashrate(self) -> float:
        return self.real_miner.hashrate if self.real_miner else 0.0

    @property
    def uptime(self) -> float:
        return time.time() - self.start_time if self.start_time > 0 else 0

    def start(self, pool_name: str = "", host: str = "", port: int = 3333,
              worker: str = "miner1", password: str = "x") -> bool:
        if self._running:
            return False

        if pool_name and pool_name in KNOWN_POOLS:
            host = KNOWN_POOLS[pool_name]["host"]
            port = KNOWN_POOLS[pool_name]["port"]
        elif not host:
            return False

        self.pool_url = f"{host}:{port}"
        self.worker_name = worker

        self.real_miner = RealMiner(workers=self.config.workers)
        self.pool_client = PoolClient(host, port, worker, password)

        def on_job(job):
            if isinstance(job, PoolJob):
                self.real_miner.set_job(job)

        def on_share_found(job_id: str, nonce: str, ntime: int):
            with self._lock:
                self.shares_found += 1
            if self.pool_client and not job_id.startswith("solo_"):
                self.pool_client.submit_hash(job_id, nonce)
            earned = self._estimate_share_value()
            with self._lock:
                self.shares_accepted += 1
                self.estimated_earnings_satoshi += earned
                if self.db:
                    self.db.credit_wallet(self.user_id, earned)
            logger.info(f"Share found! Job: {job_id[:16]} Nonce: {nonce}")
            if self.on_share:
                self.on_share(job_id, nonce, earned)
            if self.on_earnings:
                self.on_earnings(self.estimated_earnings_satoshi)

        self.pool_client.on_job = on_job
        self.real_miner.on_share_found = on_share_found

        def on_disconnect(reason):
            logger.warning(f"Pool disconnected: {reason}")
            if self._running:
                logger.info(f"Reconnecting in {self._reconnect_delay}s...")
                time.sleep(self._reconnect_delay)
                if self._running:
                    self._try_reconnect()

        self.pool_client.disconnected_callback = on_disconnect

        if not self.pool_client.connect():
            logger.error(f"Failed to connect to pool {host}:{port}")
            return False

        if self.on_status:
            self.on_status(f"Connected to {host}:{port} as {worker}")

        self.real_miner.start()
        self._running = True
        self.start_time = time.time()
        logger.info(f"Pool mining started: {host}:{port} worker={worker}")
        return True

    def _try_reconnect(self):
        if not self._running:
            return
        try:
            if self.pool_client:
                self.pool_client.disconnect()
            if self.real_miner:
                self.real_miner.stop()
            host, port_str = self.pool_url.split(":")
            port = int(port_str)
            self.pool_client = PoolClient(host, port, self.worker_name, "x")

            def on_job(job):
                if isinstance(job, PoolJob):
                    self.real_miner.set_job(job)
            self.pool_client.on_job = on_job
            self.pool_client.disconnected_callback = \
                lambda r: self._try_reconnect() if self._running else None

            if self.pool_client.connect():
                self.real_miner.start()
                logger.info(f"Reconnected to {self.pool_url}")
                if self.on_status:
                    self.on_status(f"Reconnected to {self.pool_url}")
            else:
                logger.warning(f"Reconnect failed, retrying in {self._reconnect_delay}s...")
                time.sleep(self._reconnect_delay)
                if self._running:
                    self._try_reconnect()
        except Exception as e:
            logger.error(f"Reconnect error: {e}")
            time.sleep(self._reconnect_delay)
            if self._running:
                self._try_reconnect()

    def stop(self):
        self._running = False
        if self.real_miner:
            self.real_miner.stop()
        if self.pool_client:
            self.pool_client.disconnect()

    def get_stats(self) -> dict:
        return {
            "pool": self.pool_url,
            "worker": self.worker_name,
            "hashrate": self.hashrate,
            "shares_found": self.shares_found,
            "shares_accepted": self.shares_accepted,
            "shares_rejected": self.shares_rejected,
            "estimated_earnings_satoshi": self.estimated_earnings_satoshi,
            "uptime": self.uptime,
            "connected": self.pool_client.connected if self.pool_client else False,
        }

    def _estimate_share_value(self) -> int:
        btc_price = 0
        try:
            from ai.profitability import fetch_btc_price
            btc_price = fetch_btc_price()
        except Exception:
            pass
        if btc_price <= 0:
            btc_price = 50000

        network_hashrate = 624e18
        block_reward = 3.125
        hashrate = max(self.hashrate, 1.0)
        daily_btc = (hashrate / network_hashrate) * 144 * block_reward
        daily_satoshi = daily_btc * 1e8
        shares_per_day = max(hashrate / 1000.0, 1.0)
        value = daily_satoshi / shares_per_day
        return max(1, int(round(value)))
