import hashlib
import struct
import time
import threading
from typing import Optional


def double_sha256(data: bytes) -> bytes:
    return hashlib.sha256(hashlib.sha256(data).digest()).digest()


def bytes_to_hex(b: bytes) -> str:
    return b[::-1].hex()


def hex_to_bytes_le(s: str) -> bytes:
    return bytes.fromhex(s)[::-1]


def _safe_reverse_hex(s: str, size: int) -> bytes:
    if not s:
        return b"\x00" * size
    try:
        b = bytes.fromhex(s)
        if len(b) < size:
            b = b + b"\x00" * (size - len(b))
        return b[:size][::-1]
    except (ValueError, TypeError):
        return b"\x00" * size


def build_block_header(version: int, prev_hash: str, merkle_root: str,
                       ntime: int, nbits: int, nonce: int) -> bytes:
    header = struct.pack("<I", version & 0xFFFFFFFF)
    header += _safe_reverse_hex(prev_hash, 32)
    header += _safe_reverse_hex(merkle_root, 32)
    header += struct.pack("<I", ntime & 0xFFFFFFFF)
    header += struct.pack("<I", nbits & 0xFFFFFFFF)
    header += struct.pack("<I", nonce & 0xFFFFFFFF)
    return header


def bits_to_target(bits: int) -> int:
    shift = (bits >> 24) & 0xff
    value = bits & 0x00ffffff
    return value * (1 << (8 * (shift - 3)))


class PoolJob:
    def __init__(self, job_id: str, prev_hash: str, coinbase1: str, coinbase2: str,
                 merkle_branches: list, version: str, nbits: str, ntime: str,
                 clean_jobs: bool = True):
        self.job_id = job_id
        self.prev_hash = prev_hash
        self.coinbase1 = coinbase1
        self.coinbase2 = coinbase2
        self.merkle_branches = merkle_branches
        self.version_hex = version
        self.nbits_hex = nbits
        self.ntime_hex = ntime
        self.clean_jobs = clean_jobs
        self.target = bits_to_target(int(nbits, 16)) if nbits else bits_to_target(0x1d00ffff)
        self.share_target = 0x00000000ffff0000000000000000000000000000000000000000000000000000
        self.created_at = time.time()
        self.extra_nonce1 = ""
        self.extra_nonce2 = ""
        self.merkle_root_hex = "0" * 64
        if coinbase1 and coinbase2:
            try:
                coinbase = self.build_coinbase("00000000", "00000000")
                self.merkle_root_hex = self.build_merkle_root(coinbase)
            except Exception:
                self.merkle_root_hex = "0" * 64

    def build_merkle_root(self, coinbase: bytes) -> str:
        merkle_root = double_sha256(coinbase)
        for branch in self.merkle_branches:
            try:
                branch_bytes = bytes.fromhex(branch)[::-1]
            except (ValueError, TypeError):
                continue
            merkle_root = double_sha256(merkle_root + branch_bytes)
        return merkle_root[::-1].hex()

    def build_coinbase(self, extra_nonce1: str, extra_nonce2: str) -> bytes:
        try:
            cb1 = bytes.fromhex(self.coinbase1) if self.coinbase1 else b""
            cb2 = bytes.fromhex(self.coinbase2) if self.coinbase2 else b""
        except (ValueError, TypeError):
            cb1, cb2 = b"", b""
        try:
            en1 = bytes.fromhex(extra_nonce1)
        except (ValueError, TypeError):
            en1 = b""
        try:
            en2 = bytes.fromhex(extra_nonce2)
        except (ValueError, TypeError):
            en2 = b""
        return cb1 + en1 + en2 + cb2

    def check_hash(self, block_hash: bytes) -> bool:
        hash_int = int.from_bytes(block_hash, byteorder='little')
        return hash_int < self.share_target

    def to_dict(self) -> dict:
        return {
            "job_id": self.job_id,
            "prev_hash": self.prev_hash[:16],
            "nbits": self.nbits_hex,
            "target": hex(self.target),
            "created_at": self.created_at,
        }


class RealMiner:
    def __init__(self, workers: int = 2):
        self.workers = workers
        self._running = False
        self._threads = []
        self.current_job: Optional[PoolJob] = None
        self.on_share_found = None
        self.hash_count = 0
        self.start_time = 0
        self._lock = threading.Lock()

    @property
    def hashrate(self) -> float:
        elapsed = time.time() - self.start_time
        return self.hash_count / elapsed if elapsed > 0 and self.hash_count > 0 else 0

    def set_job(self, job: PoolJob):
        with self._lock:
            self.current_job = job
            self.hash_count = 0
            self.start_time = time.time()

    def start(self):
        self._running = True
        self.start_time = time.time()
        for i in range(self.workers):
            t = threading.Thread(target=self._miner_loop, args=(i,), daemon=True)
            self._threads.append(t)
            t.start()

    def stop(self):
        self._running = False
        for t in self._threads:
            t.join(timeout=1)
        self._threads.clear()

    def _miner_loop(self, worker_id: int):
        nonce_base = worker_id * 1000000
        local_nonce = 0
        batch_size = 1000

        while self._running:
            with self._lock:
                job = self.current_job
            if job is None:
                time.sleep(0.1)
                continue

            ntime = int(time.time())
            try:
                version_int = int(job.version_hex, 16) if job.version_hex else 0x20000000
                nbits_int = int(job.nbits_hex, 16) if job.nbits_hex else 0x1d00ffff
            except ValueError:
                version_int = 0x20000000
                nbits_int = 0x1d00ffff
            for offset in range(batch_size):
                if not self._running:
                    return
                nonce = nonce_base + local_nonce + offset
                header = build_block_header(
                    version=version_int,
                    prev_hash=job.prev_hash,
                    merkle_root=job.merkle_root_hex,
                    ntime=ntime,
                    nbits=nbits_int,
                    nonce=nonce & 0xFFFFFFFF,
                )
                h = double_sha256(header)
                with self._lock:
                    self.hash_count += 1

                if job.check_hash(h):
                    nonce_str = f"{nonce & 0xFFFFFFFF:08x}"
                    if self.on_share_found:
                        self.on_share_found(job.job_id, nonce_str, ntime)

            local_nonce += batch_size
            if local_nonce > 1000000:
                local_nonce = 0
