from hashlib import sha256
import time
import json
from typing import Optional


class Block:
    def __init__(self, index: int, transactions: str, previous_hash: str,
                 nonce: int = 0, difficulty: int = 4, timestamp: Optional[float] = None):
        self.index = index
        self.timestamp = timestamp or time.time()
        self.transactions = transactions
        self.previous_hash = previous_hash
        self.nonce = nonce
        self.difficulty = difficulty
        self.hash = self.compute_hash()

    def compute_hash(self) -> str:
        data = f"{self.index}{self.timestamp}{self.transactions}{self.previous_hash}{self.nonce}"
        return sha256(data.encode("ascii")).hexdigest()

    def mine_hash(self, max_nonce: int) -> bool:
        prefix = "0" * self.difficulty
        for nonce in range(max_nonce):
            self.nonce = nonce
            h = self.compute_hash()
            if h.startswith(prefix):
                self.hash = h
                return True
        return False

    def to_dict(self) -> dict:
        return {
            "index": self.index,
            "timestamp": self.timestamp,
            "transactions": self.transactions,
            "previous_hash": self.previous_hash,
            "nonce": self.nonce,
            "difficulty": self.difficulty,
            "hash": self.hash,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Block":
        b = cls(
            index=data["index"],
            transactions=data["transactions"],
            previous_hash=data["previous_hash"],
            nonce=data.get("nonce", 0),
            difficulty=data.get("difficulty", 4),
            timestamp=data.get("timestamp"),
        )
        b.hash = data.get("hash", "")
        return b


class Blockchain:
    def __init__(self, difficulty: int = 4):
        self.chain: list[Block] = []
        self.difficulty = difficulty
        self.pending_transactions = []
        self.create_genesis_block()

    def create_genesis_block(self):
        genesis = Block(0, "Genesis Block", "0" * 64, difficulty=self.difficulty)
        genesis.mine_hash(100000)
        self.chain.append(genesis)

    def get_last_block(self) -> Block:
        return self.chain[-1]

    def add_block(self, transactions: str, max_nonce: int = 100000) -> Optional[Block]:
        prev = self.get_last_block()
        block = Block(
            index=prev.index + 1,
            transactions=transactions,
            previous_hash=prev.hash,
            difficulty=self.difficulty,
        )
        found = block.mine_hash(max_nonce)
        if found:
            self.chain.append(block)
            return block
        return None

    def is_chain_valid(self) -> bool:
        for i in range(1, len(self.chain)):
            curr = self.chain[i]
            prev = self.chain[i - 1]
            if curr.hash != curr.compute_hash():
                return False
            if curr.previous_hash != prev.hash:
                return False
        return True

    def to_dict(self) -> list:
        return [b.to_dict() for b in self.chain]

    def save_to_file(self, path: str):
        with open(path, "w") as f:
            json.dump(self.to_dict(), f, indent=2)

    @classmethod
    def load_from_file(cls, path: str) -> "Blockchain":
        with open(path) as f:
            data = json.load(f)
        bc = cls()
        bc.chain = [Block.from_dict(d) for d in data]
        return bc
