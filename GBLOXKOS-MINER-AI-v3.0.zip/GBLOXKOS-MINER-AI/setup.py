#!/usr/bin/env python3
"""Setup script for GBLOXK OS · MINER AI"""
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="gbloxk-os-miner-ai",
    version="3.0.0",
    author="GBLOXK OS Team",
    description="GBLOXK OS MINER AI — Autonomous AI Mining Operating System with Self-Healing, Self-Learning, Self-Awareness & Auto-Payout",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/gbloxk-os/miner-ai",
    packages=find_packages(),
    include_package_data=True,
    entry_points={
        "console_scripts": [
            "gbloxk-os=cli.__main__:main",
            "gbloxk-os-miner=cli.__main__:main",
        ],
    },
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Financial and Insurance Industry",
        "Topic :: Office/Business :: Financial :: Investment",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.9",
    install_requires=[
        "rich>=13.0.0",
        "click>=8.0.0",
        "requests>=2.31.0",
        "ollama>=0.6.0",
        "psutil>=5.9.0",
        "colorama>=0.4.6",
        "fastapi>=0.104.0",
        "uvicorn>=0.24.0",
        "pydantic>=2.5.0",
    ],
)
