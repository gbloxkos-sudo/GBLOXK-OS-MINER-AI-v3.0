import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, NavLink, Navigate } from 'react-router-dom';
import { theme, fmt } from './theme';
import { API_BASE, apiGet, useClock } from './api';
import { Badge } from './ui';
import Overview from './views/Overview';
import Mining from './views/Mining';
import AIEcosystem from './views/AIEcosystem';
import Analytics from './views/Analytics';
import Wallet from './views/Wallet';
import History from './views/History';
import Settings from './views/Settings';

const NAV = [
  { to: '/overview', label: 'Overview', icon: '◎', group: 'Operations' },
  { to: '/mining', label: 'Mining', icon: '⛏', group: 'Operations' },
  { to: '/analytics', label: 'Analytics', icon: '▲', group: 'Operations' },
  { to: '/ecosystem', label: 'AI Ecosystem', icon: '⬡', group: 'Intelligence', highlight: true },
  { to: '/wallet', label: 'Wallet', icon: '◈', group: 'Finance' },
  { to: '/history', label: 'Ledger', icon: '≡', group: 'Finance' },
  { to: '/settings', label: 'Settings', icon: '⚙', group: 'System' },
];

function Sidebar() {
  const groups = [...new Set(NAV.map((n) => n.group))];
  return (
    <aside
      style={{
        width: 236,
        minWidth: 236,
        background: theme.bgAlt,
        borderRight: `1px solid ${theme.border}`,
        display: 'flex',
        flexDirection: 'column',
        height: '100vh',
        position: 'sticky',
        top: 0,
      }}
    >
      <div style={{ padding: '22px 22px 18px', borderBottom: `1px solid ${theme.border}` }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div
            style={{
              width: 34,
              height: 34,
              borderRadius: 9,
              background: `linear-gradient(135deg, ${theme.orange}, #b45309)`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: 18,
              fontWeight: 800,
              color: '#0b0f16',
            }}
          >
            ⛏
          </div>
          <div>
            <div style={{ fontSize: 14.5, fontWeight: 800, color: theme.text, letterSpacing: 0.2 }}>GBLOXK OS</div>
            <div style={{ fontSize: 10.5, color: theme.textFaint, letterSpacing: 1.4, fontWeight: 600 }}>MINER AI v3.0</div>
          </div>
        </div>
      </div>

      <nav style={{ flex: 1, overflowY: 'auto', padding: '14px 12px' }}>
        {groups.map((g) => (
          <div key={g} style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 10, letterSpacing: 1.6, color: theme.textFaint, fontWeight: 700, padding: '0 12px 8px' }}>
              {g.toUpperCase()}
            </div>
            {NAV.filter((n) => n.group === g).map((n) => (
              <NavLink
                key={n.to}
                to={n.to}
                style={({ isActive }) => ({
                  display: 'flex',
                  alignItems: 'center',
                  gap: 12,
                  padding: '10px 12px',
                  borderRadius: 9,
                  marginBottom: 2,
                  textDecoration: 'none',
                  fontSize: 13.5,
                  fontWeight: 600,
                  color: isActive ? theme.text : theme.textDim,
                  background: isActive ? (n.highlight ? theme.violetSoft : theme.panelHover) : 'transparent',
                  borderLeft: isActive ? `2px solid ${n.highlight ? theme.violet : theme.orange}` : '2px solid transparent',
                  transition: 'all 0.15s',
                })}
              >
                <span style={{ fontSize: 15, color: n.highlight ? theme.violet : undefined }}>{n.icon}</span>
                <span style={{ flex: 1 }}>{n.label}</span>
                {n.highlight && (
                  <span
                    style={{
                      fontSize: 8.5,
                      fontWeight: 800,
                      color: theme.violet,
                      border: `1px solid ${theme.violet}55`,
                      borderRadius: 5,
                      padding: '2px 5px',
                      letterSpacing: 0.5,
                    }}
                  >
                    LIVE
                  </span>
                )}
              </NavLink>
            ))}
          </div>
        ))}
      </nav>

      <div style={{ padding: 16, borderTop: `1px solid ${theme.border}`, fontSize: 10.5, color: theme.textFaint }}>
        <div style={{ fontWeight: 700, color: theme.textDim, marginBottom: 3 }}>GBLOXK OS · MINER AI</div>
        <div>Self-Healing · Self-Learning</div>
        <div>Self-Awareness · Auto-Payout</div>
      </div>
    </aside>
  );
}

function Topbar() {
  const [health, setHealth] = useState(null);
  const [stats, setStats] = useState(null);
  const now = useClock(1000);

  useEffect(() => {
    let alive = true;
    const load = async () => {
      try {
        const [h, st] = await Promise.all([apiGet('/health'), apiGet('/api/v1/stats')]);
        if (alive) {
          setHealth(h);
          setStats(st);
        }
      } catch {
        if (alive) setHealth(null);
      }
    };
    load();
    const iv = setInterval(load, 4000);
    return () => {
      alive = false;
      clearInterval(iv);
    };
  }, []);

  const online = !!health;

  return (
    <header
      style={{
        height: 60,
        borderBottom: `1px solid ${theme.border}`,
        background: 'rgba(7,11,18,0.85)',
        backdropFilter: 'blur(10px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 26px',
        position: 'sticky',
        top: 0,
        zIndex: 50,
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        <Badge color={online ? theme.green : theme.red} dot>
          {online ? 'Connected' : 'Offline'}
        </Badge>
        <span style={{ fontSize: 12, color: theme.textFaint, fontFamily: theme.mono }}>{API_BASE}</span>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 22 }}>
        {stats && (
          <div style={{ display: 'flex', gap: 22, fontSize: 12.5 }}>
            <div>
              <span style={{ color: theme.textFaint }}>BTC </span>
              <span style={{ color: theme.orange, fontWeight: 700, fontFamily: theme.mono }}>
                {stats.btc_price ? fmt.usd(stats.btc_price, 0) : '—'}
              </span>
            </div>
            <div>
              <span style={{ color: theme.textFaint }}>HASH </span>
              <span style={{ color: theme.cyan, fontWeight: 700, fontFamily: theme.mono }}>
                {fmt.hash(stats.hash_rate)}
              </span>
            </div>
          </div>
        )}
        <div style={{ fontSize: 12.5, color: theme.textDim, fontFamily: theme.mono }}>
          {new Date(now).toLocaleTimeString()}
        </div>
      </div>
    </header>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <div style={{ display: 'flex', background: theme.bg, minHeight: '100vh' }}>
        <Sidebar />
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
          <Topbar />
          <main style={{ flex: 1, padding: '26px 30px', overflowX: 'hidden' }}>
            <Routes>
              <Route path="/" element={<Navigate to="/overview" replace />} />
              <Route path="/overview" element={<Overview />} />
              <Route path="/mining" element={<Mining />} />
              <Route path="/analytics" element={<Analytics />} />
              <Route path="/ecosystem" element={<AIEcosystem />} />
              <Route path="/wallet" element={<Wallet />} />
              <Route path="/history" element={<History />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="*" element={<Navigate to="/overview" replace />} />
            </Routes>
          </main>
        </div>
      </div>
    </BrowserRouter>
  );
}
