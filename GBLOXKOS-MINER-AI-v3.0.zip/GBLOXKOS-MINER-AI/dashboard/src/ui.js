import React from 'react';
import { theme, fmt } from './theme';

export const s = {
  panel: {
    background: theme.panel,
    border: `1px solid ${theme.border}`,
    borderRadius: theme.radius,
    padding: 20,
    position: 'relative',
  },
  panelTitle: {
    fontSize: 12,
    textTransform: 'uppercase',
    letterSpacing: 1.2,
    color: theme.textDim,
    fontWeight: 600,
    marginBottom: 14,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  row: { display: 'flex', alignItems: 'center' },
  between: { display: 'flex', alignItems: 'center', justifyContent: 'space-between' },
  grid: (min = 200) => ({
    display: 'grid',
    gridTemplateColumns: `repeat(auto-fit, minmax(${min}px, 1fr))`,
    gap: 14,
  }),
  mono: { fontFamily: theme.mono },
};

export function Panel({ title, right, children, style, accent }) {
  return (
    <div style={{ ...s.panel, ...(accent ? { borderTop: `2px solid ${accent}` } : {}), ...style }}>
      {(title || right) && (
        <div style={s.panelTitle}>
          <span>{title}</span>
          {right}
        </div>
      )}
      {children}
    </div>
  );
}

export function KPI({ label, value, sub, accent = theme.orange, icon, trend }) {
  return (
    <div style={{ ...s.panel, padding: 16, overflow: 'hidden' }}>
      <div style={{ position: 'absolute', top: 0, left: 0, width: 3, height: '100%', background: accent }} />
      <div style={{ ...s.between }}>
        <span style={{ fontSize: 12, color: theme.textDim, fontWeight: 600, letterSpacing: 0.4 }}>{label}</span>
        {icon && <span style={{ fontSize: 16, opacity: 0.85 }}>{icon}</span>}
      </div>
      <div style={{ fontSize: 26, fontWeight: 700, color: theme.text, marginTop: 10, letterSpacing: -0.5 }}>
        {value}
      </div>
      {(sub || trend) && (
        <div style={{ fontSize: 12, color: trend === 'up' ? theme.green : trend === 'down' ? theme.red : theme.textFaint, marginTop: 6 }}>
          {sub}
        </div>
      )}
    </div>
  );
}

export function Badge({ children, color = theme.cyan, soft, dot }) {
  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        padding: '3px 10px',
        borderRadius: 20,
        fontSize: 11,
        fontWeight: 700,
        letterSpacing: 0.4,
        textTransform: 'uppercase',
        background: soft || `${color}22`,
        color,
        border: `1px solid ${color}33`,
        whiteSpace: 'nowrap',
      }}
    >
      {dot && <span style={{ width: 6, height: 6, borderRadius: '50%', background: color, boxShadow: `0 0 8px ${color}` }} />}
      {children}
    </span>
  );
}

export function StatusPill({ active }) {
  return active ? (
    <Badge color={theme.green} dot>Live</Badge>
  ) : (
    <Badge color={theme.textFaint}>Idle</Badge>
  );
}

export function HealthBar({ value, color }) {
  const v = Math.max(0, Math.min(1, value || 0));
  const c = color || (v > 0.7 ? theme.green : v > 0.4 ? theme.yellow : theme.red);
  return (
    <div style={{ height: 6, borderRadius: 4, background: 'rgba(148,163,184,0.14)', overflow: 'hidden' }}>
      <div style={{ width: `${v * 100}%`, height: '100%', background: c, borderRadius: 4, transition: 'width 0.6s ease' }} />
    </div>
  );
}

export function Button({ children, onClick, variant = 'primary', disabled, style }) {
  const variants = {
    primary: { background: theme.orange, color: '#0b0f16' },
    danger: { background: theme.red, color: '#fff' },
    success: { background: theme.green, color: '#06231a' },
    ghost: { background: 'transparent', color: theme.textDim, border: `1px solid ${theme.borderStrong}` },
  };
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        padding: '11px 20px',
        border: 'none',
        borderRadius: theme.radiusSm,
        fontWeight: 700,
        fontSize: 13,
        letterSpacing: 0.3,
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.5 : 1,
        transition: 'transform 0.15s ease, filter 0.15s ease',
        ...variants[variant],
        ...style,
      }}
      onMouseDown={(e) => (e.currentTarget.style.transform = 'scale(0.97)')}
      onMouseUp={(e) => (e.currentTarget.style.transform = 'scale(1)')}
      onMouseLeave={(e) => (e.currentTarget.style.transform = 'scale(1)')}
    >
      {children}
    </button>
  );
}

export function DataTable({ columns, rows, empty = 'No data', renderCell }) {
  return (
    <div style={{ overflowX: 'auto' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
        <thead>
          <tr>
            {columns.map((c) => (
              <th
                key={c.key}
                style={{
                  textAlign: c.align || 'left',
                  padding: '10px 12px',
                  color: theme.textDim,
                  fontWeight: 600,
                  fontSize: 11,
                  textTransform: 'uppercase',
                  letterSpacing: 0.8,
                  borderBottom: `1px solid ${theme.border}`,
                  whiteSpace: 'nowrap',
                }}
              >
                {c.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows && rows.length ? (
            rows.map((r, i) => (
              <tr key={i} className="trow">
                {columns.map((c) => (
                  <td
                    key={c.key}
                    style={{
                      padding: '11px 12px',
                      borderBottom: `1px solid ${theme.border}`,
                      textAlign: c.align || 'left',
                      color: theme.text,
                      whiteSpace: 'nowrap',
                      ...(c.mono ? s.mono : {}),
                    }}
                  >
                    {renderCell ? renderCell(r, c) : r[c.key]}
                  </td>
                ))}
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan={columns.length} style={{ padding: 28, textAlign: 'center', color: theme.textFaint }}>
                {empty}
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

export function Gauge({ value, max = 100, label, unit = '%', color, size = 96 }) {
  const pct = Math.max(0, Math.min(1, (value || 0) / max));
  const r = size / 2 - 8;
  const circ = 2 * Math.PI * r;
  const c = color || (pct > 0.85 ? theme.red : pct > 0.65 ? theme.yellow : theme.green);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(148,163,184,0.14)" strokeWidth={8} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={c}
          strokeWidth={8}
          strokeLinecap="round"
          strokeDasharray={circ}
          strokeDashoffset={circ * (1 - pct)}
          style={{ transition: 'stroke-dashoffset 0.6s ease' }}
        />
      </svg>
      <div style={{ marginTop: -size / 2 - 12, fontSize: 18, fontWeight: 700, color: theme.text }}>
        {fmt.num(value, value < 10 ? 1 : 0)}
        <span style={{ fontSize: 11, color: theme.textDim }}>{unit}</span>
      </div>
      <div style={{ fontSize: 11, color: theme.textDim, marginTop: size / 2 - 6, fontWeight: 600 }}>{label}</div>
    </div>
  );
}

export function Sparkline({ data, color = theme.orange, height = 40, width = 140 }) {
  if (!data || data.length < 2) {
    return <div style={{ height, width, opacity: 0.25, borderBottom: `1px dashed ${theme.border}` }} />;
  }
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const step = width / (data.length - 1);
  const pts = data.map((d, i) => `${i * step},${height - ((d - min) / range) * height}`).join(' ');
  return (
    <svg width={width} height={height} style={{ display: 'block' }}>
      <polyline points={pts} fill="none" stroke={color} strokeWidth={2} strokeLinejoin="round" />
    </svg>
  );
}

export function Toast({ message, type = 'info', onClose }) {
  if (!message) return null;
  const colors = { info: theme.cyan, success: theme.green, error: theme.red };
  const c = colors[type] || theme.cyan;
  return (
    <div
      className="toast"
      style={{
        position: 'fixed',
        bottom: 24,
        right: 24,
        zIndex: 1000,
        background: theme.panelAlt,
        border: `1px solid ${c}55`,
        borderLeft: `3px solid ${c}`,
        borderRadius: theme.radiusSm,
        padding: '14px 18px',
        maxWidth: 380,
        boxShadow: '0 12px 32px rgba(0,0,0,0.5)',
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        color: theme.text,
        fontSize: 13,
      }}
    >
      <span style={{ flex: 1 }}>{message}</span>
      {onClose && (
        <span onClick={onClose} style={{ cursor: 'pointer', color: theme.textFaint }}>
          ✕
        </span>
      )}
    </div>
  );
}

export function Section({ title, subtitle, right, children }) {
  return (
    <div style={{ marginBottom: 22 }}>
      <div style={{ ...s.between, marginBottom: 14 }}>
        <div>
          <div style={{ fontSize: 17, fontWeight: 700, color: theme.text }}>{title}</div>
          {subtitle && <div style={{ fontSize: 12.5, color: theme.textDim, marginTop: 3 }}>{subtitle}</div>}
        </div>
        {right}
      </div>
      {children}
    </div>
  );
}
