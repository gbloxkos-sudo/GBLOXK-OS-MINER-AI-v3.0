import React, { useState, useMemo } from 'react';
import { theme, fmt } from '../theme';
import { usePolling } from '../api';
import { Panel, KPI, Badge, Section, DataTable, Button, s } from '../ui';

export default function History() {
  const { data } = usePolling('/api/v1/history', 8000);
  const [query, setQuery] = useState('');

  const sessions = useMemo(() => {
    const list = (data?.sessions || []).map((x) => ({
      ...x,
      started: x.start_time ? new Date(x.start_time * 1000).toLocaleString() : '—',
      ended: x.end_time ? new Date(x.end_time * 1000).toLocaleString() : '—',
    }));
    if (!query.trim()) return list;
    const q = query.toLowerCase();
    return list.filter(
      (x) =>
        String(x.difficulty_level).includes(q) ||
        String(x.blocks_found).includes(q) ||
        x.status.toLowerCase().includes(q) ||
        x.started.toLowerCase().includes(q)
    );
  }, [data, query]);

  const totals = (data?.sessions || []).reduce(
    (acc, x) => ({
      blocks: acc.blocks + (x.blocks_found || 0),
      hashes: acc.hashes + (x.total_hashes || 0),
      time: acc.time + ((x.end_time || Date.now() / 1000) - (x.start_time || 0)),
    }),
    { blocks: 0, hashes: 0, time: 0 }
  );

  const exportCsv = () => {
    const rows = [
      ['id', 'user_id', 'started', 'ended', 'difficulty', 'blocks_found', 'total_hashes', 'avg_hash_rate', 'status'],
      ...sessions.map((x) => [
        x.id, x.user_id, x.started, x.ended, x.difficulty_level, x.blocks_found, x.total_hashes, x.avg_hash_rate || 0, x.status,
      ]),
    ];
    const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `gbloxk-os-ledger-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div>
      <Section
        title="Session Ledger"
        subtitle="Immutable mining session records with export"
        right={
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <input
              placeholder="Filter…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              style={{
                padding: '8px 12px', borderRadius: 8, border: `1px solid ${theme.border}`,
                background: theme.bgAlt, color: theme.text, fontSize: 12.5, outline: 'none', width: 180,
              }}
            />
            <Button variant="ghost" onClick={exportCsv}>
              ⬇ EXPORT CSV
            </Button>
          </div>
        }
      />

      <div style={s.grid(190)}>
        <KPI label="Total Sessions" value={fmt.num(data?.sessions?.length)} icon="≡" accent={theme.cyan} />
        <KPI label="Total Blocks" value={fmt.num(totals.blocks)} icon="⛏" accent={theme.orange} />
        <KPI label="Total Hashes" value={fmt.num(totals.hashes)} icon="#" accent={theme.violet} />
        <KPI label="Aggregate Runtime" value={fmt.dur(totals.time)} icon="⏱" accent={theme.green} />
      </div>

      <div style={{ marginTop: 14 }}>
        <Panel title="Mining Sessions" right={<Badge color={theme.textDim}>{sessions.length} shown</Badge>}>
          <DataTable
            columns={[
              { key: 'id', label: '#', mono: true },
              { key: 'started', label: 'Started' },
              { key: 'ended', label: 'Ended' },
              { key: 'difficulty_level', label: 'Diff', align: 'center' },
              { key: 'blocks_found', label: 'Blocks', align: 'right' },
              { key: 'total_hashes', label: 'Hashes', align: 'right', mono: true },
              { key: 'avg_hash_rate', label: 'Avg Rate', align: 'right', mono: true },
              { key: 'status', label: 'Status', align: 'right' },
            ]}
            rows={sessions}
            renderCell={(r, c) => {
              if (c.key === 'difficulty_level') return <span style={{ color: theme.violet }}>D{r.difficulty_level}</span>;
              if (c.key === 'blocks_found') return <span style={{ color: theme.green }}>{r.blocks_found}</span>;
              if (c.key === 'avg_hash_rate') return <span style={{ color: theme.cyan }}>{fmt.hash(r.avg_hash_rate)}</span>;
              if (c.key === 'status') return <Badge color={r.status === 'active' ? theme.yellow : theme.green}>{r.status}</Badge>;
              return r[c.key];
            }}
          />
        </Panel>
      </div>
    </div>
  );
}
