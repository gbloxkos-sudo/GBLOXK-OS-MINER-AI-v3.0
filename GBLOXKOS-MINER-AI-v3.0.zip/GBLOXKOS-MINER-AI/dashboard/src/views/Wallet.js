import React, { useState } from 'react';
import { theme, fmt } from '../theme';
import { usePolling, apiPost } from '../api';
import { Panel, KPI, Button, Badge, Toast, Section, DataTable, HealthBar, s } from '../ui';

const STATUS_COLORS = { pending: theme.yellow, completed: theme.green, rejected: theme.red, failed: theme.red };

export default function Wallet() {
  const { data: wallet, reload } = usePolling('/api/v1/wallet', 4000);
  const { data: tx, reload: reloadTx } = usePolling('/api/v1/wallet/transactions', 6000);
  const [address, setAddress] = useState('');
  const [amount, setAmount] = useState('');
  const [payoutAddr, setPayoutAddr] = useState('');
  const [threshold, setThreshold] = useState('');
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);

  const notify = (message, type = 'info') => {
    setMsg({ message, type });
    setTimeout(() => setMsg(null), 3500);
  };

  const savedAddress = tx?.wallet?.btc_address || wallet?.btc_address || '';
  const autopayEnabled = !!(tx?.wallet?.auto_payout_enabled ?? wallet?.auto_payout_enabled);
  const autoThreshold = tx?.wallet?.payout_threshold_satoshi ?? 100000;
  const balance = wallet?.balance_satoshi || 0;
  const progress = Math.min(1, balance / (autoThreshold || 1));

  const saveAddress = async () => {
    if (!payoutAddr.trim()) return notify('Enter a wallet address', 'error');
    setBusy(true);
    try {
      await apiPost('/api/v1/wallet/address', { btc_address: payoutAddr.trim() });
      notify(`Payout address saved → ${payoutAddr.trim().slice(0, 12)}…`, 'success');
      setPayoutAddr('');
      reload();
      reloadTx();
    } catch (e) {
      notify(`Save failed: ${e.message}`, 'error');
    }
    setBusy(false);
  };

  const configureAutopay = async (enabled) => {
    setBusy(true);
    try {
      const body = { enabled, threshold_satoshi: threshold ? parseInt(threshold, 10) : autoThreshold };
      if (payoutAddr.trim()) body.btc_address = payoutAddr.trim();
      await apiPost('/api/v1/wallet/autopay', body);
      notify(enabled ? 'Auto-send enabled — coins will settle automatically' : 'Auto-send disabled', 'success');
      setThreshold('');
      reload();
      reloadTx();
    } catch (e) {
      notify(`Error: ${e.message}`, 'error');
    }
    setBusy(false);
  };

  const withdraw = async () => {
    const sat = parseInt(amount, 10);
    if (!sat || sat <= 0) return notify('Enter a valid satoshi amount', 'error');
    if (!address) return notify('Enter a destination BTC address', 'error');
    if (sat < 10000) return notify('Minimum withdrawal is 10,000 satoshi', 'error');
    if (sat > balance) return notify('Insufficient balance', 'error');
    setBusy(true);
    try {
      await apiPost('/api/v1/wallet/withdraw', { satoshi: sat, btc_address: address });
      notify(`Withdrawal of ${sat.toLocaleString()} sats queued → ${address}`, 'success');
      setAddress('');
      setAmount('');
      reload();
      reloadTx();
    } catch (e) {
      notify(`Withdrawal failed: ${e.message}`, 'error');
    }
    setBusy(false);
  };

  const balanceBtc = balance / 1e8;

  return (
    <div>
      <Section
        title="Wallet"
        subtitle="Mining rewards, treasury auto-send and BTC withdrawals"
        right={<Badge color={autopayEnabled ? theme.green : theme.textFaint} dot>{autopayEnabled ? 'AUTO-SEND ARMED' : 'MANUAL MODE'}</Badge>}
      />

      <div style={s.grid(200)}>
        <KPI label="Balance" value={fmt.sats(balance)} icon="◈" accent={theme.orange} sub={`${fmt.btc(balanceBtc)} BTC`} />
        <KPI label="Total Earned" value={fmt.sats(wallet?.total_earned_satoshi)} icon="📈" accent={theme.green} sub="From accepted shares" />
        <KPI label="Total Withdrawn" value={fmt.sats(wallet?.total_withdrawn_satoshi)} icon="↗" accent={theme.red} />
        <KPI
          label="Payout Address"
          value={savedAddress ? savedAddress.slice(0, 10) + '…' : 'NOT SET'}
          icon="📍"
          accent={savedAddress ? theme.green : theme.red}
          sub={savedAddress || 'Set your wallet below'}
        />
      </div>

      <div style={{ marginTop: 14 }}>
        <Panel title="Auto-Send to Wallet" accent={theme.orange} right={<Badge color={autopayEnabled ? theme.green : theme.yellow}>{autopayEnabled ? 'ACTIVE' : 'INACTIVE'}</Badge>}>
          <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: 18 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div>
                <div style={{ fontSize: 11, color: theme.textDim, marginBottom: 6, letterSpacing: 0.4 }}>
                  CRYPTO WALLET ADDRESS (BTC · ETH · LTC · ANY BECH32/BASE58)
                </div>
                <input
                  placeholder="bc1q… / 0x… / ltc1… / L…"
                  value={payoutAddr}
                  onChange={(e) => setPayoutAddr(e.target.value)}
                  style={{
                    width: '100%', padding: '12px 14px', borderRadius: 8,
                    border: `1px solid ${theme.border}`, background: theme.bgAlt,
                    color: theme.text, fontSize: 13, fontFamily: theme.mono, outline: 'none',
                  }}
                />
              </div>
              <div>
                <div style={{ fontSize: 11, color: theme.textDim, marginBottom: 6, letterSpacing: 0.4 }}>
                  AUTO-SEND THRESHOLD (SATOSHI · MIN 10,000)
                </div>
                <input
                  type="number"
                  placeholder={String(autoThreshold)}
                  value={threshold}
                  onChange={(e) => setThreshold(e.target.value)}
                  style={{
                    width: '100%', padding: '12px 14px', borderRadius: 8,
                    border: `1px solid ${theme.border}`, background: theme.bgAlt,
                    color: theme.text, fontSize: 13, fontFamily: theme.mono, outline: 'none',
                  }}
                />
              </div>
              <div style={{ display: 'flex', gap: 10 }}>
                <Button onClick={saveAddress} disabled={busy} variant="ghost">📍 SAVE ADDRESS</Button>
                <Button onClick={() => configureAutopay(true)} disabled={busy} variant="success">⚡ ENABLE AUTO-SEND</Button>
                <Button onClick={() => configureAutopay(false)} disabled={busy} variant="ghost">DISABLE</Button>
              </div>
            </div>
            <div style={{ borderLeft: `1px solid ${theme.border}`, paddingLeft: 18 }}>
              <div style={{ fontSize: 12, color: theme.textDim, marginBottom: 10 }}>
                When your balance reaches the threshold, the treasury agent automatically settles the full amount to your wallet.
              </div>
              <div style={{ ...s.between, fontSize: 12, color: theme.textDim, marginBottom: 6 }}>
                <span>Progress to payout</span>
                <span style={{ color: theme.text, fontFamily: theme.mono }}>
                  {fmt.num(balance)} / {fmt.num(autoThreshold)} sats
                </span>
              </div>
              <HealthBar value={progress} color={theme.orange} />
              <div style={{ marginTop: 12, fontSize: 11, color: theme.textFaint }}>
                Last payout: {tx?.wallet?.last_payout_at ? new Date(tx.wallet.last_payout_at * 1000).toLocaleString() : 'never'}
                <br />
                Settlement agent: {' '}
                <span style={{ color: theme.green }}>
                  {tx?.autopay?.running ? 'online' : 'offline'}
                </span>
                {' '}· {tx?.autopay?.payouts_sent || 0} auto-payouts sent
              </div>
            </div>
          </div>
        </Panel>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.4fr', gap: 14, marginTop: 14 }}>
        <Panel title="Manual Withdraw">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <input
              placeholder="Destination address (1… / 3… / bc1…)"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              style={{
                width: '100%', padding: '12px 14px', borderRadius: 8,
                border: `1px solid ${theme.border}`, background: theme.bgAlt,
                color: theme.text, fontSize: 13, fontFamily: theme.mono, outline: 'none',
              }}
            />
            <input
              type="number"
              placeholder="Amount (satoshi, min 10,000)"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              style={{
                width: '100%', padding: '12px 14px', borderRadius: 8,
                border: `1px solid ${theme.border}`, background: theme.bgAlt,
                color: theme.text, fontSize: 13, fontFamily: theme.mono, outline: 'none',
              }}
            />
            <Button onClick={withdraw} disabled={busy} variant="primary">
              {busy ? 'PROCESSING…' : '↗ REQUEST WITHDRAWAL'}
            </Button>
          </div>
        </Panel>

        <Panel title="Payout Ledger" right={<Badge color={theme.textDim}>{tx?.withdrawals?.length || 0} records</Badge>}>
          <DataTable
            columns={[
              { key: 'created_at', label: 'Date' },
              { key: 'amount_satoshi', label: 'Amount', align: 'right', mono: true },
              { key: 'btc_address', label: 'Address' },
              { key: 'status', label: 'Status', align: 'right' },
            ]}
            rows={(tx?.withdrawals || []).map((w) => ({
              ...w,
              created_at: new Date((w.created_at || 0) * 1000).toLocaleString(),
              btc_address: (w.btc_address || '').slice(0, 14) + '…',
            }))}
            empty="No payouts yet — start mining to earn"
            renderCell={(r, c) =>
              c.key === 'amount_satoshi' ? (
                <span style={{ color: theme.orange }}>{fmt.sats(r.amount_satoshi)}</span>
              ) : c.key === 'status' ? (
                <Badge color={STATUS_COLORS[r.status] || theme.textDim}>{r.status}</Badge>
              ) : (
                r[c.key]
              )
            }
          />
        </Panel>
      </div>

      <Toast message={msg?.message} type={msg?.type} onClose={() => setMsg(null)} />
    </div>
  );
}