import React from 'react';
import {
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
} from 'recharts';
import { theme, fmt } from '../theme';
import { usePolling } from '../api';
import { Panel, KPI, Gauge, Badge, HealthBar, Section, s } from '../ui';

function ChartTooltip({ active, payload, label }) {
  if (!active || !payload || !payload.length) return null;
  return (
    <div style={{ background: theme.panelAlt, border: `1px solid ${theme.borderStrong}`, borderRadius: 8, padding: '8px 12px', fontSize: 12 }}>
      <div style={{ color: theme.textDim, marginBottom: 4 }}>{label}</div>
      {payload.map((p) => (
        <div key={p.dataKey} style={{ color: p.color }}>
          {p.name}: <b>{fmt.num(p.value, 2)}</b>
        </div>
      ))}
    </div>
  );
}

export default function Overview() {
  const { data: stats } = usePolling('/api/v1/stats', 2500);
  const { data: selfStatus } = usePolling('/api/v1/self', 4000);
  const { data: profit } = usePolling('/api/v1/profitability', 10000);
  const { data: history } = usePolling('/api/v1/history', 8000);
  const { data: chart } = usePolling('/api/v1/chart', 3000);

  const active = (stats?.hash_rate || 0) > 0;
  const aw = selfStatus?.awareness || {};
  const healthColor =
    { excellent: theme.green, good: theme.cyan, fair: theme.yellow, monitoring: theme.yellow, critical: theme.red }[
      aw.health
    ] || theme.textDim;

  const sparkData = (chart?.hashrates || []).map((hr, i) => ({
    t: chart?.timestamps?.[i] || i,
    hr: Math.max(0, hr || 0),
  }));

  const resources = stats?.resources || {};
  const cpuPct = resources.cpu_percent ?? 0;
  const ramPct = resources.memory_percent ?? 0;
  const tempC = resources.temperature ?? 0;

  return (
    <div>
      <Section
        title="Command Center"
        subtitle="Real-time mining operations, system health and autonomous intelligence"
        right={<Badge color={active ? theme.green : theme.textFaint} dot>{active ? 'MINING ACTIVE' : 'STANDBY'}</Badge>}
      />

      <div style={s.grid(190)}>
        <KPI label="Hash Rate" value={fmt.hash(stats?.hash_rate)} icon="⚡" accent={theme.cyan} sub="Live throughput" />
        <KPI label="Blocks / Shares" value={fmt.num(stats?.blocks_found)} icon="⛏" accent={theme.orange} sub={`${fmt.num(stats?.total_shares)} shares`} />
        <KPI label="BTC Price" value={stats?.btc_price ? fmt.usd(stats.btc_price, 0) : '—'} icon="₿" accent={theme.yellow} sub="CoinGecko live" />
        <KPI label="Daily Profit" value={profit ? fmt.usd(profit.daily_profit_usd, 4) : '—'} icon="📈" accent={profit?.daily_profit_usd >= 0 ? theme.green : theme.red} sub={profit ? `Monthly ${fmt.usd(profit.monthly_profit_usd)}` : ''} />
        <KPI label="AI Health" value={(aw.health || '—').toUpperCase()} icon="🧠" accent={healthColor} sub={`Stability ${fmt.pct((aw.stability || 0) * 100)}`} />
        <KPI label="Uptime" value={fmt.dur(stats?.elapsed)} icon="⏱" accent={theme.violet} sub={`Difficulty ${stats?.current_difficulty ?? '—'}`} />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 14, marginTop: 14 }}>
        <Panel title="Hash Rate Telemetry" right={<Badge color={theme.cyan}>REAL-TIME</Badge>}>
          <ResponsiveContainer width="100%" height={230}>
            <AreaChart data={sparkData} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
              <defs>
                <linearGradient id="hrGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={theme.orange} stopOpacity={0.5} />
                  <stop offset="100%" stopColor={theme.orange} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke={theme.border} strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="t" hide />
              <YAxis stroke={theme.textFaint} fontSize={11} tickFormatter={(v) => fmt.hash(v)} width={70} />
              <Tooltip content={<ChartTooltip />} />
              <Area type="monotone" dataKey="hr" name="Hash/s" stroke={theme.orange} strokeWidth={2} fill="url(#hrGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </Panel>

        <Panel title="System Resources" right={<Badge color={theme.cyan}>LIVE</Badge>}>
          <div style={{ display: 'flex', justifyContent: 'space-around' }}>
            <Gauge value={cpuPct} label="CPU" unit="%" color={theme.cyan} />
            <Gauge value={ramPct} label="RAM" unit="%" color={theme.violet} />
            <Gauge value={tempC} label="TEMP" unit="°C" max={100} color={theme.orange} />
          </div>
          <div style={{ marginTop: 14, fontSize: 12, color: theme.textFaint, textAlign: 'center' }}>
            {resources.cores_logical
              ? `${resources.cores_logical} logical cores · ${(resources.memory_available_gb || 0).toFixed(1)} GB RAM available`
              : 'Live resource telemetry streamed from the orchestrator monitor loop.'}
          </div>
        </Panel>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginTop: 14 }}>
        <Panel title="Autonomous Intelligence">
          {[
            { k: 'Self-Awareness', v: (aw.consciousness || 'awake').toUpperCase(), c: theme.violet },
            { k: 'Self-Healing Incidents', v: fmt.num(selfStatus?.healing?.total_incidents), c: theme.green },
            { k: 'Learning Records', v: fmt.num(selfStatus?.learning?.records_count), c: theme.yellow },
            { k: 'Patterns Discovered', v: fmt.num(selfStatus?.learning?.patterns_found), c: theme.cyan },
            { k: 'Anomalies Detected', v: fmt.num(aw.anomalies), c: (aw.anomalies || 0) > 0 ? theme.red : theme.green },
          ].map((row) => (
            <div key={row.k} style={{ ...s.between, padding: '9px 0', borderBottom: `1px solid ${theme.border}` }}>
              <span style={{ fontSize: 13, color: theme.textDim }}>{row.k}</span>
              <span style={{ fontSize: 13, fontWeight: 700, color: row.c }}>{row.v}</span>
            </div>
          ))}
          <div style={{ marginTop: 12 }}>
            <div style={{ fontSize: 11, color: theme.textFaint, marginBottom: 6 }}>STABILITY INDEX</div>
            <HealthBar value={aw.stability || 0} />
          </div>
        </Panel>

        <Panel title="Recent Sessions" right={<Badge color={theme.textDim}>{history?.sessions?.length || 0}</Badge>}>
          {(history?.sessions || []).slice(0, 6).map((sess, i) => (
            <div key={i} style={{ ...s.between, padding: '9px 0', borderBottom: `1px solid ${theme.border}` }}>
              <span style={{ fontSize: 12.5, color: theme.textDim }}>
                {new Date((sess.start_time || 0) * 1000).toLocaleString()}
              </span>
              <span style={{ display: 'flex', gap: 14, fontSize: 12.5 }}>
                <span style={{ color: theme.orange }}>D{sess.difficulty_level}</span>
                <span style={{ color: theme.green }}>{sess.blocks_found} blk</span>
                <span style={{ color: theme.cyan }}>{fmt.hash(sess.avg_hash_rate)}</span>
              </span>
            </div>
          ))}
          {!history?.sessions?.length && (
            <div style={{ padding: 24, textAlign: 'center', color: theme.textFaint, fontSize: 13 }}>
              No sessions yet. Start mining to populate the ledger.
            </div>
          )}
        </Panel>
      </div>
    </div>
  );
}
