import React, { useState, useEffect } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Cell,
} from 'recharts';
import { theme, fmt } from '../theme';
import { apiGet } from '../api';
import { Panel, KPI, Badge, Section, DataTable, s } from '../ui';

function ChartTooltip({ active, payload, label }) {
  if (!active || !payload || !payload.length) return null;
  return (
    <div style={{ background: theme.panelAlt, border: `1px solid ${theme.borderStrong}`, borderRadius: 8, padding: '8px 12px', fontSize: 12 }}>
      <div style={{ color: theme.textDim, marginBottom: 4 }}>{label}</div>
      {payload.map((p) => (
        <div key={p.dataKey} style={{ color: p.color }}>
          {p.name}: <b>{fmt.usd(p.value, 4)}</b>
        </div>
      ))}
    </div>
  );
}

export default function Analytics() {
  const [hashrate, setHashrate] = useState(1000000);
  const [power, setPower] = useState(65);
  const [cost, setCost] = useState(0.12);
  const [fee, setFee] = useState(2);
  const [profit, setProfit] = useState(null);
  const [coins, setCoins] = useState([]);
  const [err, setErr] = useState(null);

  useEffect(() => {
    const t = setTimeout(async () => {
      try {
        const p = await apiGet(
          `/api/v1/profitability?hashrate=${hashrate}&power=${power}&cost=${cost}&fee=${(fee / 100).toFixed(4)}`
        );
        setProfit(p);
        setErr(null);
      } catch (e) {
        setErr(e.message);
      }
    }, 350);
    return () => clearTimeout(t);
  }, [hashrate, power, cost, fee]);

  useEffect(() => {
    apiGet('/api/v1/coins')
      .then((d) => setCoins(d.coins || []))
      .catch(() => setCoins([]));
  }, []);

  const projections = profit
    ? [
        { name: 'Daily', revenue: profit.daily_revenue_usd, cost: profit.daily_power_cost },
        { name: 'Weekly', revenue: profit.daily_revenue_usd * 7, cost: profit.daily_power_cost * 7 },
        { name: 'Monthly', revenue: profit.daily_revenue_usd * 30, cost: profit.daily_power_cost * 30 },
        { name: 'Yearly', revenue: profit.daily_revenue_usd * 365, cost: profit.daily_power_cost * 365 },
      ]
    : [];

  const field = (label, value, setter, step, min = 0) => (
    <div style={{ flex: 1, minWidth: 130 }}>
      <div style={{ fontSize: 11, color: theme.textDim, marginBottom: 6, letterSpacing: 0.4 }}>{label}</div>
      <input
        type="number"
        value={value}
        step={step}
        min={min}
        onChange={(e) => setter(Number(e.target.value) || 0)}
        style={{
          width: '100%',
          padding: '9px 12px',
          borderRadius: 8,
          border: `1px solid ${theme.border}`,
          background: theme.bgAlt,
          color: theme.text,
          fontSize: 13,
          fontFamily: theme.mono,
          outline: 'none',
        }}
      />
    </div>
  );

  return (
    <div>
      <Section
        title="Analytics"
        subtitle="Profitability modeling, revenue projections and multi-coin market intelligence"
        right={<Badge color={err ? theme.red : theme.cyan}>{err ? 'FEED ERROR' : 'LIVE FEED'}</Badge>}
      />

      <Panel title="Profitability Model" style={{ marginBottom: 14 }}>
        <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap' }}>
          {field('Hashrate (H/s)', hashrate, setHashrate, 100000)}
          {field('Power (W)', power, setPower, 5)}
          {field('Electricity $/kWh', cost, setCost, 0.01)}
          {field('Pool Fee (%)', fee, setFee, 0.5)}
        </div>
      </Panel>

      <div style={s.grid(190)}>
        <KPI label="BTC Price" value={profit ? fmt.usd(profit.btc_price, 0) : '—'} icon="₿" accent={theme.yellow} />
        <KPI label="Daily BTC" value={profit ? fmt.btc(profit.daily_btc) : '—'} icon="⛏" accent={theme.orange} />
        <KPI
          label="Daily Profit"
          value={profit ? fmt.usd(profit.daily_profit_usd, 4) : '—'}
          icon="📈"
          accent={profit?.daily_profit_usd >= 0 ? theme.green : theme.red}
        />
        <KPI label="Monthly Profit" value={profit ? fmt.usd(profit.monthly_profit_usd) : '—'} icon="🗓" accent={profit?.monthly_profit_usd >= 0 ? theme.green : theme.red} />
        <KPI label="ROI" value={profit ? fmt.pct(profit.roi_percent) : '—'} icon="↻" accent={theme.cyan} />
        <KPI
          label="Days to 1 BTC"
          value={profit && profit.days_to_1btc !== Infinity ? fmt.num(profit.days_to_1btc) : '∞'}
          icon="🎯"
          accent={theme.violet}
          sub={profit && profit.days_to_1btc !== Infinity ? 'at current rate' : 'beyond horizon'}
        />
      </div>

      <div style={{ marginTop: 14 }}>
        <Panel title="Revenue Projections" right={<Badge color={theme.orange}>USD</Badge>}>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={projections} margin={{ top: 8, right: 8, left: -8, bottom: 0 }}>
              <CartesianGrid stroke={theme.border} strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="name" stroke={theme.textFaint} fontSize={11} />
              <YAxis stroke={theme.textFaint} fontSize={11} tickFormatter={(v) => `$${v.toFixed(0)}`} width={70} />
              <Tooltip content={<ChartTooltip />} cursor={{ fill: 'rgba(148,163,184,0.06)' }} />
              <Bar dataKey="revenue" name="Revenue" fill={theme.orange} radius={[4, 4, 0, 0]} />
              <Bar dataKey="cost" name="Power Cost" fill={theme.red} radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Panel>
      </div>

      <div style={{ marginTop: 14 }}>
        <Panel title="Multi-Coin Market Intelligence" right={<Badge color={theme.textDim}>{coins.length} coins</Badge>}>
          <DataTable
            columns={[
              { key: 'name', label: 'Coin' },
              { key: 'symbol', label: 'Symbol' },
              { key: 'algorithm', label: 'Algorithm' },
              { key: 'block_reward', label: 'Reward', align: 'right' },
              { key: 'block_time_seconds', label: 'Block Time', align: 'right' },
              { key: 'price_usd', label: 'Price', align: 'right', mono: true },
              { key: 'daily_revenue_usd', label: 'Daily Rev @1MH', align: 'right', mono: true },
              { key: 'profitability_score', label: 'Score', align: 'right', mono: true },
            ]}
            rows={coins}
            empty="Coin data unavailable (air-gapped mode)"
            renderCell={(r, c) => {
              if (c.key === 'price_usd') return fmt.usd(r.price_usd, 2);
              if (c.key === 'daily_revenue_usd') return fmt.usd(r.daily_revenue_usd, 4);
              if (c.key === 'profitability_score') return fmt.num(r.profitability_score, 3);
              if (c.key === 'block_reward') return fmt.num(r.block_reward, 3);
              if (c.key === 'block_time_seconds') return `${fmt.num(r.block_time_seconds)}s`;
              return r[c.key];
            }}
          />
        </Panel>
      </div>
    </div>
  );
}
