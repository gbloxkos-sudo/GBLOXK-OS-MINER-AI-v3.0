import React, { useEffect, useRef, useState } from 'react';
import { theme, fmt } from '../theme';
import { usePolling } from '../api';
import { Panel, KPI, Badge, HealthBar, Section, s } from '../ui';

function useTicker(ms = 1000) {
  const [, setT] = useState(0);
  useEffect(() => {
    const iv = setInterval(() => setT((x) => x + 1), ms);
    return () => clearInterval(iv);
  }, [ms]);
}

function NeuralMesh({ snapshot }) {
  const nodes = snapshot?.nodes || [];
  const edges = snapshot?.edges || [];
  const pos = {};
  nodes.forEach((n) => {
    pos[n.id] = n;
  });
  const coreSignal = snapshot?.metrics?.mesh_activity || 0;

  return (
    <div style={{ position: 'relative', width: '100%', height: 420, overflow: 'hidden' }}>
      {/* background grid */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          backgroundImage:
            'linear-gradient(rgba(148,163,184,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(148,163,184,0.06) 1px, transparent 1px)',
          backgroundSize: '36px 36px',
          maskImage: 'radial-gradient(circle at 50% 50%, black 40%, transparent 78%)',
          WebkitMaskImage: 'radial-gradient(circle at 50% 50%, black 40%, transparent 78%)',
        }}
      />

      {/* edges */}
      <svg viewBox="0 0 100 100" preserveAspectRatio="none" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
        {edges.map((e, i) => {
          const a = pos[e.source];
          const b = pos[e.target];
          if (!a || !b) return null;
          const act = Math.max(0.06, e.activity || 0);
          return (
            <g key={i}>
              <line x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke={theme.cyan} strokeWidth={0.15} opacity={act * 0.5} />
              <line
                className="flow"
                x1={a.x}
                y1={a.y}
                x2={b.x}
                y2={b.y}
                stroke={act > 0.4 ? theme.orange : theme.cyan}
                strokeWidth={0.3}
                opacity={act}
                strokeDasharray="2 4"
              />
            </g>
          );
        })}
      </svg>

      {/* core */}
      <div
        style={{
          position: 'absolute',
          left: '50%',
          top: '50%',
          transform: 'translate(-50%, -50%)',
          width: 96,
          height: 96,
          borderRadius: '50%',
          background: `radial-gradient(circle, ${theme.violet}55, transparent 70%)`,
          border: `2px solid ${theme.violet}`,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          boxShadow: `0 0 ${20 + coreSignal * 40}px ${theme.violet}88`,
          animation: 'corePulse 2.4s ease-in-out infinite',
          zIndex: 3,
        }}
      >
        <div style={{ fontSize: 26 }}>🧠</div>
        <div style={{ fontSize: 9, color: theme.text, fontWeight: 800, letterSpacing: 1 }}>CORE</div>
        <div style={{ fontSize: 8, color: theme.textDim }}>{Math.round(coreSignal * 100)}%</div>
      </div>

      {/* agent nodes */}
      {nodes.map((n) => {
        const active = (n.signal || 0) > 0.15;
        return (
          <div
            key={n.id}
            style={{
              position: 'absolute',
              left: `${n.x}%`,
              top: `${n.y}%`,
              transform: 'translate(-50%, -50%)',
              zIndex: 2,
              textAlign: 'center',
              width: 96,
            }}
          >
            <div
              style={{
                width: 44,
                height: 44,
                margin: '0 auto',
                borderRadius: 12,
                background: theme.panelAlt,
                border: `2px solid ${n.color}`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: 20,
                boxShadow: active ? `0 0 ${8 + n.signal * 20}px ${n.color}` : 'none',
                transition: 'box-shadow 0.5s ease',
              }}
            >
              {n.icon}
            </div>
            <div style={{ fontSize: 10, fontWeight: 700, color: theme.text, marginTop: 4, whiteSpace: 'nowrap' }}>
              {n.label}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function EventFeed({ events }) {
  const levels = { info: theme.cyan, warning: theme.yellow, error: theme.red, decision: theme.violet };
  return (
    <div style={{ maxHeight: 420, overflowY: 'auto' }}>
      {(events || []).map((e, i) => (
        <div
          key={e.id + '-' + i}
          style={{
            display: 'flex',
            gap: 12,
            padding: '9px 0',
            borderBottom: `1px solid ${theme.border}`,
            animation: i === 0 ? 'feedIn 0.4s ease' : 'none',
          }}
        >
          <span
            style={{
              width: 6,
              height: 6,
              borderRadius: '50%',
              background: levels[e.level] || theme.cyan,
              marginTop: 6,
              flexShrink: 0,
              boxShadow: `0 0 6px ${levels[e.level] || theme.cyan}`,
            }}
          />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 12.5, color: theme.text, wordBreak: 'break-word' }}>{e.message}</div>
            <div style={{ fontSize: 10.5, color: theme.textFaint, marginTop: 2, fontFamily: theme.mono }}>
              {e.agent} · {fmt.ago(e.timestamp)}
            </div>
          </div>
        </div>
      ))}
      {!events?.length && (
        <div style={{ padding: 24, textAlign: 'center', color: theme.textFaint, fontSize: 13 }}>
          Agents are warming up…
        </div>
      )}
    </div>
  );
}

export default function AIEcosystem() {
  const { data: snap } = usePolling('/api/v1/ai/ecosystem', 2000);
  useTicker(1000);
  const metrics = snap?.metrics || {};
  const consciousness = snap?.consciousness || {};
  const agents = snap?.agents || [];

  const coreColor =
    { excellent: theme.green, good: theme.cyan, fair: theme.yellow, monitoring: theme.yellow, critical: theme.red }[
      consciousness.health
    ] || theme.violet;

  return (
    <div>
      <Section
        title="AI Ecosystem"
        subtitle="A live view of the autonomous intelligence layer — agents, signals, decisions and consciousness"
        right={<Badge color={theme.violet} dot>AUTONOMOUS</Badge>}
      />

      <div style={s.grid(180)}>
        <KPI label="Agents Online" value={`${metrics.agents_online || 0}/${metrics.agents_total || 0}`} icon="🤖" accent={theme.violet} sub="Self-managing fleet" />
        <KPI label="Mesh Activity" value={fmt.pct((metrics.mesh_activity || 0) * 100)} icon="📡" accent={theme.cyan} sub="Inter-agent signal" />
        <KPI label="Events / min" value={metrics.events_per_min || 0} icon="⚡" accent={theme.orange} sub={`${metrics.total_events || 0} total`} />
        <KPI label="Decisions / min" value={metrics.decisions_per_min || 0} icon="🎯" accent={theme.green} sub="Autonomous actions" />
        <KPI label="Consciousness" value={(consciousness.level || 'awake').toUpperCase()} icon="🧠" accent={coreColor} sub={`Health ${consciousness.health || '—'}`} />
        <KPI label="Ecosystem Uptime" value={fmt.dur(metrics.uptime)} icon="⏱" accent={theme.blue} sub="Continuous operation" />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr', gap: 14, marginTop: 14 }}>
        <Panel title="Neural Mesh — Live Agent Topology" right={<Badge color={theme.cyan} dot>STREAMING</Badge>}>
          <NeuralMesh snapshot={snap} />
        </Panel>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <Panel title="Consciousness Core" accent={coreColor}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div style={{ ...s.between }}>
                <span style={{ fontSize: 13, color: theme.textDim }}>State of Mind</span>
                <Badge color={coreColor}>{(consciousness.level || 'awake').toUpperCase()}</Badge>
              </div>
              <div>
                <div style={{ ...s.between, fontSize: 12, color: theme.textDim, marginBottom: 6 }}>
                  <span>Stability Index</span>
                  <span style={{ color: theme.text }}>{fmt.pct((consciousness.stability || 0) * 100)}</span>
                </div>
                <HealthBar value={consciousness.stability || 0} />
              </div>
              <div>
                <div style={{ ...s.between, fontSize: 12, color: theme.textDim, marginBottom: 6 }}>
                  <span>Mesh Activity</span>
                  <span style={{ color: theme.text }}>{fmt.pct((consciousness.mesh_activity || 0) * 100)}</span>
                </div>
                <HealthBar value={consciousness.mesh_activity || 0} color={theme.cyan} />
              </div>
              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginTop: 4 }}>
                <Badge color={consciousness.anomalies > 0 ? theme.red : theme.green}>
                  {consciousness.anomalies || 0} anomalies
                </Badge>
                <Badge color={theme.violet}>{agents.length} agents</Badge>
              </div>
            </div>
          </Panel>

          <Panel title="Decision Log" right={<Badge color={theme.textDim}>{snap?.decisions?.length || 0}</Badge>} style={{ flex: 1, maxHeight: 300, overflowY: 'auto' }}>
            {(snap?.decisions || []).slice(0, 8).map((d, i) => (
              <div key={i} style={{ padding: '9px 0', borderBottom: `1px solid ${theme.border}` }}>
                <div style={{ ...s.between }}>
                  <span style={{ fontSize: 12.5, fontWeight: 700, color: theme.violet }}>{d.decision}</span>
                  <span
                    style={{
                      fontSize: 10,
                      fontWeight: 700,
                      color: d.impact === 'positive' ? theme.green : d.impact === 'negative' ? theme.red : theme.textDim,
                    }}
                  >
                    {d.impact.toUpperCase()}
                  </span>
                </div>
                <div style={{ fontSize: 11, color: theme.textDim, marginTop: 3 }}>{d.rationale}</div>
                <div style={{ fontSize: 10, color: theme.textFaint, marginTop: 3, fontFamily: theme.mono }}>
                  {d.agent} · {fmt.ago(d.timestamp)}
                </div>
              </div>
            ))}
            {!snap?.decisions?.length && (
              <div style={{ padding: 20, textAlign: 'center', color: theme.textFaint, fontSize: 12.5 }}>
                No decisions recorded yet. The mesh will log autonomous choices here.
              </div>
            )}
          </Panel>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.3fr 1fr', gap: 14, marginTop: 14 }}>
        <Panel title="Agent Roster" right={<Badge color={theme.violet}>{agents.filter((a) => a.status === 'online').length} online</Badge>}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 12 }}>
            {agents.map((a) => (
              <div
                key={a.id}
                style={{
                  background: theme.panelAlt,
                  border: `1px solid ${theme.border}`,
                  borderLeft: `3px solid ${a.color}`,
                  borderRadius: 10,
                  padding: 14,
                }}
              >
                <div style={{ ...s.between }}>
                  <span style={{ fontSize: 15 }}>
                    {a.icon} <b style={{ fontSize: 13.5 }}>{a.name}</b>
                  </span>
                  <Badge color={a.status === 'online' ? theme.green : theme.red} dot>
                    {a.status}
                  </Badge>
                </div>
                <div style={{ fontSize: 11, color: theme.textFaint, margin: '6px 0 10px' }}>{a.role}</div>
                <HealthBar value={a.health} color={a.color} />
                <div style={{ ...s.between, marginTop: 8, fontSize: 11, color: theme.textDim }}>
                  <span>{a.detail || 'nominal'}</span>
                  <span style={{ fontFamily: theme.mono }}>{a.tasks} tasks</span>
                </div>
                <div style={{ fontSize: 10.5, color: theme.textFaint, marginTop: 6, minHeight: 14, fontStyle: 'italic' }}>
                  {a.last_action}
                </div>
              </div>
            ))}
          </div>
        </Panel>

        <Panel title="Live Activity Stream" right={<Badge color={theme.cyan} dot>LIVE</Badge>}>
          <EventFeed events={snap?.events} />
        </Panel>
      </div>
    </div>
  );
}
