import React, { useState } from 'react';
import { theme, fmt } from '../theme';
import { usePolling, apiPost } from '../api';
import { Panel, KPI, Button, Badge, Toast, Section, DataTable, s } from '../ui';

const MODES = [
  { id: 'performance', label: 'Performance', icon: '🚀', workers: 8, diff: 6, desc: 'Maximum throughput' },
  { id: 'balanced', label: 'Balanced', icon: '⚖️', workers: 4, diff: 4, desc: 'Efficiency / heat balance' },
  { id: 'eco', label: 'Eco', icon: '🌿', workers: 2, diff: 3, desc: 'Low power footprint' },
  { id: 'laptop', label: 'Laptop Safe', icon: '💻', workers: 2, diff: 2, desc: 'Thermal-first profile' },
];

export default function Mining() {
  const { data: stats, reload } = usePolling('/api/v1/stats', 2000);
  const { data: config } = usePolling('/api/v1/config', 8000);
  const { data: stratum } = usePolling('/api/v1/stratum', 5000);
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState(null);
  const [mode, setMode] = useState('balanced');

  const active = (stats?.hash_rate || 0) > 0;

  const notify = (message, type = 'info') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3200);
  };

  const toggle = async () => {
    setBusy(true);
    try {
      if (active) {
        await apiPost('/api/v1/stop');
        notify('Mining stopped · session archived', 'info');
      } else {
        await apiPost('/api/v1/start', { difficulty: config?.default_difficulty || 4 });
        notify('Mining engine engaged · AI systems online', 'success');
      }
      reload();
    } catch (e) {
      notify(`Error: ${e.message}`, 'error');
    }
    setBusy(false);
  };

  const applyMode = async (m) => {
    setMode(m.id);
    try {
      await apiPost('/api/v1/config', { key: 'workers', value: Math.min(m.workers, config?.max_workers || m.workers) });
      await apiPost('/api/v1/config', { key: 'default_difficulty', value: m.diff });
      notify(`Profile applied: ${m.label}`, 'success');
    } catch (e) {
      notify(`Error: ${e.message}`, 'error');
    }
  };

  const rows = stats
    ? [
        { metric: 'Hash Rate', value: fmt.hash(stats.hash_rate), tone: theme.cyan },
        { metric: 'Blocks Found', value: fmt.num(stats.blocks_found), tone: theme.orange },
        { metric: 'Total Hashes', value: fmt.num(stats.total_hashes), tone: theme.text },
        { metric: 'Difficulty', value: stats.current_difficulty, tone: theme.violet },
        { metric: 'Chain Length', value: stats.chain_length, tone: theme.text },
        { metric: 'Shares', value: fmt.num(stats.total_shares), tone: theme.green },
        { metric: 'Acceptance', value: fmt.pct(stats.acceptance_rate), tone: theme.green },
        { metric: 'State', value: stats.state, tone: theme.textDim },
      ]
    : [];

  return (
    <div>
      <Section
        title="Mining Control"
        subtitle="Engage the SHA-256 engine and monitor live throughput"
        right={<Badge color={active ? theme.green : theme.textFaint} dot>{active ? 'RUNNING' : 'STOPPED'}</Badge>}
      />

      <div style={s.grid(190)}>
        <KPI label="Hash Rate" value={fmt.hash(stats?.hash_rate)} icon="⚡" accent={theme.cyan} />
        <KPI label="Blocks" value={fmt.num(stats?.blocks_found)} icon="⛏" accent={theme.orange} />
        <KPI label="Difficulty" value={stats?.current_difficulty ?? '—'} icon="🎚" accent={theme.violet} />
        <KPI label="Workers" value={config?.workers ?? '—'} icon="🧩" accent={theme.blue} />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginTop: 14 }}>
        <Panel title="Engine Control">
          <div style={{ display: 'flex', gap: 12, alignItems: 'center', marginBottom: 18 }}>
            <Button onClick={toggle} variant={active ? 'danger' : 'success'} disabled={busy} style={{ flex: 1, padding: '14px' }}>
              {busy ? 'WORKING…' : active ? '⏹ STOP MINING' : '▶ START MINING'}
            </Button>
          </div>
          <div style={{ fontSize: 12, color: theme.textFaint, marginBottom: 8, letterSpacing: 0.6 }}>OPERATING PROFILE</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            {MODES.map((m) => (
              <button
                key={m.id}
                onClick={() => applyMode(m)}
                style={{
                  textAlign: 'left',
                  padding: '12px 14px',
                  borderRadius: 10,
                  cursor: 'pointer',
                  background: mode === m.id ? theme.orangeSoft : theme.panelAlt,
                  border: `1px solid ${mode === m.id ? theme.orange : theme.border}`,
                  color: theme.text,
                }}
              >
                <div style={{ fontSize: 15 }}>
                  {m.icon} <b style={{ fontSize: 13.5 }}>{m.label}</b>
                </div>
                <div style={{ fontSize: 11, color: theme.textFaint, marginTop: 3 }}>{m.desc}</div>
              </button>
            ))}
          </div>
        </Panel>

        <Panel title="Live Telemetry">
          <DataTable
            columns={[
              { key: 'metric', label: 'Metric' },
              { key: 'value', label: 'Value', align: 'right', mono: true },
            ]}
            rows={rows}
            empty="Engine idle"
            renderCell={(r, c) => <span style={{ color: c.key === 'value' ? r.tone : theme.textDim }}>{r[c.key]}</span>}
          />
        </Panel>
      </div>

      <div style={{ marginTop: 14 }}>
        <Panel title="Stratum Server (ASIC / GPU)" right={<Badge color={stratum?.active_clients ? theme.green : theme.textFaint}>{stratum?.active_clients || 0} clients</Badge>}>
          <div style={s.grid(180)}>
            <KPI label="V1 Port" value={stratum?.port || 3333} accent={theme.cyan} />
            <KPI label="Difficulty" value={stratum?.difficulty ?? '—'} accent={theme.violet} />
            <KPI label="Active Clients" value={stratum?.active_clients ?? 0} accent={theme.green} />
            <KPI label="Status" value={stratum?.host ? 'LISTENING' : 'OFFLINE'} accent={stratum?.host ? theme.green : theme.red} />
          </div>
        </Panel>
      </div>

      <Toast message={toast?.message} type={toast?.type} onClose={() => setToast(null)} />
    </div>
  );
}
