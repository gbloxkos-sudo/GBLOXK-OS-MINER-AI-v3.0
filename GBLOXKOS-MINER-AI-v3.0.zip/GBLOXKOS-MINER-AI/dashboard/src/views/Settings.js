import React, { useState } from 'react';
import { theme } from '../theme';
import { usePolling, apiPost } from '../api';
import { Panel, Button, Badge, Toast, Section, s } from '../ui';

const GROUPS = [
  {
    title: 'Mining Engine',
    fields: [
      { key: 'workers', label: 'Workers', type: 'number', min: 1, max: 32 },
      { key: 'max_workers', label: 'Max Workers', type: 'number', min: 1, max: 64 },
      { key: 'default_difficulty', label: 'Default Difficulty', type: 'number', min: 1, max: 8 },
      { key: 'max_nonce', label: 'Max Nonce', type: 'number', min: 1000, step: 1000 },
      { key: 'block_reward', label: 'Block Reward (BTC)', type: 'number', min: 0, step: 0.001 },
    ],
  },
  {
    title: 'AI & Autonomy',
    fields: [
      { key: 'ollama_model', label: 'AI Model', type: 'text' },
      { key: 'ollama_host', label: 'Ollama Host', type: 'text' },
      { key: 'auto_tune_ai', label: 'AI Auto-Tuning', type: 'bool' },
      { key: 'auto_throttle', label: 'Auto Throttle', type: 'bool' },
    ],
  },
  {
    title: 'Real Mining',
    fields: [
      { key: 'real_mining', label: 'Real Pool Mining', type: 'bool' },
      { key: 'default_pool', label: 'Default Pool', type: 'text' },
      { key: 'default_worker', label: 'Worker Name', type: 'text' },
    ],
  },
  {
    title: 'System',
    fields: [
      { key: 'air_gapped', label: 'Air-Gapped Mode', type: 'bool' },
      { key: 'low_memory_mode', label: 'Low Memory Mode', type: 'bool' },
      { key: 'log_level', label: 'Log Level', type: 'select', options: ['DEBUG', 'INFO', 'WARNING', 'ERROR'] },
    ],
  },
];

export default function Settings() {
  const { data: config, reload } = usePolling('/api/v1/config', 8000);
  const [draft, setDraft] = useState(null);
  const [toast, setToast] = useState(null);

  React.useEffect(() => {
    if (config && !draft) setDraft({ ...config });
  }, [config, draft]);

  const notify = (message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  const set = (key, value) => setDraft((d) => ({ ...(d || {}), [key]: value }));

  const save = async () => {
    if (!draft || !config) return;
    try {
      for (const g of GROUPS) {
        for (const f of g.fields) {
          if (draft[f.key] !== undefined && draft[f.key] !== config[f.key]) {
            await apiPost('/api/v1/config', { key: f.key, value: draft[f.key] });
          }
        }
      }
      notify('Configuration saved · applied live');
      reload();
    } catch (e) {
      notify(`Save failed: ${e.message}`, 'error');
    }
  };

  if (!config || !draft) {
    return (
      <div style={{ padding: 40, textAlign: 'center', color: theme.textFaint }}>
        Loading configuration…
      </div>
    );
  }

  const dirty = GROUPS.some((g) => g.fields.some((f) => draft[f.key] !== config[f.key]));

  const inputStyle = {
    padding: '9px 12px', borderRadius: 8, border: `1px solid ${theme.border}`,
    background: theme.bgAlt, color: theme.text, fontSize: 13, fontFamily: theme.mono,
    outline: 'none', width: 190,
  };

  return (
    <div>
      <Section
        title="Settings"
        subtitle="Live system configuration — applied without restart"
        right={<Badge color={dirty ? theme.yellow : theme.green}>{dirty ? 'UNSAVED CHANGES' : 'IN SYNC'}</Badge>}
      />

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: 14 }}>
        {GROUPS.map((g) => (
          <Panel key={g.title} title={g.title}>
            {g.fields.map((f) => (
              <div key={f.key} style={{ ...s.between, padding: '10px 0', borderBottom: `1px solid ${theme.border}` }}>
                <div>
                  <div style={{ fontSize: 13, color: theme.text }}>{f.label}</div>
                  <div style={{ fontSize: 10.5, color: theme.textFaint, fontFamily: theme.mono, marginTop: 2 }}>{f.key}</div>
                </div>
                <div>
                  {f.type === 'bool' ? (
                    <button
                      onClick={() => set(f.key, !draft[f.key])}
                      style={{
                        width: 46, height: 24, borderRadius: 14, border: 'none', cursor: 'pointer',
                        background: draft[f.key] ? theme.green : 'rgba(148,163,184,0.25)',
                        position: 'relative', transition: 'background 0.2s',
                      }}
                    >
                      <span
                        style={{
                          position: 'absolute', top: 3, left: draft[f.key] ? 25 : 3, width: 18, height: 18,
                          borderRadius: '50%', background: draft[f.key] ? '#06231a' : theme.textDim,
                          transition: 'left 0.2s',
                        }}
                      />
                    </button>
                  ) : f.type === 'select' ? (
                    <select value={draft[f.key]} onChange={(e) => set(f.key, e.target.value)} style={inputStyle}>
                      {f.options.map((o) => (
                        <option key={o} value={o} style={{ background: theme.bgAlt }}>
                          {o}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <input
                      type={f.type}
                      value={draft[f.key] ?? ''}
                      min={f.min}
                      step={f.step}
                      onChange={(e) => set(f.key, f.type === 'number' ? Number(e.target.value) : e.target.value)}
                      style={inputStyle}
                    />
                  )}
                </div>
              </div>
            ))}
          </Panel>
        ))}
      </div>

      <div style={{ marginTop: 18, display: 'flex', gap: 12 }}>
        <Button onClick={save} disabled={!dirty}>💾 SAVE CONFIGURATION</Button>
        <Button variant="ghost" onClick={() => setDraft({ ...config })} disabled={!dirty}>
          ↺ RESET
        </Button>
      </div>

      <Toast message={toast?.message} type={toast?.type} onClose={() => setToast(null)} />
    </div>
  );
}
