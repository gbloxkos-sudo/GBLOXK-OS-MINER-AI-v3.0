export const theme = {
  bg: '#070b12',
  bgAlt: '#0b1220',
  panel: '#0f172a',
  panelAlt: '#131f36',
  panelHover: '#16233d',
  border: 'rgba(148, 163, 184, 0.14)',
  borderStrong: 'rgba(148, 163, 184, 0.28)',
  text: '#e8eefc',
  textDim: '#94a3b8',
  textFaint: '#5b6b82',
  orange: '#f7931a',
  orangeSoft: 'rgba(247, 147, 26, 0.14)',
  green: '#10b981',
  greenSoft: 'rgba(16, 185, 129, 0.14)',
  red: '#f43f5e',
  redSoft: 'rgba(244, 63, 94, 0.14)',
  cyan: '#22d3ee',
  cyanSoft: 'rgba(34, 211, 238, 0.14)',
  violet: '#a855f7',
  violetSoft: 'rgba(168, 85, 247, 0.14)',
  yellow: '#eab308',
  yellowSoft: 'rgba(234, 179, 8, 0.14)',
  blue: '#3b82f6',
  blueSoft: 'rgba(59, 130, 246, 0.14)',
  radius: 12,
  radiusSm: 8,
  mono: "'JetBrains Mono', 'SFMono-Regular', Menlo, Consolas, monospace",
};

export const fmt = {
  num: (n, d = 0) =>
    n === null || n === undefined || Number.isNaN(Number(n))
      ? '—'
      : Number(n).toLocaleString(undefined, { minimumFractionDigits: d, maximumFractionDigits: d }),
  usd: (n, d = 2) =>
    n === null || n === undefined || Number.isNaN(Number(n)) ? '—' : `$${Number(n).toLocaleString(undefined, { minimumFractionDigits: d, maximumFractionDigits: d })}`,
  btc: (n) => (n === null || n === undefined ? '—' : Number(n).toFixed(8)),
  sats: (n) => (n === null || n === undefined ? '—' : `${Number(n).toLocaleString()} sats`),
  pct: (n, d = 1) => (n === null || n === undefined ? '—' : `${Number(n).toFixed(d)}%`),
  hash: (h) => {
    if (!h || h <= 0) return '0 H/s';
    const units = ['H/s', 'KH/s', 'MH/s', 'GH/s', 'TH/s', 'PH/s'];
    let i = 0;
    let v = h;
    while (v >= 1000 && i < units.length - 1) {
      v /= 1000;
      i += 1;
    }
    return `${v.toFixed(2)} ${units[i]}`;
  },
  dur: (s) => {
    if (!s || s < 0) return '0s';
    const d = Math.floor(s / 86400);
    const h = Math.floor((s % 86400) / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = Math.floor(s % 60);
    if (d) return `${d}d ${h}h`;
    if (h) return `${h}h ${m}m`;
    if (m) return `${m}m ${sec}s`;
    return `${sec}s`;
  },
  ago: (t) => {
    const s = Math.max(0, Math.floor(Date.now() / 1000 - t));
    if (s < 60) return `${s}s ago`;
    if (s < 3600) return `${Math.floor(s / 60)}m ago`;
    if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
    return `${Math.floor(s / 86400)}d ago`;
  },
  clock: (t) => (t ? new Date(t * 1000).toLocaleTimeString() : '—'),
};
