import getpass
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from database.storage import DatabaseManager

console = Console()


def interactive_login(db: DatabaseManager) -> int:
    while True:
        console.clear()
        console.print()
        console.print(Panel.fit(
            "[bold cyan]⛏ GBLOXK OS · MINER AI[/] [white]v3.0[/]\n"
            "[dim]Autonomous AI Mining Operating System[/]\n"
            "[dim]Self-Healing | Self-Learning | Self-Awareness | Auto-Payout[/]\n"
            "[dim]Stratum V2 | Multi-Coin | REST API | Web Dashboard[/]",
            border_style="cyan"
        ))
        console.print()
        console.print("[cyan]Authentication Required[/]")
        console.print()

        choice = Prompt.ask(
            "[bold]Select option[/]",
            choices=["login", "register", "exit"],
            default="login"
        )

        if choice == "exit":
            console.print("[yellow]Goodbye. Mine on.[/]")
            return None

        if choice == "register":
            console.print("\n[bold]📝 Create New Account[/]")
            username = Prompt.ask("[cyan]Username[/]")
            if not username or len(username) < 2:
                console.print("[red]❌ Username must be 2+ characters[/]")
                continue
            email = Prompt.ask("[cyan]Email (optional)[/]", default="")
            password = getpass.getpass("[cyan]Password[/]: ")
            confirm = getpass.getpass("[cyan]Confirm password[/]: ")

            if password != confirm:
                console.print("[red]❌ Passwords do not match[/]")
                continue
            if len(password) < 4:
                console.print("[red]❌ Password must be 4+ characters[/]")
                continue

            if db.register_user(username, password, email):
                console.print(f"[green]✅ Account created! Welcome, {username}. Please login.[/]")
            else:
                console.print("[red]❌ Username already exists[/]")
                continue

        if choice == "login":
            console.print("\n[bold]🔑 Login[/]")
            username = Prompt.ask("[cyan]Username[/]")
            password = getpass.getpass("[cyan]Password[/]: ")

            uid = db.authenticate_user(username, password)
            if uid:
                console.print(f"[green]✅ Authenticated. Welcome back, {username}![/]")
                return uid
            else:
                console.print("[red]❌ Invalid username or password[/]")
                retry = Prompt.ask("[yellow]Try again?[/]", choices=["y", "n"], default="y")
                if retry.lower() != "y":
                    return None
