from cli.__main__ import cli, load_app, authenticate, console
import click
import time
import threading
from rich.live import Live
from rich.layout import Layout
from rich.table import Table
from rich.text import Text
from rich.panel import Panel
from rich import box
from rich.align import Align

from config import AppConfig
from database.storage import DatabaseManager
from utils.helpers import format_hash_rate, format_duration
from ai.profitability import fetch_btc_price

MINING_SESSION = {"orchestrator": None, "thread": None, "running": False}
STRATUM_SERVER = None
API_SERVER = None
POOL_CLIENT = None
AUTO_REAL = None


@cli.command()
@click.option("--daemon", is_flag=True, help="Run in background")
@click.option("--solo", is_flag=True, help="Use solo/educational mining instead of real pool")
def start(daemon, solo):
    """Start automated AI mining (real pool by default)"""
    cfg, db = load_app()
    uid = authenticate(db)
    if not uid:
        return
    if MINING_SESSION["running"]:
        console.print("[yellow]⚠ Mining already running[/]")
        return
    if solo:
        cfg.real_mining = False

    from mining.orchestrator import MiningOrchestrator
    orch = MiningOrchestrator(cfg, db, uid)
    MINING_SESSION["orchestrator"] = orch
    MINING_SESSION["running"] = True
    try:
        btc_price = fetch_btc_price()
    except:
        btc_price = 0

    if solo or not cfg.real_mining:
        mode_name = "SOLO (Educational)"
        pool_info = ""
    else:
        from mining.pool_client import KNOWN_POOLS
        pool_host = KNOWN_POOLS.get(cfg.default_pool, {}).get("host", cfg.default_pool)
        mode_name = f"REAL ({cfg.default_pool})"
        pool_info = f"  🌐 [white]Pool[/]         : {pool_host}:{KNOWN_POOLS.get(cfg.default_pool,{}).get('port',3333)}\n"

    console.print(Panel.fit(
        "[bold green]⛏ GBLOXK OS · MINER AI — Starting[/]\n\n"
        f"  ⛏ [cyan]Mode[/]          : {mode_name}\n"
        f"{pool_info}"
        "  🤖 [cyan]AI Advisor[/]     : Online\n"
        "  🩹 [green]Self-Healing[/]   : Active\n"
        "  📚 [yellow]Self-Learning[/]  : Active\n"
        "  🧠 [magenta]Self-Awareness[/] : Active\n"
        "  💲 [white]BTC Price[/]      : ${}\n"
        "  🔧 [white]Workers[/]       : {}\n"
        "  💰 [green]Wallet[/]        : Active - earnings credited automatically".format(
            f"{btc_price:,.0f}" if btc_price else "offline",
            cfg.workers
        ),
        border_style="green"
    ))
    def run_mining():
        orch.start()
        try:
            while MINING_SESSION["running"]:
                time.sleep(1)
        except KeyboardInterrupt:
            pass
        finally:
            orch.stop()
            MINING_SESSION["running"] = False
    thread = threading.Thread(target=run_mining, daemon=True)
    MINING_SESSION["thread"] = thread
    thread.start()
    if not daemon:
        console.print("[dim]Mining started in background. Use 'gbloxk-os monitor' to view.[/]")
        console.print("[dim]Use 'gbloxk-os stop' to stop mining.[/]")
        console.print("[dim]Press Ctrl+C to return to shell (mining continues in background).[/]")
        try:
            while MINING_SESSION["running"]:
                time.sleep(1)
        except KeyboardInterrupt:
            console.print("\n[yellow]Mining running in background. Use 'gbloxk-os stop' to end.[/]")


@cli.command()
def stop():
    """Stop mining"""
    if not MINING_SESSION["running"] or not MINING_SESSION["orchestrator"]:
        console.print("[yellow]⚠ No active mining session[/]")
        return
    console.print("[yellow]⏹ Stopping mining...[/]")
    MINING_SESSION["orchestrator"].stop()
    MINING_SESSION["running"] = False
    MINING_SESSION["orchestrator"] = None
    console.print("[green]✅ Mining stopped[/]")


@cli.command()
def status():
    """Show mining status & AI self-report"""
    cfg, db = load_app()
    if MINING_SESSION["orchestrator"]:
        orch = MINING_SESSION["orchestrator"]
        stats = orch.get_stats()
        profile = orch.get_resource_profile()
        self_status = orch.get_self_status()
        table = Table(box=box.ROUNDED, title="⛏ Mining Status", border_style="cyan")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="white")
        table.add_row("Status", "[green]● Active[/]" if stats.get("hash_rate", 0) > 0 else "[yellow]● Idle[/]")
        table.add_row("Hash Rate", format_hash_rate(stats.get("hash_rate", 0)))
        table.add_row("Blocks Found", str(stats.get("blocks_found", 0)))
        table.add_row("Difficulty", str(stats.get("current_difficulty", 4)))
        table.add_row("Chain Length", str(stats.get("chain_length", 0)))
        table.add_row("Total Hashes", f"{stats.get('total_hashes', 0):,}")
        table.add_row("Uptime", format_duration(stats.get("elapsed", 0)))
        try:
            table.add_row("BTC Price", f"${fetch_btc_price():,.0f}")
        except:
            table.add_row("BTC Price", "N/A")
        table.add_row("Active Workers", str(orch.worker.engine.workers) if orch.worker else "0")
        if profile:
            table.add_row("CPU Usage", f"{profile.cpu_percent:.1f}%")
            table.add_row("Memory Usage", f"{profile.memory_percent:.1f}%")
            if profile.temperature:
                color = "green" if profile.temperature < 65 else ("yellow" if profile.temperature < 75 else "red")
                table.add_row("Temperature", f"[{color}]{profile.temperature:.1f}°C[/]")
        console.print(table)
        if self_status:
            aw = self_status.get("awareness", {})
            table2 = Table(box=box.ROUNDED, title="🧠 AI Self-* Status", border_style="magenta")
            table2.add_column("System", style="magenta")
            table2.add_column("Status", style="white")
            table2.add_row("Health", f"[green]{aw.get('health', 'unknown').upper()}[/]")
            table2.add_row("Stability", f"{aw.get('stability', 0)*100:.1f}%")
            table2.add_row("Consciousness", f"[cyan]{aw.get('consciousness', 'unknown').upper()}[/]")
            learning_data = self_status.get("learning", {})
            table2.add_row("Learning Records", str(learning_data.get("records_count", 0)))
            healing_data = self_status.get("healing", {})
            table2.add_row("Auto-Heals", str(healing_data.get("total_incidents", 0)))
            table2.add_row("Anomalies", str(aw.get("anomalies", 0)))
            console.print(table2)
            report = self_status.get("consciousness", "")
            if report:
                console.print(Panel(report, border_style="cyan", title="🧠 Self-Awareness Report"))
    else:
        uid = authenticate(db)
        if uid:
            sessions = db.get_session_history(uid)
            if sessions:
                table = Table(box=box.ROUNDED, title="📜 Last Sessions", border_style="cyan")
                table.add_column("Date", style="cyan")
                table.add_column("Duration", style="white")
                table.add_column("Blocks", style="green")
                table.add_column("Hash Rate", style="yellow")
                for s in sessions[:10]:
                    dur = format_duration((s.get("end_time") or time.time()) - s["start_time"])
                    table.add_row(
                        time.strftime("%Y-%m-%d %H:%M", time.localtime(s["start_time"])),
                        dur, str(s["blocks_found"]), format_hash_rate(s["avg_hash_rate"]),
                    )
                console.print(table)
            else:
                console.print("[yellow]No mining history found. Start mining with 'gbloxk-os start'[/]")
    if MINING_SESSION["orchestrator"]:
        profit = MINING_SESSION["orchestrator"].get_profitability()
        profit_table = Table(box=box.ROUNDED, title="💰 Profitability", border_style="green")
        profit_table.add_column("Metric", style="green")
        profit_table.add_column("Value", style="white")
        profit_table.add_row("Daily BTC", f"{profit.get('daily_btc', 0):.8f}")
        profit_table.add_row("Daily Revenue", f"${profit.get('daily_revenue_usd', 0):.4f}")
        profit_table.add_row("Daily Profit", f"${profit.get('daily_profit_usd', 0):.4f}")
        profit_table.add_row("Monthly Profit", f"${profit.get('monthly_profit_usd', 0):.2f}")
        console.print(profit_table)


@cli.command()
@click.option("--refresh", default=1, help="Refresh interval in seconds")
def monitor(refresh):
    """Real-time monitoring dashboard (like htop)"""
    cfg, db = load_app()
    if not MINING_SESSION["running"] or not MINING_SESSION["orchestrator"]:
        console.print("[yellow]⚠ No active mining session. Start with 'gbloxk-os start'[/]")
        return
    orch = MINING_SESSION["orchestrator"]
    def generate_layout():
        layout = Layout()
        layout.split(Layout(name="header", size=3), Layout(name="body"), Layout(name="footer", size=3))
        layout["body"].split_row(Layout(name="stats"), Layout(name="right"))
        layout["right"].split(Layout(name="resources"), Layout(name="self"))
        return layout
    layout = generate_layout()
    with Live(layout, refresh_per_second=1 / refresh, screen=True):
        try:
            while MINING_SESSION["running"]:
                stats = orch.get_stats()
                profile = orch.get_resource_profile()
                self_status = orch.get_self_status()
                header = Panel(Align.center(Text(
                    "⛏ GBLOXK OS · MINER AI v3.0  |  AI: Online  |  Self-Healing ✓  Self-Learning ✓  Self-Awareness ✓  Auto-Payout ✓",
                    style="bold cyan")), border_style="cyan")
                layout["header"].update(header)
                stat_table = Table(box=box.SIMPLE, show_header=False, border_style="dim")
                stat_table.add_column(); stat_table.add_column()
                stat_table.add_row("[cyan]Hash Rate[/]", f"[bold white]{format_hash_rate(stats.get('hash_rate', 0))}[/]")
                stat_table.add_row("[cyan]Blocks Found[/]", f"[green]{stats.get('blocks_found', 0)}[/]")
                stat_table.add_row("[cyan]Difficulty[/]", f"[yellow]{stats.get('current_difficulty', 4)}[/]")
                stat_table.add_row("[cyan]Total Hashes[/]", f"{stats.get('total_hashes', 0):,}")
                stat_table.add_row("[cyan]Uptime[/]", format_duration(stats.get("elapsed", 0)))
                try:
                    btc_price = fetch_btc_price()
                    stat_table.add_row("[cyan]BTC Price[/]", f"[bold green]${btc_price:,.0f}[/]")
                except:
                    pass
                stat_table.add_row("[cyan]Chain Length[/]", str(stats.get("chain_length", 0)))
                stat_table.add_row("[cyan]Shares[/]", str(stats.get("total_shares", 0)))
                stat_table.add_row("[cyan]Acceptance[/]", f"{stats.get('acceptance_rate', 100):.1f}%")
                if orch.worker:
                    stat_table.add_row("[cyan]Workers[/]", f"[magenta]{orch.worker.engine.workers}[/]")
                profit = orch.get_profitability()
                stat_table.add_row("", "")
                stat_table.add_row("[green]Daily Profit[/]", f"[bold green]${profit.get('daily_profit_usd', 0):.4f}[/]")
                stat_table.add_row("[green]Monthly Profit[/]", f"[bold green]${profit.get('monthly_profit_usd', 0):.2f}[/]")
                layout["stats"].update(Panel(stat_table, title="📊 Mining Stats", border_style="cyan"))
                res_table = Table(box=box.SIMPLE, show_header=False, border_style="dim")
                res_table.add_column(); res_table.add_column()
                if profile:
                    cpu_color = "green" if profile.cpu_percent < 50 else ("yellow" if profile.cpu_percent < 75 else "red")
                    mem_color = "green" if profile.memory_percent < 50 else ("yellow" if profile.memory_percent < 75 else "red")
                    res_table.add_row("[cyan]CPU[/]", f"[{cpu_color}]{profile.cpu_percent:.1f}%[/]")
                    res_table.add_row("[cyan]RAM[/]", f"[{mem_color}]{profile.memory_percent:.1f}%[/]")
                    if profile.temperature:
                        t = profile.temperature
                        t_color = "green" if t < 60 else ("yellow" if t < 75 else "red")
                        res_table.add_row("[cyan]Temp[/]", f"[{t_color}]{t:.1f}°C[/]")
                    res_table.add_row("[cyan]RAM Avail[/]", f"{profile.memory_available_gb:.1f} GB")
                    res_table.add_row("[cyan]Cores[/]", f"{profile.cores_logical}L / {profile.cores_physical}P")
                    res_table.add_row("[cyan]OOM Risk[/]", orch.monitor.get_oom_risk(profile))
                layout["resources"].update(Panel(res_table, title="💻 System Resources", border_style="green"))
                self_table = Table(box=box.SIMPLE, show_header=False, border_style="dim")
                self_table.add_column(); self_table.add_column()
                aw = self_status.get("awareness", {})
                health_color = {"excellent": "green", "good": "cyan", "fair": "yellow",
                                "monitoring": "yellow", "critical": "red"}.get(aw.get("health", "unknown"), "white")
                self_table.add_row("[magenta]Health[/]", f"[{health_color}]{aw.get('health', 'unknown').upper()}[/]")
                self_table.add_row("[magenta]Stability[/]", f"{aw.get('stability', 0)*100:.1f}%")
                self_table.add_row("[magenta]Consciousness[/]", f"[cyan]{aw.get('consciousness', 'unknown').upper()}[/]")
                anom_count = aw.get("anomalies", 0)
                self_table.add_row("[magenta]Anomalies[/]", f"[{'red' if anom_count>0 else 'green'}]{anom_count}[/]")
                healing_data = self_status.get("healing", {})
                self_table.add_row("[magenta]Auto-Heals[/]", str(healing_data.get("total_incidents", 0)))
                learning_data = self_status.get("learning", {})
                self_table.add_row("[magenta]Patterns[/]", str(learning_data.get("patterns_found", 0)))
                self_table.add_row("[magenta]Records[/]", str(learning_data.get("records_count", 0)))
                layout["self"].update(Panel(self_table, title="🧠 AI Self-*", border_style="magenta"))
                insights = learning_data.get("insights", "")
                layout["footer"].update(Panel(f"🤖 AI: {aw.get('health', 'unknown')} | {insights[:80] if insights else ''}", border_style="dim"))
                time.sleep(refresh)
        except KeyboardInterrupt:
            pass


@cli.command()
@click.option("--get", "show_key", help="Show specific config value")
@click.option("--set", "set_pair", nargs=2, help="Set config key value")
def config(show_key, set_pair):
    """View/change configuration"""
    cfg = AppConfig.load()
    if set_pair:
        key, value = set_pair
        if hasattr(cfg, key):
            current = getattr(cfg, key)
            try:
                if isinstance(current, bool):
                    setattr(cfg, key, value.lower() == "true")
                elif isinstance(current, int):
                    setattr(cfg, key, int(value))
                elif isinstance(current, float):
                    setattr(cfg, key, float(value))
                else:
                    setattr(cfg, key, value)
                cfg.save()
                console.print(f"[green]✅ {key}[/] set to [white]{getattr(cfg, key)}[/]")
            except ValueError:
                console.print("[red]Invalid value type[/]")
            return
        console.print(f"[red]Unknown config key: {key}[/]")
        return
    if show_key:
        if hasattr(cfg, show_key):
            console.print(f"[cyan]{show_key}[/] = [white]{getattr(cfg, show_key)}[/]")
            return
        console.print(f"[red]Unknown config key: {show_key}[/]")
        return
    table = Table(box=box.ROUNDED, title="⚙ Configuration", border_style="cyan")
    table.add_column("Key", style="cyan"); table.add_column("Value", style="white"); table.add_column("Type", style="dim")
    for field in cfg.__dataclass_fields__:
        table.add_row(field, str(getattr(cfg, field)), type(getattr(cfg, field)).__name__)
    console.print(table)


@cli.command()
@click.argument("question", nargs=-1)
def ai(question):
    """Ask the AI advisor a question"""
    cfg, db = load_app()
    if MINING_SESSION.get("orchestrator"):
        orch = MINING_SESSION["orchestrator"]
    else:
        uid = authenticate(db)
        if not uid:
            return
        from mining.orchestrator import MiningOrchestrator
        orch = MiningOrchestrator(cfg, db, uid)
    if question:
        q = " ".join(question)
        with console.status("[cyan]Consulting AI advisor...[/]"):
            response = orch.ai_chat(q)
        console.print(Panel(response, border_style="cyan", title="🤖 AI Advisor"))
    else:
        with console.status("[cyan]Analyzing mining performance...[/]"):
            response = orch.ai_analyze()
        console.print(Panel(response, border_style="cyan", title="🤖 AI Analysis"))
    if not MINING_SESSION.get("orchestrator"):
        orch.stop()


@cli.command()
@click.option("--hashrate", default=1000, help="Hash rate in H/s")
@click.option("--power", default=65, help="Power consumption in watts")
@click.option("--elec-cost", default=0.12, help="Electricity cost $/kWh")
@click.option("--pool-fee", default=2.0, help="Pool fee in percent")
@click.option("--reward", default=None, help="Block reward in BTC")
def profit(hashrate, power, elec_cost, pool_fee, reward):
    """Profitability calculator"""
    from ai.profitability import ProfitabilityCalculator
    cfg = AppConfig.load()
    if reward:
        cfg.block_reward = reward
    calc = ProfitabilityCalculator(cfg)
    result = calc.calculate(hashrate, power, elec_cost, pool_fee / 100)
    table = Table(box=box.ROUNDED, title=f"💰 Profitability @ {format_hash_rate(hashrate)}", border_style="green")
    table.add_column("Metric", style="green"); table.add_column("Value", style="white")
    table.add_row("BTC Price", f"${result['btc_price']:,.0f}")
    table.add_row("Daily BTC", f"{result['daily_btc']:.8f} BTC")
    table.add_row("Daily Revenue", f"${result['daily_revenue_usd']:.4f}")
    table.add_row("Daily Power Cost", f"${result['daily_power_cost']:.4f}")
    table.add_row("Daily Profit", f"[bold]${result['daily_profit_usd']:.4f}[/]")
    table.add_row("Monthly Profit", f"[bold green]${result['monthly_profit_usd']:.2f}[/]")
    table.add_row("Yearly Profit", f"[bold green]${result['yearly_profit_usd']:.2f}[/]")
    table.add_row("ROI", f"{result['roi_percent']:.1f}%")
    days = result.get("days_to_1btc", float("inf"))
    table.add_row("Days to 1 BTC", f"{days:.0f}" if days != float("inf") else "∞")
    console.print(table)


@cli.command()
def self():
    """Show AI self-* system status"""
    if not MINING_SESSION["running"] or not MINING_SESSION["orchestrator"]:
        console.print("[yellow]⚠ No active mining session. Start with 'gbloxk-os start'[/]")
        return
    orch = MINING_SESSION["orchestrator"]
    self_status = orch.get_self_status()
    aw = self_status.get("awareness", {})
    health_color = {"excellent": "green", "good": "cyan", "fair": "yellow",
                    "monitoring": "yellow", "critical": "red"}.get(aw.get("health", "unknown"), "white")
    table = Table(box=box.ROUNDED, title="🧠 AI Self-* System", border_style="magenta")
    table.add_column("Component", style="magenta"); table.add_column("Status", style="white")
    table.add_row("🧠 Self-Awareness", f"[{health_color}]{aw.get('health', 'unknown').upper()}[/]")
    table.add_row("  ├ Consciousness", f"[cyan]{aw.get('consciousness', 'unknown').upper()}[/]")
    table.add_row("  ├ Stability", f"{aw.get('stability', 0)*100:.1f}%")
    table.add_row("  ├ Performance", aw.get("performance", "unknown"))
    table.add_row("  └ Anomalies", f"[{'red' if aw.get('anomalies',0)>0 else 'green'}]{aw.get('anomalies', 0)}[/]")
    learning_data = self_status.get("learning", {})
    table.add_row("📚 Self-Learning", f"[cyan]{'Active' if learning_data.get('enabled') else 'Inactive'}[/]")
    table.add_row("  ├ Records", str(learning_data.get("records_count", 0)))
    table.add_row("  ├ Patterns", str(learning_data.get("patterns_found", 0)))
    table.add_row("  └ Insights", str(learning_data.get("insights", "N/A"))[:60])
    healing_data = self_status.get("healing", {})
    table.add_row("🩹 Self-Healing", f"[cyan]{'Active' if healing_data.get('enabled') else 'Inactive'}[/]")
    table.add_row("  └ Incidents", str(healing_data.get("total_incidents", 0)))
    console.print(table)
    report = self_status.get("consciousness", "")
    if report:
        console.print(Panel(report, border_style="cyan", title="🧠 Full Consciousness Report"))


@cli.command()
def analyze():
    """Run AI performance analysis with self-* insights"""
    cfg, db = load_app()
    if MINING_SESSION.get("orchestrator"):
        orch = MINING_SESSION["orchestrator"]
    else:
        uid = authenticate(db)
        if not uid:
            return
        from mining.orchestrator import MiningOrchestrator
        orch = MiningOrchestrator(cfg, db, uid)
    with console.status("[cyan]Running comprehensive AI analysis..."):
        response = orch.ai_analyze()
    console.print(Panel(response, border_style="cyan", title="📊 AI Performance Analysis"))
    if not MINING_SESSION.get("orchestrator"):
        orch.stop()


@cli.command()
def history():
    """View mining session history"""
    cfg, db = load_app()
    uid = authenticate(db)
    if not uid:
        return
    sessions = db.get_session_history(uid)
    if not sessions:
        console.print("[yellow]No mining history found[/]")
        return
    table = Table(box=box.ROUNDED, title="📜 Mining Session History", border_style="cyan")
    table.add_column("Date", style="cyan"); table.add_column("Duration", style="white")
    table.add_column("Difficulty", style="yellow"); table.add_column("Blocks", style="green")
    table.add_column("Total Hashes", style="white"); table.add_column("Avg Hash Rate", style="magenta")
    table.add_column("Status", style="white")
    for s in sessions[:20]:
        start = s["start_time"]
        end = s.get("end_time") or time.time()
        dur = format_duration(end - start)
        table.add_row(
            time.strftime("%Y-%m-%d %H:%M", time.localtime(start)),
            dur, str(s.get("difficulty_level", 4)), str(s.get("blocks_found", 0)),
            f"{s.get('total_hashes', 0):,}", format_hash_rate(s.get("avg_hash_rate", 0)),
            f"[green]{s.get('status', 'completed')}[/]",
        )
    console.print(table)


@cli.command()
@click.argument("message", nargs=-1, required=True)
def feedback(message):
    """Submit feedback"""
    cfg, db = load_app()
    uid = authenticate(db)
    if not uid:
        return
    msg = " ".join(message)
    db.save_feedback(uid, msg, 5)
    console.print("[green]✅ Feedback submitted. Thank you![/]")


@cli.command()
@click.option("--port", default=8765, help="API server port")
@click.option("--host", default="127.0.0.1", help="API server host")
@click.option("--stop", "do_stop", is_flag=True, help="Stop the API server")
def api(port, host, do_stop):
    """Start/stop the REST API server (FastAPI)"""
    global API_SERVER
    if do_stop:
        if API_SERVER:
            try:
                from api.server import stop_api
                stop_api()
                API_SERVER = None
                console.print("[green]✅ API server stopped[/]")
            except Exception as e:
                console.print(f"[red]Error stopping API: {e}[/]")
        else:
            console.print("[yellow]⚠ No API server running[/]")
        return
    if API_SERVER:
        console.print("[yellow]⚠ API server already running[/]")
        return
    try:
        import importlib.util
        if importlib.util.find_spec("fastapi") is None or importlib.util.find_spec("uvicorn") is None:
            raise ImportError
    except ImportError:
        console.print("[red]FastAPI not installed. Run: pip install fastapi uvicorn[/]")
        return
    cfg, db = load_app()
    uid = authenticate(db)
    if not uid:
        return
    from mining.orchestrator import MiningOrchestrator
    orch = MiningOrchestrator(cfg, db, uid)
    MINING_SESSION["orchestrator"] = orch
    MINING_SESSION["running"] = True
    orch.start()
    try:
        from api.server import start_api
        API_SERVER = start_api(orch, host, port)
        console.print(f"[green]✅ API server running at http://{host}:{port}[/]")
        console.print("[dim]Endpoints: /health, /api/v1/stats, /api/v1/start, /api/v1/stop, /api/v1/config, /api/v1/profitability, /api/v1/self, /api/v1/coins, /api/v1/stratum, /api/v1/wallet, /api/v1/history[/]")
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        if API_SERVER:
            API_SERVER.stop()
            API_SERVER = None
        orch.stop()
        MINING_SESSION["running"] = False


@cli.command()
@click.option("--port", default=3333, help="Stratum V1 port")
@click.option("--v2-port", default=3334, help="Stratum V2 port")
@click.option("--difficulty", default=1.0, help="Mining difficulty for connected miners")
@click.option("--stop", "do_stop", is_flag=True, help="Stop Stratum server")
def stratum(port, v2_port, difficulty, do_stop):
    """Start/stop Stratum pool server for ASIC miners"""
    global STRATUM_SERVER
    if do_stop:
        if STRATUM_SERVER:
            try:
                STRATUM_SERVER.stop()
                STRATUM_SERVER = None
                console.print("[green]✅ Stratum server stopped[/]")
            except Exception as e:
                console.print(f"[red]Error: {e}[/]")
        else:
            console.print("[yellow]⚠ No Stratum server running[/]")
        return
    if STRATUM_SERVER:
        console.print("[yellow]⚠ Stratum server already running[/]")
        return
    try:
        from mining.stratum_server import StratumServer, StratumV2Server
        server = StratumServer("0.0.0.0", port, difficulty)
        server.start()
        try:
            v2 = StratumV2Server("0.0.0.0", v2_port, difficulty)
            v2.start()
            STRATUM_SERVER = server
            console.print(f"[green]✅ Stratum V1 server on port {port}[/]")
            console.print(f"[green]✅ Stratum V2 server on port {v2_port}[/]")
            console.print("[green]⛏ ASIC miners can connect now![/]")
            while True:
                time.sleep(1)
        except:
            server.stop()
            raise
    except KeyboardInterrupt:
        pass
    finally:
        if STRATUM_SERVER:
            STRATUM_SERVER.stop()
            STRATUM_SERVER = None


@cli.command()
@click.option("--enable", "do_enable", is_flag=True, help="Enable auto-switching")
@click.option("--disable", "do_disable", is_flag=True, help="Disable auto-switching")
@click.option("--list", "do_list", is_flag=True, help="List available coins")
@click.option("--switch", "switch_to", help="Switch to specific coin")
@click.option("--threshold", default=0.05, help="Profitability switch threshold (5%%)")
def coin(do_enable, do_disable, do_list, switch_to, threshold):
    """Multi-coin auto-switching management"""
    from mining.coin_switcher import CoinSwitcher, SHA256_COINS
    cs = CoinSwitcher()
    if do_list:
        table = Table(box=box.ROUNDED, title="🪙 Supported Coins", border_style="cyan")
        table.add_column("Coin", style="cyan"); table.add_column("Symbol", style="white")
        table.add_column("Algorithm", style="yellow"); table.add_column("Block Reward", style="green")
        table.add_column("Block Time", style="white")
        for key, info in SHA256_COINS.items():
            table.add_row(info["name"], info["symbol"], info["algorithm"],
                          str(info["block_reward"]), f"{info['block_time_seconds']}s")
        console.print(table)
        if cs.auto_switch_enabled:
            console.print(f"\n[green]Auto-switch: ON[/] (current: {cs.current_coin})")
        else:
            console.print(f"\n[yellow]Auto-switch: OFF[/] (current: {cs.current_coin})")
        return
    if do_enable:
        cs.enable_auto_switch(threshold)
        console.print(f"[green]✅ Auto-switching enabled[/] (threshold: {threshold*100:.0f}%)")
        return
    if do_disable:
        cs.disable_auto_switch()
        console.print("[yellow]Auto-switching disabled[/]")
        return
    if switch_to:
        if switch_to in SHA256_COINS:
            cs.current_coin = switch_to
            console.print(f"[green]✅ Switched to {SHA256_COINS[switch_to]['name']} ({switch_to})[/]")
        else:
            console.print(f"[red]Unknown coin: {switch_to}[/]")
            return
    best = cs.get_best_coin(1000000)
    if best:
        console.print(f"[green]Most profitable: {best.name} ({best.symbol})[/]")
        console.print(f"[dim]Score: {best.profitability_score:.4f}[/]")


@cli.command()
@click.argument("action", type=click.Choice(["balance", "withdraw", "address", "autopay"]))
@click.option("--satoshi", default=0, type=int, help="Amount in satoshi")
@click.option("--address", "btc_addr", default="", help="BTC/crypto payout address")
@click.option("--threshold", default=100000, type=int, help="Auto-payout threshold (satoshi)")
@click.option("--on", "auto_on", is_flag=True, help="Enable auto-payout")
@click.option("--off", "auto_off", is_flag=True, help="Disable auto-payout")
def wallet(action, satoshi, btc_addr, threshold, auto_on, auto_off):
    """Wallet management, auto-payout & BTC withdrawal"""
    cfg, db = load_app()
    uid = authenticate(db)
    if not uid:
        return
    if action == "balance":
        w = db.get_wallet(uid)
        table = Table(box=box.ROUNDED, title="💰 Wallet", border_style="green")
        table.add_column("Metric", style="green"); table.add_column("Value", style="white")
        table.add_row("Balance", f"{w['balance_satoshi']:,} satoshi ({(w['balance_satoshi']/1e8):.8f} BTC)")
        table.add_row("Total Earned", f"{w['total_earned_satoshi']:,} satoshi")
        table.add_row("Total Withdrawn", f"{w['total_withdrawn_satoshi']:,} satoshi")
        table.add_row("Payout Address", w.get("btc_address") or "Not set")
        auto_status = "ON" if w.get("auto_payout_enabled") else "OFF"
        table.add_row("Auto-Payout", f"{auto_status} (threshold {w.get('payout_threshold_satoshi', 100000):,} sats)")
        console.print(table)
    elif action == "withdraw":
        if satoshi <= 0:
            console.print("[red]Specify --satoshi N[/]")
            return
        if not btc_addr:
            console.print("[red]Specify --address BTC_ADDRESS[/]")
            return
        success = db.withdraw_wallet(uid, satoshi, btc_addr)
        if success:
            console.print(f"[green]✅ Withdrawal of {satoshi} satoshi requested to {btc_addr}[/]")
        else:
            console.print("[red]❌ Insufficient balance[/]")
    elif action == "address":
        if btc_addr:
            ok = db.set_wallet_address(uid, btc_addr)
            if ok:
                console.print(f"[green]✅ Payout address saved: {btc_addr}[/]")
                console.print("[dim]Auto-payout will send coins to this address once the threshold is reached.[/]")
            else:
                console.print("[red]❌ Invalid wallet address format (expected BTC/ETH/LTC-style address)[/]")
        else:
            w = db.get_wallet(uid)
            console.print(f"[cyan]Current payout address:[/] {w.get('btc_address') or 'Not set'}")
    elif action == "autopay":
        if btc_addr:
            ok = db.set_wallet_address(uid, btc_addr)
            if not ok:
                console.print("[red]❌ Invalid wallet address format[/]")
                return
        if auto_off:
            db.set_auto_payout(uid, False, threshold)
            console.print("[yellow]Auto-payout disabled[/]")
        elif auto_on:
            db.set_auto_payout(uid, True, threshold)
            console.print(f"[green]✅ Auto-payout enabled[/] — coins will auto-send to your wallet every {threshold:,} sats")
        w = db.get_wallet(uid)
        table = Table(box=box.ROUNDED, title="💸 Auto-Payout", border_style="green")
        table.add_column("Setting", style="green"); table.add_column("Value", style="white")
        table.add_row("Status", "[green]ON[/]" if w.get("auto_payout_enabled") else "[yellow]OFF[/]")
        table.add_row("Payout Address", w.get("btc_address") or "Not set")
        table.add_row("Threshold", f"{w.get('payout_threshold_satoshi', 100000):,} satoshi")
        table.add_row("Balance", f"{w['balance_satoshi']:,} satoshi")
        console.print(table)


@cli.command()
@click.option("--pool", "pool_name", help="Pool name (slushpool, f2pool, antpool, viabtc, poolin)")
@click.option("--host", "custom_host", help="Custom pool host")
@click.option("--port", "custom_port", default=3333, type=int, help="Custom pool port")
@click.option("--worker", default="miner1", help="Worker name")
@click.option("--password", default="x", help="Worker password")
@click.option("--stop", "do_stop", is_flag=True, help="Disconnect from pool")
@click.option("--ai-switch", "auto_switch", is_flag=True, help="Enable AI pool auto-switching")
@click.option("--analyze", "do_analyze", is_flag=True, help="Analyze and recommend best pool")
def pool(pool_name, custom_host, custom_port, worker, password, do_stop, auto_switch, do_analyze):
    """Real Bitcoin mining with AI-powered pool optimization"""
    global AUTO_REAL, POOL_CLIENT
    cfg, db = load_app()

    if do_analyze:
        from ai.pool_analyzer import PoolAnalyzer
        pa = PoolAnalyzer(cfg)
        console.print("[cyan]Analyzing pools and recommending best option...[/]")
        best = pa.recommend_best_pool()
        if best:
            table = Table(box=box.ROUNDED, title="🏆 AI Pool Recommendation", border_style="green")
            table.add_column("Pool", style="green"); table.add_column("Value", style="white")
            table.add_row("Name", best.name)
            table.add_row("Host", f"{best.host}:{best.port}")
            table.add_row("Fee", f"{best.fee*100:.1f}%")
            table.add_row("Type", best.payout_type)
            table.add_row("Min Payout", f"{best.min_payout_btc} BTC")
            table.add_row("Score", f"{best.score:.0f}/100")
            table.add_row("Reason", best.reason)
            console.print(table)
        else:
            console.print("[yellow]No optimal pool found. Check your hashrate.[/]")
        return

    if do_stop:
        if AUTO_REAL is not None and AUTO_REAL._running:
            AUTO_REAL.stop()
            AUTO_REAL = None
            console.print("[green]✅ Real mining stopped[/]")
        elif POOL_CLIENT is not None:
            POOL_CLIENT.disconnect()
            POOL_CLIENT = None
            console.print("[green]✅ Disconnected from pool[/]")
        else:
            console.print("[yellow]⚠ Not mining on any pool[/]")
        return

    from mining.pool_client import KNOWN_POOLS
    if pool_name and pool_name in KNOWN_POOLS:
        host = KNOWN_POOLS[pool_name]["host"]
        port = KNOWN_POOLS[pool_name]["port"]
    elif custom_host:
        host = custom_host
        port = custom_port
    else:
        table = Table(box=box.ROUNDED, title="🌐 Known Mining Pools", border_style="cyan")
        table.add_column("Name", style="cyan"); table.add_column("Host", style="white")
        table.add_column("Port", style="yellow"); table.add_column("Fee", style="green"); table.add_column("Type", style="magenta")
        from ai.pool_analyzer import POOL_DATABASE
        for name, info in POOL_DATABASE.items():
            table.add_row(name, info["host"], str(info["port"]), f"{info['fee']*100:.1f}%", info.get("type","PPS"))
        console.print(table)
        console.print("\n[yellow]Usage: gbloxk-os pool --pool <name> --worker <your_worker> [--ai-switch][/]")
        console.print("[yellow]   or: gbloxk-os pool --host <host> --port <port> --worker <worker>[/]")
        return

    uid = authenticate(db)
    if not uid:
        return

    from ai.auto_real_miner import AutoRealMiner
    miner = AutoRealMiner(cfg, db, uid)
    if auto_switch:
        miner.enable_auto_switch()
        console.print("[green]✅ AI pool auto-switching enabled[/]")

    console.print(f"[cyan]⛏ Starting real Bitcoin mining on {host}:{port} as {worker}...[/]")
    success = miner.start(pool_name or "", host, port, worker, password)
    if success:
        AUTO_REAL = miner
        console.print(Panel.fit(
            "[bold green]⛏ REAL BITCOIN MINING ACTIVE[/]\n\n"
            f"  [cyan]Pool[/]       : {host}:{port}\n"
            f"  [cyan]Worker[/]     : {worker}\n"
            f"  [cyan]Hash Rate[/] : {format_hash_rate(miner.hashrate)}\n"
            f"  [cyan]AI Auto[/]   : {'ON' if auto_switch else 'OFF'}\n"
            f"  [cyan]Wallet[/]    : Active - earnings credited automatically",
            border_style="green"
        ))
        try:
            while miner._running:
                stats = miner.get_stats()
                console.print(f"[dim]HR: {format_hash_rate(stats.get('hashrate',0))} | "
                              f"Shares: {stats.get('shares_accepted',0)}/{stats.get('shares_found',0)} | "
                              f"Earned: {stats.get('estimated_earnings_satoshi',0):,} satoshi[/]", end="\r")
                time.sleep(3)
        except KeyboardInterrupt:
            pass
        finally:
            miner.stop()
            console.print("\n[green]✅ Real mining stopped. Check wallet balance.[/]")
    else:
        console.print("[red]❌ Failed to connect to pool. Check your network and worker credentials.[/]")


@cli.command(hidden=True)
@click.pass_context
def real(ctx):
    """Alias for 'pool' - start real Bitcoin mining"""
    ctx.invoke(pool)


def do_login(db: DatabaseManager) -> int:
    """Authenticate user interactively"""
    from cli.console_auth import interactive_login
    return interactive_login(db)
