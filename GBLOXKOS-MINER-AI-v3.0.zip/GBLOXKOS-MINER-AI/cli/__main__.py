import click
from rich.console import Console
from rich.panel import Panel

console = Console()

from config import AppConfig
from database.storage import DatabaseManager
from utils.logger import setup_logger

logger = setup_logger(__name__)

PASS_CONTEXT = click.make_pass_decorator(dict, ensure=True)


def load_app():
    cfg = AppConfig.load()
    db = DatabaseManager(cfg.db_path)
    return cfg, db


def authenticate(db: DatabaseManager) -> int:
    from cli.commands import do_login
    return do_login(db)


@click.group(invoke_without_command=True)
@click.option("--version", is_flag=True, help="Show version")
@click.pass_context
def cli(ctx, version):
    if version:
        console.print(Panel.fit(
            "[bold cyan]GBLOXK OS[/] [white]MINER AI[/] [dim]v3.0[/]\n"
            "[dim]Autonomous AI Mining Operating System[/]\n"
            "[dim]Engine: SHA-256 Multi-Processor | AI: Ollama[/]\n"
            "[dim]Features: Self-Healing | Self-Learning | Self-Awareness | Auto-Payout | Stratum V2 | Multi-Coin | REST API | Web Dashboard | ASIC Support | Pool Integration[/]",
            border_style="cyan"
        ))
        return
    if ctx.invoked_subcommand is None:
        console.print("[yellow]Usage:[/] gbloxk-os [OPTIONS] COMMAND [ARGS]...")
        console.print("\n[bold]Core Mining:[/]")
        console.print("  [cyan]start[/]        Start automated mining")
        console.print("  [cyan]stop[/]         Stop mining")
        console.print("  [cyan]status[/]       Show mining status & AI self-report")
        console.print("  [cyan]monitor[/]      Real-time monitoring dashboard")
        console.print("  [cyan]config[/]       View/change configuration")
        console.print("\n[bold]AI & Analytics:[/]")
        console.print("  [cyan]ai[/]           AI advisor commands")
        console.print("  [cyan]profit[/]       Profitability calculator")
        console.print("  [cyan]self[/]         Self-* system status")
        console.print("  [cyan]analyze[/]      Run AI performance analysis")
        console.print("  [cyan]history[/]      View mining session history")
        console.print("  [cyan]feedback[/]     Submit feedback")
        console.print("\n[bold]Enterprise (v3.0):[/]")
        console.print("  [cyan]api[/]          REST API server (FastAPI)")
        console.print("  [cyan]stratum[/]      Stratum pool server (ASIC/GPU miners)")
        console.print("  [cyan]coin[/]         Multi-coin auto-switching")
        console.print("  [cyan]wallet[/]       Wallet, payout address & auto-send")
        console.print("  [cyan]pool[/]         Mining pool client")
        console.print("\n[dim]Run 'gbloxk-os COMMAND --help' for more info.[/]")
        console.print("\n[yellow]Example:[/] [white]gbloxk-os start[/] | [white]gbloxk-os monitor[/] | [white]gbloxk-os api[/]")


def main():
    cli()
