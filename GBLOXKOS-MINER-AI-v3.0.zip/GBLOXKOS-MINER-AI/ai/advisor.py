from config import AppConfig
from utils.logger import setup_logger

logger = setup_logger(__name__)

try:
    from ollama import Client as OllamaClient
    _ollama_available = True
except ImportError:
    _ollama_available = False
    OllamaClient = object


class AIAdvisor:
    def __init__(self, config: AppConfig):
        self.config = config
        self._available = _ollama_available
        if self._available:
            try:
                self.client = OllamaClient(host=config.ollama_host)
                self.model = config.ollama_model
                self._check_model()
            except Exception:
                self._available = False
        else:
            self._available = False

    def _check_model(self):
        try:
            models = self.client.list()
            available = []
            raw = models.get("models", [])
            for m in raw:
                if isinstance(m, dict):
                    available.append(m.get("name", ""))
                elif hasattr(m, "name"):
                    available.append(m.name)
            if self.model not in available and "huihui_ai" not in self.model:
                fallback = [m for m in available if "llama" in m or "qwen" in m or "mistral" in m]
                if fallback:
                    self.model = fallback[0]
                    logger.info(f"Using fallback model: {self.model}")
        except Exception as e:
            logger.debug(f"Ollama model check: {e}")

    def _query(self, prompt: str, system: str = "") -> str:
        if not self._available:
            return "[AI advisor: Ollama not available. Run in air-gapped mode - AI features disabled. Mining continues autonomously.]"
        try:
            messages = []
            if system:
                messages.append({"role": "system", "content": system})
            messages.append({"role": "user", "content": prompt})

            resp = self.client.chat(model=self.model, messages=messages, options={"temperature": 0.7})
            return resp["message"]["content"].strip()
        except Exception as e:
            logger.debug(f"AI query failed (air-gapped): {e}")
            return "[AI advisor: offline. Mining continues with self-healing/learning/awareness engines.]"

    def analyze_mining_performance(self, stats: dict) -> str:
        prompt = f"""Analyze this Bitcoin mining performance data and provide optimization recommendations:
- Hash Rate: {stats.get('hash_rate', 0):.2f} H/s
- Blocks Found: {stats.get('blocks_found', 0)}
- Total Hashes: {stats.get('total_hashes', 0)}
- Difficulty: {stats.get('current_difficulty', 4)}
- Workers: {self.config.workers}
- Session Duration: {stats.get('elapsed', 0):.1f}s

Provide concise, actionable advice for improving mining efficiency."""
        return self._query(prompt, "You are a Bitcoin mining optimization expert.")

    def suggest_difficulty(self, hash_rate: float, blocks_found: int) -> str:
        prompt = f"""Given current mining metrics:
- Hash Rate: {hash_rate:.2f} H/s
- Blocks Found: {blocks_found}
- Current Workers: {self.config.workers}

What difficulty level (1-10) should I use and why? Respond with just the number and a brief reason."""
        return self._query(prompt, "You are a Bitcoin mining strategy expert.")

    def predict_yield(self, stats: dict) -> str:
        prompt = f"""Based on these mining stats:
- Hash Rate: {stats.get('hash_rate', 0):.2f} H/s
- Blocks Found: {stats.get('blocks_found', 0)}
- Difficulty: {stats.get('current_difficulty', 4)}
- Block Reward: {self.config.block_reward} BTC

Estimate the expected BTC yield per hour and give recommendations."""
        return self._query(prompt, "You are a cryptocurrency mining analyst.")

    def chat(self, message: str) -> str:
        system = (
            "You are an advanced AI mining assistant. You help with Bitcoin mining strategies, "
            "blockchain technology, hardware recommendations, and optimization tips. "
            "Be concise, professional, and data-driven."
        )
        return self._query(message, system)
