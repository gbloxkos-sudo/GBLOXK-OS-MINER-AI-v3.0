import psutil
from typing import Optional
from dataclasses import dataclass, field


@dataclass
class ResourceProfile:
    cpu_percent: float = 0.0
    cpu_per_core: list = field(default_factory=list)
    memory_percent: float = 0.0
    memory_available_gb: float = 0.0
    swap_percent: float = 0.0
    disk_io_read_mb: float = 0.0
    disk_io_write_mb: float = 0.0
    load_avg: tuple = (0, 0, 0)
    temperature: Optional[float] = None
    cores_logical: int = 0
    cores_physical: int = 0


class SystemMonitor:
    def __init__(self, interval: float = 1.0):
        self.interval = interval
        self._prev_disk = psutil.disk_io_counters()

    def profile(self) -> ResourceProfile:
        p = ResourceProfile()
        p.cpu_percent = psutil.cpu_percent(interval=self.interval)
        p.cpu_per_core = psutil.cpu_percent(interval=0, percpu=True)
        mem = psutil.virtual_memory()
        p.memory_percent = mem.percent
        p.memory_available_gb = mem.available / (1024 ** 3)
        p.swap_percent = psutil.swap_memory().percent
        p.load_avg = getattr(psutil, "getloadavg", lambda: (0, 0, 0))()
        p.cores_logical = psutil.cpu_count(logical=True)
        p.cores_physical = psutil.cpu_count(logical=False)

        try:
            disk = psutil.disk_io_counters()
            if self._prev_disk:
                dt = self.interval if self.interval > 0 else 1
                p.disk_io_read_mb = (disk.read_bytes - self._prev_disk.read_bytes) / (1024 ** 2) / dt
                p.disk_io_write_mb = (disk.write_bytes - self._prev_disk.write_bytes) / (1024 ** 2) / dt
            self._prev_disk = disk
        except Exception:
            pass

        try:
            temps = psutil.sensors_temperatures()
            if temps:
                cpu_temps = []
                for name, entries in temps.items():
                    if entries:
                        for entry in entries:
                            temp = entry.current
                            if 0 < temp < 150:
                                if 'core' in name.lower() or 'package' in name.lower() or 'cpu' in name.lower():
                                    cpu_temps.append(temp)
                                else:
                                    p.temperature = temp
                if cpu_temps:
                    p.temperature = sum(cpu_temps) / len(cpu_temps)
        except Exception:
            pass
        
        if p.temperature is None:
            p.temperature = 45.0

        return p

    def recommended_workers(self, profile: Optional[ResourceProfile] = None) -> int:
        p = profile or self.profile()
        total = p.cores_logical
        cpu_free = 100 - p.cpu_percent
        mem_free = p.memory_available_gb
        free_ratio = min(cpu_free / 100.0, mem_free / 4.0)
        recommended = max(1, int(total * free_ratio))
        if p.memory_percent > 85:
            recommended = max(1, recommended // 2)
        return min(recommended, total)

    def optimal_difficulty(self, profile: Optional[ResourceProfile] = None) -> int:
        p = profile or self.profile()
        cpu_power = p.cores_logical * (100 - p.cpu_percent) / 100.0
        mem_health = max(0, 1 - p.memory_percent / 100.0)
        score = cpu_power * mem_health
        if score < 1:
            return 2
        elif score < 3:
            return 3
        elif score < 6:
            return 4
        elif score < 10:
            return 5
        else:
            return 6

    def can_mine(self, profile: Optional[ResourceProfile] = None) -> tuple[bool, str]:
        p = profile or self.profile()
        if p.memory_percent > 95:
            return False, "Insufficient memory available"
        if p.memory_available_gb < 0.3:
            return False, "Less than 300MB RAM available - OOM risk"
        if p.cpu_percent > 90:
            return False, "CPU usage already critical"
        if p.memory_available_gb < 0.5:
            return False, "Less than 512MB RAM available"
        return True, "System ready for mining"

    def safe_worker_limit(self, profile: Optional[ResourceProfile] = None) -> int:
        p = profile or self.profile()
        mem_gb = p.memory_available_gb
        if mem_gb < 0.5:
            return 1
        elif mem_gb < 1.0:
            return max(1, p.cores_logical // 4)
        elif mem_gb < 2.0:
            return max(1, p.cores_logical // 2)
        else:
            return p.cores_logical

    def get_oom_risk(self, profile: Optional[ResourceProfile] = None) -> str:
        p = profile or self.profile()
        if p.memory_percent > 95 or p.memory_available_gb < 0.3:
            return "CRITICAL"
        if p.memory_percent > 85 or p.memory_available_gb < 0.5:
            return "HIGH"
        if p.memory_percent > 70 or p.memory_available_gb < 1.0:
            return "MODERATE"
        return "LOW"
