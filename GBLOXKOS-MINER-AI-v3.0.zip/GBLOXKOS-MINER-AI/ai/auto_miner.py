import time
import threading
from typing import Optional, Callable
from config import AppConfig
from ai.advisor import AIAdvisor
from ai.analyzer import SystemMonitor, ResourceProfile
from ai.profitability import ProfitabilityCalculator
from ai.alerts import AlertManager
from utils.logger import setup_logger

logger = setup_logger(__name__)


class AutoMiningController:
    def __init__(self, config: AppConfig, advisor: AIAdvisor,
                 monitor: SystemMonitor, profitability: ProfitabilityCalculator,
                 alerts: AlertManager):
        self.config = config
        self.advisor = advisor
        self.monitor = monitor
        self.profitability = profitability
        self.alerts = alerts
        self.enabled = False
        self.mode = "balanced"
        self._thread: Optional[threading.Thread] = None
        self._callbacks = {
            "on_adjustment": None,
            "on_mode_change": None,
        }
        self._history = []
        self._last_ai_query = 0
        self._ai_query_interval = 30

    def set_callback(self, name: str, cb: Callable):
        self._callbacks[name] = cb

    def start(self):
        if self.enabled:
            return
        self.enabled = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        logger.info("AI Auto-Mining started")

    def stop(self):
        self.enabled = False
        logger.info("AI Auto-Mining stopped")

    def set_mode(self, mode: str):
        valid = ["performance", "balanced", "eco", "laptop_safe"]
        if mode in valid:
            self.mode = mode
            if self._callbacks["on_mode_change"]:
                self._callbacks["on_mode_change"](mode)
            logger.info(f"Auto-mining mode set to: {mode}")

    def _loop(self):
        while self.enabled:
            try:
                profile = self.monitor.profile()
                adjustment = self._compute_adjustment(profile)
                self._apply_adjustment(adjustment)
                self._history.append({
                    "time": time.time(),
                    "profile": profile,
                    "adjustment": adjustment,
                })
                if len(self._history) > 100:
                    self._history = self._history[-50:]
                time.sleep(2)
            except Exception as e:
                logger.error(f"Auto-mining error: {e}")
                time.sleep(5)

    def _compute_adjustment(self, profile: ResourceProfile) -> dict:
        cpu = profile.cpu_percent
        mem = profile.memory_percent
        temp = profile.temperature or 0
        cores = profile.cores_logical
        mem_avail = profile.memory_available_gb

        if self.mode == "laptop_safe":
            max_cpu = 50
            max_mem = 70
            max_temp = 65
            worker_ratio = 0.3
        elif self.mode == "eco":
            max_cpu = 40
            max_mem = 60
            max_temp = 60
            worker_ratio = 0.25
        elif self.mode == "performance":
            max_cpu = 85
            max_mem = 85
            max_temp = 80
            worker_ratio = 0.8
        else:
            max_cpu = 65
            max_mem = 75
            max_temp = 70
            worker_ratio = 0.5

        if cpu >= max_cpu or mem >= max_mem or (temp > 0 and temp >= max_temp):
            throttle = True
            reduction = max(
                0.3 if cpu >= max_cpu else 1.0,
                0.3 if mem >= max_mem else 1.0,
                0.2 if temp >= max_temp else 1.0,
            )
        else:
            throttle = False
            reduction = 1.0

        if mem_avail < 1.0:
            reduction = min(reduction, 0.3)
        if mem_avail < 0.5:
            reduction = 0.1

        recommended_workers = max(1, int(cores * worker_ratio * reduction))
        difficulty = max(1, min(8, int(recommended_workers * 0.8 * (1 + reduction))))

        if temp > 70:
            difficulty = max(1, difficulty - 2)
        if temp > 80:
            recommended_workers = max(1, recommended_workers // 2)
            difficulty = 1

        return {
            "workers": recommended_workers,
            "difficulty": difficulty,
            "throttle": throttle,
            "reason": f"CPU:{cpu:.0f}% RAM:{mem:.0f}% Temp:{temp:.0f}°C → W:{recommended_workers} D:{difficulty}",
        }

    def _apply_adjustment(self, adj: dict):
        if self._callbacks["on_adjustment"]:
            self._callbacks["on_adjustment"](adj)

    def get_status(self) -> dict:
        return {
            "enabled": self.enabled,
            "mode": self.mode,
            "history_count": len(self._history),
        }

    def get_reason(self) -> str:
        if self._history:
            return self._history[-1]["adjustment"]["reason"]
        return "AI Auto-Mining: initializing..."
