import time
import threading
from typing import Optional
from config import AppConfig
from database.storage import DatabaseManager
from mining.pool_miner import PoolMiner
from ai.pool_analyzer import PoolAnalyzer, POOL_DATABASE
from ai.analyzer import SystemMonitor
from ai.alerts import AlertManager
from ai.self_learning import SelfLearningEngine
from ai.self_aware import SelfAwarenessEngine
from utils.logger import setup_logger

logger = setup_logger(__name__)


class AutoRealMiner:
    def __init__(self, config: AppConfig, db: DatabaseManager, user_id: int):
        self.config = config
        self.db = db
        self.user_id = user_id
        self.pool_miner: Optional[PoolMiner] = None
        self.pool_analyzer = PoolAnalyzer(config)
        self.monitor = SystemMonitor()
        self.alerts = AlertManager()
        self.learning = SelfLearningEngine(config)
        self.awareness = SelfAwarenessEngine(config, self.learning, self.alerts)
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._auto_switch = False
        self._switch_cooldown = 300
        self._last_switch = 0
        self._min_daily_usd = 0.001
        self.session_id: Optional[int] = None
        self.on_status = None

    def start(self, pool_name: str = "", host: str = "", port: int = 3333,
              worker: str = "miner1", password: str = "x"):
        if self._running:
            return

        self.session_id = self.db.create_session(self.user_id, self.config.default_difficulty)
        self.pool_miner = PoolMiner(self.config, self.db, self.user_id)

        def on_share(job_id, nonce, earned):
            logger.info(f"Share: {nonce} earned {earned} satoshi")

        def on_status(msg):
            logger.info(f"Pool: {msg}")

        self.pool_miner.on_share = on_share
        self.pool_miner.on_status = on_status
        self._running = True

        if not pool_name and not host:
            best = self.pool_analyzer.recommend_best_pool()
            if best:
                pool_name = best.name
                host = best.host
                port = best.port
                logger.info(f"AI selected {pool_name} as best pool (score: {best.score:.0f})")

        success = self.pool_miner.start(pool_name, host, port, worker, password)
        if not success:
            self._running = False
            return False

        self._thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self._thread.start()
        return True

    def stop(self):
        self._running = False
        if self.pool_miner:
            self.pool_miner.stop()
        if self.session_id:
            self.db.end_session(self.session_id, {
                "blocks_found": self.pool_miner.shares_accepted if self.pool_miner else 0,
                "total_hashes": 0,
                "hash_rate": self.pool_miner.hashrate if self.pool_miner else 0,
            })
            self.session_id = None

    def _monitor_loop(self):
        while self._running and self.pool_miner:
            try:
                stats = self.pool_miner.get_stats()
                profile = self.monitor.profile()

                self.awareness.observe(profile, stats.get("hashrate", 0), stats.get("shares_accepted", 0))
                self.learning.record_observation(
                    hash_rate=stats.get("hashrate", 0),
                    difficulty=self.config.default_difficulty,
                    workers=self.config.workers,
                    cpu_usage=profile.cpu_percent,
                    memory_usage=profile.memory_percent,
                    temperature=profile.temperature or 0,
                    blocks_found=stats.get("shares_accepted", 0),
                    mode="auto",
                )

                self.alerts.check(profile, stats)
                self._auto_tune(stats, profile)

                if self._auto_switch and time.time() - self._last_switch > self._switch_cooldown:
                    self._check_pool_switch(stats)

                time.sleep(3)
            except Exception as e:
                logger.error(f"Monitor error: {e}")
                time.sleep(10)

    def _auto_tune(self, stats: dict, profile):
        recommended_workers = self.monitor.recommended_workers(profile)
        cpu = profile.cpu_percent
        mem = profile.memory_percent
        temp = profile.temperature or 0

        if cpu > 80 or mem > 85 or temp > 75:
            recommended_workers = max(1, recommended_workers // 2)
        if temp > 80:
            recommended_workers = 1

        if self.pool_miner and self.pool_miner.pool_client and self.pool_miner.pool_client.connected:
            acceptance = self.pool_miner.shares_accepted / max(self.pool_miner.shares_found, 1)
            if acceptance < 0.5:
                logger.warning(f"Low share acceptance ({acceptance*100:.0f}%) - adjusting")

    def _check_pool_switch(self, current_stats: dict):
        hash_rate = current_stats.get("hashrate", 0)
        if hash_rate < 100:
            return
        best = self.pool_analyzer.recommend_best_pool(hash_rate)
        if not best:
            return
        current_pool = current_stats.get("pool", "")
        current_name = ""
        for name, info in POOL_DATABASE.items():
            if info["host"] in current_pool:
                current_name = name
                break
        if best.name != current_name and best.score > 20:
            logger.info(f"AI switching pool: {current_name} -> {best.name} (score: {best.score:.0f})")
            self._last_switch = time.time()
            old_worker = current_stats.get("worker", "miner1")
            self.stop()
            time.sleep(2)
            self.start(best.name, best.host, best.port, old_worker)

    @property
    def hashrate(self) -> float:
        return self.pool_miner.hashrate if self.pool_miner else 0.0

    def get_stats(self) -> dict:
        pool_stats = self.pool_miner.get_stats() if self.pool_miner else {}
        awareness = self.awareness.get_stats()
        learning = self.learning.get_stats()
        btc_price = 0
        try:
            from ai.profitability import fetch_btc_price
            btc_price = fetch_btc_price()
        except:
            pass
        return {
            **pool_stats,
            "btc_price": btc_price,
            "awareness_health": awareness.get("health", "unknown"),
            "learning_records": learning.get("records_count", 0),
            "auto_switch": self._auto_switch,
        }

    def enable_auto_switch(self):
        self._auto_switch = True

    def disable_auto_switch(self):
        self._auto_switch = False
