import time
import threading
from typing import Optional
from dataclasses import dataclass
from config import AppConfig
from utils.logger import setup_logger

logger = setup_logger(__name__)


POOL_DATABASE = {
    "slushpool": {
        "host": "stratum.slushpool.com", "port": 3333, "fee": 0.02,
        "min_payout": 0.001, "payout_schedule": "daily", "type": "FPPS",
        "location": "EU/US/Asia", "requires_id": True,
    },
    "f2pool": {
        "host": "btc.f2pool.com", "port": 1314, "fee": 0.025,
        "min_payout": 0.005, "payout_schedule": "daily", "type": "PPS+",
        "location": "US/EU/Asia", "requires_id": False,
    },
    "antpool": {
        "host": "stratum.antpool.com", "port": 3333, "fee": 0.024,
        "min_payout": 0.001, "payout_schedule": "daily", "type": "PPS+",
        "location": "US/Asia", "requires_id": False,
    },
    "viabtc": {
        "host": "stratum.viabtc.com", "port": 3333, "fee": 0.015,
        "min_payout": 0.001, "payout_schedule": "daily", "type": "PPS",
        "location": "US/EU/Asia", "requires_id": True,
    },
    "poolin": {
        "host": "stratum.poolin.com", "port": 3333, "fee": 0.0125,
        "min_payout": 0.001, "payout_schedule": "daily", "type": "FPPS",
        "location": "US/EU/Asia", "requires_id": True,
    },
}


@dataclass
class PoolRecommendation:
    name: str
    host: str
    port: int
    fee: float
    payout_type: str
    min_payout_btc: float
    score: float
    reason: str


class PoolAnalyzer:
    def __init__(self, config: AppConfig):
        self.config = config
        self._performance_history = {}
        self._lock = threading.Lock()

    def record_performance(self, pool_name: str, hashrate: float,
                           accepted: int, rejected: int, latency_ms: float = 0):
        with self._lock:
            if pool_name not in self._performance_history:
                self._performance_history[pool_name] = []
            self._performance_history[pool_name].append({
                "time": time.time(),
                "hashrate": hashrate,
                "accepted": accepted,
                "rejected": rejected,
                "latency_ms": latency_ms,
            })
            if len(self._performance_history[pool_name]) > 100:
                self._performance_history[pool_name] = \
                    self._performance_history[pool_name][-100:]

    def get_pool_stats(self, pool_name: str) -> dict:
        info = POOL_DATABASE.get(pool_name, {})
        with self._lock:
            hist = self._performance_history.get(pool_name, [])
        if not hist:
            return {"name": pool_name, **info, "avg_hashrate": 0,
                    "acceptance_rate": 1.0, "samples": 0}

        recent = hist[-20:] if len(hist) > 20 else hist
        avg_hr = sum(h["hashrate"] for h in recent) / len(recent)
        total_acc = sum(h["accepted"] for h in recent)
        total_rej = sum(h["rejected"] for h in recent)
        total = total_acc + total_rej
        acceptance = total_acc / total if total > 0 else 1.0
        avg_latency = sum(h["latency_ms"] for h in recent if h["latency_ms"]) / \
                      max(sum(1 for h in recent if h["latency_ms"]), 1)

        return {
            "name": pool_name, **info,
            "avg_hashrate": avg_hr,
            "acceptance_rate": acceptance,
            "avg_latency_ms": avg_latency,
            "samples": len(hist),
        }

    def recommend_best_pool(self, hashrate_hs: float = 0,
                            min_acceptance: float = 0.8) -> Optional[PoolRecommendation]:
        recommendations = []
        for name, info in POOL_DATABASE.items():
            stats = self.get_pool_stats(name)

            acceptance = stats.get("acceptance_rate", 1.0)
            if acceptance < min_acceptance:
                continue

            fee_impact = info["fee"] * 100
            acceptance_bonus = acceptance * 10
            pps_bonus = 5 if "PPS" in info.get("type", "") else 0
            latency_penalty = max(0, (stats.get("avg_latency_ms", 0) - 50) / 10)

            score = 100 - fee_impact + acceptance_bonus + pps_bonus - latency_penalty

            payout_ok = True
            if hashrate_hs > 0:
                daily_btc = (hashrate_hs / 624e18) * 144 * 3.125 * (1 - info["fee"])
                if daily_btc < info.get("min_payout", 0.001) * 0.5:
                    payout_ok = False
                    score -= 30

            recommendations.append(PoolRecommendation(
                name=name,
                host=info["host"],
                port=info["port"],
                fee=info["fee"],
                payout_type=info.get("type", "PPS"),
                min_payout_btc=info.get("min_payout", 0.001),
                score=max(0, min(100, score)),
                reason=self._build_reason(name, info, score, stats, payout_ok),
            ))

        recommendations.sort(key=lambda r: r.score, reverse=True)
        return recommendations[0] if recommendations else None

    def _build_reason(self, name: str, info: dict, score: float,
                      stats: dict, payout_ok: bool) -> str:
        parts = []
        if info.get("type") == "FPPS":
            parts.append("Full Pay Per Share (FPPS) - best payout model")
        elif info.get("type") == "PPS+":
            parts.append("PPS+ - good for stable hashrate")
        else:
            parts.append("PPS - predictable earnings")

        if stats.get("acceptance_rate", 1) > 0.95:
            parts.append(f"high acceptance rate ({stats['acceptance_rate']*100:.0f}%)")
        elif stats.get("acceptance_rate", 1) < 0.8:
            parts.append(f"⚠ low acceptance rate ({stats['acceptance_rate']*100:.0f}%)")

        if not payout_ok:
            parts.append("⚠ may not reach minimum payout")
        parts.append(f"fee: {info['fee']*100:.1f}%")
        return ", ".join(parts)

    def predict_daily_earnings(self, hashrate_hs: float, pool_fee: float = 0.02) -> dict:
        network_hashrate = 624e18
        blocks_per_day = 144
        block_reward = 3.125
        btc_price = 0
        try:
            from ai.profitability import fetch_btc_price
            btc_price = fetch_btc_price()
        except:
            pass

        daily_btc = (hashrate_hs / network_hashrate) * blocks_per_day * block_reward * (1 - pool_fee)
        daily_usd = daily_btc * btc_price if btc_price > 0 else 0

        return {
            "hashrate_hs": hashrate_hs,
            "network_hashrate_hs": network_hashrate,
            "btc_price": btc_price,
            "daily_btc": daily_btc,
            "daily_usd": daily_usd,
            "weekly_usd": daily_usd * 7,
            "monthly_usd": daily_usd * 30,
            "days_to_1btc": 1 / daily_btc if daily_btc > 0 else float("inf"),
            "blocks_per_day_found": (hashrate_hs / network_hashrate) * blocks_per_day,
        }

    def get_performance_trend(self, pool_name: str) -> str:
        with self._lock:
            hist = self._performance_history.get(pool_name, [])
        if len(hist) < 5:
            return "insufficient data"
        recent = hist[-5:]
        avg_hr = sum(h["hashrate"] for h in recent) / len(recent)
        early_hr = sum(h["hashrate"] for h in hist[:5]) / min(5, len(hist))
        if avg_hr > early_hr * 1.1:
            return "improving"
        elif avg_hr < early_hr * 0.9:
            return "declining"
        return "stable"
