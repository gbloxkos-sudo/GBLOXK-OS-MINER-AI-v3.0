import time
import threading
from config import AppConfig
from utils.logger import setup_logger

logger = setup_logger(__name__)

BTC_PRICE_CACHE = {"price": 0.0, "updated": 0, "source": "none"}
CACHE_TTL = 60


def fetch_btc_price() -> float:
    now = time.time()
    if now - BTC_PRICE_CACHE["updated"] < CACHE_TTL and BTC_PRICE_CACHE["source"] != "none":
        return BTC_PRICE_CACHE["price"]
    try:
        import urllib.request
        import json
        resp = urllib.request.urlopen("https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd", timeout=5)
        data = json.loads(resp.read().decode())
        price = data.get("bitcoin", {}).get("usd", 0.0)
        if price > 0:
            BTC_PRICE_CACHE["price"] = price
            BTC_PRICE_CACHE["updated"] = now
            BTC_PRICE_CACHE["source"] = "coingecko"
        return price if price > 0 else BTC_PRICE_CACHE["price"]
    except Exception as e:
        logger.debug(f"BTC price fetch failed (air-gapped mode): {e}")
    return BTC_PRICE_CACHE["price"]


class ProfitabilityCalculator:
    def __init__(self, config: AppConfig):
        self.config = config
        self._price_updater = threading.Thread(target=self._update_loop, daemon=True)
        self._price_updater.start()

    def _update_loop(self):
        while True:
            fetch_btc_price()
            time.sleep(CACHE_TTL)

    def calculate(self, hash_rate: float, power_watts: float = 0,
                  electricity_cost: float = 0.12, pool_fee: float = 0.02) -> dict:
        btc_price = fetch_btc_price()
        network_hashrate = 624e18
        daily_btc = (hash_rate / network_hashrate) * 144 * self.config.block_reward
        daily_btc *= (1 - pool_fee)
        daily_revenue = daily_btc * btc_price
        daily_power_cost = (power_watts / 1000) * 24 * electricity_cost if power_watts > 0 else 0
        daily_profit = daily_revenue - daily_power_cost

        return {
            "btc_price": btc_price,
            "daily_btc": daily_btc,
            "daily_revenue_usd": daily_revenue,
            "daily_power_cost": daily_power_cost,
            "daily_profit_usd": daily_profit,
            "monthly_profit_usd": daily_profit * 30,
            "yearly_profit_usd": daily_profit * 365,
            "roi_percent": (daily_profit / max(daily_revenue, 1)) * 100,
            "btc_mined_per_day": daily_btc,
            "days_to_1btc": 1 / daily_btc if daily_btc > 0 else float("inf"),
        }

    def get_price(self) -> float:
        return fetch_btc_price()
