import time
import threading
from dataclasses import dataclass, field
from ai.analyzer import ResourceProfile
from ai.self_learning import SelfLearningEngine
from ai.alerts import AlertManager
from config import AppConfig
from utils.logger import setup_logger

logger = setup_logger(__name__)


@dataclass
class SystemState:
    overall_health: str = "unknown"
    performance_rating: str = "unknown"
    stability_score: float = 1.0
    anomaly_detected: bool = False
    anomalies: list = field(default_factory=list)
    recommendations: list = field(default_factory=list)
    consciousness_level: str = "awake"


class SelfAwarenessEngine:
    def __init__(self, config: AppConfig, learning: SelfLearningEngine, alerts: AlertManager):
        self.config = config
        self.learning = learning
        self.alerts = alerts
        self.enabled = True
        self.state = SystemState()
        self._history: list[dict] = []
        self._anomaly_thresholds = {
            "cpu_spike": 25,
            "memory_leak": 15,
            "hashrate_drop": 0.5,
            "temp_spike": 10,
        }
        self._baselines: dict = {
            "cpu_baseline": 30.0,
            "mem_baseline": 50.0,
            "hr_baseline": 1000.0,
            "temp_baseline": 45.0,
        }
        self._awareness_thread = threading.Thread(target=self._awareness_loop, daemon=True)
        self._awareness_thread.start()
        logger.info("Self-Awareness Engine activated")

    def _awareness_loop(self):
        while self.enabled:
            try:
                self._update_state()
                time.sleep(5)
            except Exception as e:
                logger.error(f"Awareness error: {e}")
                time.sleep(10)

    def _update_state(self):
        if not self._history:
            return

        recent = self._history[-20:]
        if len(recent) < 1:
            return

        self._detect_anomalies(recent)
        self._assess_health(recent)
        self._generate_recommendations()

    def observe(self, profile: ResourceProfile, hash_rate: float, blocks: int):
        observation = {
            "time": time.time(),
            "cpu": profile.cpu_percent,
            "mem": profile.memory_percent,
            "temp": profile.temperature or 0,
            "hash_rate": hash_rate,
            "blocks": blocks,
            "mem_avail_gb": profile.memory_available_gb,
        }
        self._history.append(observation)
        if len(self._history) > 200:
            self._history = self._history[-150:]

        if len(self._history) >= 10:
            self._update_baselines()

    def _update_baselines(self):
        recent = self._history[-30:]
        if len(recent) < 5:
            return
        self._baselines["cpu_baseline"] = sum(r["cpu"] for r in recent) / len(recent)
        self._baselines["mem_baseline"] = sum(r["mem"] for r in recent) / len(recent)
        hr_values = [r["hash_rate"] for r in recent if r["hash_rate"] > 0]
        if hr_values:
            self._baselines["hr_baseline"] = sum(hr_values) / len(hr_values)
        temp_values = [r["temp"] for r in recent if r["temp"] > 0]
        if temp_values:
            self._baselines["temp_baseline"] = sum(temp_values) / len(temp_values)

    def _detect_anomalies(self, recent: list):
        self.state.anomalies = []
        self.state.anomaly_detected = False

        latest = recent[-1]
        baseline = self._baselines

        if latest["cpu"] > baseline["cpu_baseline"] + self._anomaly_thresholds["cpu_spike"]:
            self.state.anomalies.append(f"⚠ CPU spike: {latest['cpu']:.0f}% vs baseline {baseline['cpu_baseline']:.0f}%")
            self.state.anomaly_detected = True

        if latest["mem"] > baseline["mem_baseline"] + self._anomaly_thresholds["memory_leak"]:
            self.state.anomalies.append(f"⚠ Memory increase: {latest['mem']:.0f}% vs baseline {baseline['mem_baseline']:.0f}%")
            self.state.anomaly_detected = True

        if latest["hash_rate"] > 0 and baseline["hr_baseline"] > 0:
            drop_ratio = latest["hash_rate"] / baseline["hr_baseline"]
            if drop_ratio < self._anomaly_thresholds["hashrate_drop"]:
                self.state.anomalies.append(f"⚠ Hashrate drop: {drop_ratio*100:.0f}% of baseline")
                self.state.anomaly_detected = True

        if latest["temp"] > 0 and baseline["temp_baseline"] > 0:
            temp_spike = latest["temp"] - baseline["temp_baseline"]
            if temp_spike > self._anomaly_thresholds["temp_spike"]:
                self.state.anomalies.append(f"⚠ Temperature spike: +{temp_spike:.0f}°C")
                self.state.anomaly_detected = True

        mem_leak = self._detect_memory_leak(recent)
        if mem_leak:
            self.state.anomalies.append("⚠ Possible memory leak detected")
            self.state.anomaly_detected = True

    def _detect_memory_leak(self, recent: list) -> bool:
        if len(recent) < 15:
            return False
        first_half = recent[:len(recent)//2]
        second_half = recent[len(recent)//2:]
        avg_first = sum(r["mem"] for r in first_half) / len(first_half)
        avg_second = sum(r["mem"] for r in second_half) / len(second_half)
        return (avg_second - avg_first) > 10 and avg_second > 70

    def _assess_health(self, recent: list):
        latest = recent[-1]

        cpu_score = max(0, 100 - latest["cpu"]) / 100
        mem_score = max(0, 100 - latest["mem"]) / 100
        hr_score = min(1.0, latest["hash_rate"] / max(self._baselines["hr_baseline"], 1)) if latest["hash_rate"] > 0 else 0.5
        temp_score = max(0, 100 - latest["temp"]) / 100 if latest["temp"] > 0 else 0.8

        self.state.stability_score = (cpu_score * 0.3 + mem_score * 0.3 + hr_score * 0.2 + temp_score * 0.2)

        if self.state.stability_score > 0.8:
            self.state.overall_health = "excellent"
            self.state.performance_rating = "peak"
        elif self.state.stability_score > 0.6:
            self.state.overall_health = "good"
            self.state.performance_rating = "normal"
        elif self.state.stability_score > 0.4:
            self.state.overall_health = "fair"
            self.state.performance_rating = "degraded"
        else:
            self.state.overall_health = "critical"
            self.state.performance_rating = "emergency"

        if self.state.anomaly_detected and self.state.overall_health == "good":
            self.state.overall_health = "monitoring"

        self.state.consciousness_level = "awake" if self.state.stability_score > 0.3 else "sleeping"

    def _generate_recommendations(self):
        self.state.recommendations = []
        latest = self._history[-1] if self._history else {}

        if latest.get("cpu", 0) > 75:
            self.state.recommendations.append("Reduce worker count to lower CPU usage")
        if latest.get("mem", 0) > 80:
            self.state.recommendations.append("Close other applications to free memory")
        if latest.get("temp", 0) > 70:
            self.state.recommendations.append("Improve cooling - temperature elevated")
        if latest.get("hash_rate", 0) < self._baselines["hr_baseline"] * 0.5 and latest.get("hash_rate", 0) > 0:
            self.state.recommendations.append("Hashrate below baseline - consider restart")

        learning_insights = self.learning.get_insights()
        if "best worker" in learning_insights:
            self.state.recommendations.append(learning_insights)

    def get_consciousness_report(self) -> str:
        lines = [
            f"🧠 Self-Awareness Status: {self.state.consciousness_level.upper()}",
            f"📊 Health: {self.state.overall_health.upper()} ({self.state.stability_score:.2f})",
            f"⚡ Performance: {self.state.performance_rating}",
            f"🔍 Anomalies: {len(self.state.anomalies)} detected",
        ]
        if self.state.anomalies:
            for a in self.state.anomalies[:3]:
                lines.append(f"  {a}")
        if self.state.recommendations:
            for r in self.state.recommendations[:3]:
                lines.append(f"  💡 {r}")
        return "\n".join(lines)

    def get_stats(self) -> dict:
        return {
            "enabled": self.enabled,
            "health": self.state.overall_health,
            "stability": round(self.state.stability_score, 3),
            "performance": self.state.performance_rating,
            "anomalies": len(self.state.anomalies),
            "consciousness": self.state.consciousness_level,
            "observations": len(self._history),
            "baselines": self._baselines,
        }
