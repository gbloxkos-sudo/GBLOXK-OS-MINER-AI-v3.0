import time
import threading
from typing import Optional, Callable
from dataclasses import dataclass
from ai.alerts import AlertManager, Alert
from mining.worker import MiningWorker
from config import AppConfig
from utils.logger import setup_logger

logger = setup_logger(__name__)


@dataclass
class Incident:
    id: int
    incident_type: str
    severity: str
    detected_at: float
    resolved_at: Optional[float] = None
    description: str = ""
    action_taken: str = ""
    resolved: bool = False
    recovery_count: int = 0


class SelfHealingEngine:
    def __init__(self, config: AppConfig, alerts: AlertManager):
        self.config = config
        self.alerts = alerts
        self.enabled = True
        self.incidents: list[Incident] = []
        self._counter = 0
        self._worker_ref: Optional[MiningWorker] = None
        self._restart_callbacks: list[Callable] = []
        self._healing_thread: Optional[threading.Thread] = None
        self._last_health_check = 0
        self._recovery_attempts: dict[str, int] = {}
        self.MAX_RECOVERY_ATTEMPTS = 3

    def register_worker(self, worker: MiningWorker):
        self._worker_ref = worker

    def on_restart(self, cb: Callable):
        self._restart_callbacks.append(cb)

    def start(self):
        self._healing_thread = threading.Thread(target=self._heal_loop, daemon=True)
        self._healing_thread.start()
        logger.info("Self-Healing Engine activated")

    def _heal_loop(self):
        while self.enabled:
            try:
                if time.time() - self._last_health_check >= 3:
                    self._health_check()
                    self._last_health_check = time.time()
                time.sleep(1)
            except Exception as e:
                logger.error(f"Healing loop error: {e}")
                time.sleep(5)

    def _health_check(self):
        if not self._worker_ref:
            return

        worker = self._worker_ref

        if not worker.running and worker.is_alive() is False:
            self._handle_incident("worker_crash", "error",
                                  "Mining worker process crashed unexpectedly")

        if worker.paused and self._detect_forced_pause():
            self._handle_incident("forced_pause", "warning",
                                  "Mining paused due to system pressure - monitoring")

        if hasattr(worker, "stats"):
            hr = worker.stats.get("hash_rate", 0)
            if hr == 0 and worker.running and not worker.paused:
                duration = time.time() - worker.stats.get("start_time", time.time())
                if duration > 30:
                    self._handle_incident("zero_hashrate", "warning",
                                          f"Zero hash rate for {duration:.0f}s - reinitializing")

    def _handle_incident(self, incident_type: str, severity: str, description: str):
        now = time.time()
        key = f"{incident_type}"
        self._recovery_attempts[key] = self._recovery_attempts.get(key, 0) + 1
        attempts = self._recovery_attempts[key]

        if attempts > self.MAX_RECOVERY_ATTEMPTS:
            logger.error(f"Max recovery attempts reached for {incident_type}")
            return

        self._counter += 1
        incident = Incident(
            id=self._counter,
            incident_type=incident_type,
            severity=severity,
            detected_at=now,
            description=description,
        )

        action = self._determine_action(incident_type, severity, attempts)
        incident.action_taken = action
        self._execute_action(action, incident)
        incident.resolved = True
        incident.resolved_at = time.time()
        self.incidents.append(incident)

        if len(self.incidents) > 50:
            self.incidents = self.incidents[-30:]

    def _determine_action(self, incident_type: str, severity: str, attempts: int) -> str:
        actions = {
            "worker_crash": "restart_worker",
            "zero_hashrate": "reinitialize_worker",
            "forced_pause": "adjust_workers",
            "high_temperature": "throttle_workers",
            "memory_pressure": "reduce_workers",
        }
        base = actions.get(incident_type, "log_only")
        if attempts >= 2:
            return f"{base}_aggressive"
        return base

    def _execute_action(self, action: str, incident: Incident):
        worker = self._worker_ref
        if not worker:
            return

        if action == "restart_worker":
            logger.info("Self-healing: Restarting worker...")
            worker.running = False
            time.sleep(1)
            for cb in self._restart_callbacks:
                cb()
            self.alerts.alerts.append(
                Alert(id=self._counter + 100, severity="info",
                      message=f"🔄 Self-healed: Worker restarted after {incident.incident_type}",
                      timestamp=time.time())
            )

        elif action == "reinitialize_worker":
            logger.info("Self-healing: Reinitializing worker...")
            worker.running = False
            time.sleep(0.5)
            worker.stats["hash_rate"] = 0.0
            worker.stats["total_hashes"] = 0
            for cb in self._restart_callbacks:
                cb()

        elif action == "adjust_workers":
            new_count = max(1, worker.engine.workers - 1)
            worker.engine.workers = new_count
            logger.info(f"Self-healing: Reduced workers to {new_count}")
            self.alerts.alerts.append(
                Alert(id=self._counter + 101, severity="info",
                      message=f"🛠 Self-healed: Workers reduced to {new_count}",
                      timestamp=time.time())
            )

        elif action in ("throttle_workers", "throttle_workers_aggressive"):
            reduction = 2 if "aggressive" in action else 1
            new_count = max(1, worker.engine.workers - reduction)
            worker.engine.workers = new_count
            logger.info(f"Self-healing: Throttled workers to {new_count}")

        elif action in ("reduce_workers", "reduce_workers_aggressive"):
            reduction = 3 if "aggressive" in action else 1
            new_count = max(1, worker.engine.workers - reduction)
            worker.engine.workers = new_count
            logger.info(f"Self-healing: Reduced workers to {new_count} due to memory pressure")

    def _detect_forced_pause(self) -> bool:
        return False

    def get_stats(self) -> dict:
        return {
            "enabled": self.enabled,
            "total_incidents": len(self.incidents),
            "recent_incidents": self.incidents[-5:] if self.incidents else [],
            "recovery_attempts": dict(self._recovery_attempts),
        }
