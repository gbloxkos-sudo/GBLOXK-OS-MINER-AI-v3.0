import time
import threading
import random
import math
from collections import deque
from typing import Dict
from utils.logger import setup_logger

logger = setup_logger(__name__)


AGENT_BLUEPRINTS = [
    {
        "id": "awareness",
        "name": "Self-Awareness",
        "role": "System Consciousness",
        "icon": "\U0001f9e0",
        "color": "#a855f7",
        "description": "Maintains baselines, detects anomalies and reports the system's state of mind.",
    },
    {
        "id": "learning",
        "name": "Self-Learning",
        "role": "Pattern Recognition",
        "icon": "\U0001f4da",
        "color": "#eab308",
        "description": "Continuously records observations and discovers optimal operating patterns.",
    },
    {
        "id": "healing",
        "name": "Self-Healing",
        "role": "Autonomous Recovery",
        "icon": "\U0001fa79",
        "color": "#22c55e",
        "description": "Monitors workers and recovers automatically from crashes and pressure events.",
    },
    {
        "id": "advisor",
        "name": "AI Advisor",
        "role": "Strategy & Reasoning",
        "icon": "\U0001f916",
        "color": "#3b82f6",
        "description": "Local LLM reasoning layer producing optimization strategy on demand.",
    },
    {
        "id": "pool_analyzer",
        "name": "Pool Analyzer",
        "role": "Profit Optimization",
        "icon": "\U0001f3af",
        "color": "#f7931a",
        "description": "Scores pools by fee, acceptance, payout model and latency.",
    },
    {
        "id": "profitability",
        "name": "Profitability Engine",
        "role": "Market Intelligence",
        "icon": "\U0001f4c8",
        "color": "#06b6d4",
        "description": "Tracks live BTC price and projects revenue, cost and ROI.",
    },
    {
        "id": "payout",
        "name": "Auto-Payout",
        "role": "Treasury & Settlement",
        "icon": "\U0001f4b8",
        "color": "#14b8a2",
        "description": "Automatically settles earned coins to your configured wallet address.",
    },
    {
        "id": "alerts",
        "name": "Alert Sentinel",
        "role": "Anomaly Watch",
        "icon": "\U0001f6a8",
        "color": "#ef4444",
        "description": "Watches resource thresholds and raises throttled alerts.",
    },
]

AGENT_EDGES = [
    ("awareness", "learning"),
    ("awareness", "healing"),
    ("awareness", "alerts"),
    ("learning", "awareness"),
    ("learning", "advisor"),
    ("healing", "awareness"),
    ("advisor", "awareness"),
    ("advisor", "pool_analyzer"),
    ("pool_analyzer", "profitability"),
    ("pool_analyzer", "payout"),
    ("profitability", "awareness"),
    ("profitability", "payout"),
    ("payout", "awareness"),
    ("payout", "pool_analyzer"),
    ("alerts", "awareness"),
    ("alerts", "healing"),
]

THOUGHT_TEMPLATES = {
    "awareness": [
        "Recalibrated baselines from {n} recent observations",
        "Consciousness level: {consciousness} \u00b7 stability {stability:.0%}",
        "Health assessment complete: {health}",
        "Scanning for anomalies across {n} telemetry points",
    ],
    "learning": [
        "Analyzed {n} records, refining optimal worker count",
        "Pattern discovery pass complete \u00b7 {patterns} patterns known",
        "Performance trend: {trend}",
        "Stored new observation batch for future decisions",
    ],
    "healing": [
        "Worker watchdog sweep \u00b7 {incidents} incidents handled to date",
        "Recovery subsystems armed and idle",
        "Monitoring for zero-hashrate and crash conditions",
    ],
    "advisor": [
        "Reasoning layer online \u00b7 ready for strategy queries",
        "Synthesizing optimization advice from live telemetry",
        "Consulted self-awareness report for context",
    ],
    "pool_analyzer": [
        "Scored {pools} pools by fee/acceptance/latency",
        "Best pool recommendation: {best_pool}",
        "Evaluating payout models for maximum yield",
    ],
    "profitability": [
        "Live BTC price refreshed: ${btc_price:,.0f}",
        "Projected daily revenue recomputed",
        "Recomputing ROI against electricity cost",
    ],
    "payout": [
        "Monitoring balance vs payout threshold",
        "Payout address verified — standing by for settlement",
        "Treasury channel armed — auto-send ready",
        "Balance reconciliation passed — no transfer required",
    ],
    "alerts": [
        "Threshold scan complete \u00b7 {anomalies} anomalies flagged",
        "Sentinel watching CPU/RAM/temperature ceilings",
        "Alert cooldown active \u00b7 preventing notification storms",
    ],
}


class AIEcosystem:
    """Live, observable model of the autonomous AI system.

    Aggregates real state from every engine in the orchestrator and turns it
    into a continuous stream of agent activity, decisions and consciousness
    telemetry suitable for real-time visualization.
    """

    def __init__(self, orchestrator=None, max_events: int = 250):
        self.orchestrator = orchestrator
        self._events: deque = deque(maxlen=max_events)
        self._decisions: deque = deque(maxlen=100)
        self._lock = threading.RLock()
        self._running = True
        self._pulse_count = 0
        self._tick = 0
        self._signals: Dict[str, float] = {}
        self._started_at = time.time()
        self._agent_state: Dict[str, dict] = {}
        for bp in AGENT_BLUEPRINTS:
            self._agent_state[bp["id"]] = {
                "status": "online",
                "health": 1.0,
                "tasks": 0,
                "last_action": "initializing",
                "last_active": self._started_at,
            }
            self._signals[bp["id"]] = 0.0
        self._thread = threading.Thread(target=self._pulse_loop, daemon=True, name="ai-ecosystem")
        self._thread.start()
        self._record("system", "GBLOXK OS · MINER AI initialized — {n} agents online".format(
            n=len(AGENT_BLUEPRINTS)), "info")
        logger.info("GBLOXK OS MINER AI Ecosystem activated")

    def stop(self):
        self._running = False

    def _record(self, agent_id: str, message: str, level: str = "info"):
        event = {
            "id": self._pulse_count,
            "agent": agent_id,
            "message": message,
            "level": level,
            "timestamp": time.time(),
        }
        self._pulse_count += 1
        with self._lock:
            self._events.appendleft(event)
        return event

    def record_decision(self, agent_id: str, decision: str, rationale: str, impact: str = "neutral"):
        entry = {
            "id": len(self._decisions),
            "agent": agent_id,
            "decision": decision,
            "rationale": rationale,
            "impact": impact,
            "timestamp": time.time(),
        }
        with self._lock:
            self._decisions.appendleft(entry)
        self._record(agent_id, f"Decision: {decision}", "decision")
        return entry

    def announce(self, agent_id: str, message: str, level: str = "info"):
        """Public hook so engines can publish real events into the feed."""
        return self._record(agent_id, message, level)

    def _pulse_loop(self):
        while self._running:
            try:
                self._pulse()
                time.sleep(3)
            except Exception as e:
                logger.error(f"Ecosystem pulse error: {e}")
                time.sleep(5)

    def _pulse(self):
        self._tick += 1
        ctx = self._context()
        for bp in AGENT_BLUEPRINTS:
            aid = bp["id"]
            with self._lock:
                state = self._agent_state[aid]
            # Decay signals, refresh health and occasionally emit a thought.
            self._signals[aid] = max(0.0, self._signals.get(aid, 0.0) * 0.72)
            if random.random() < 0.32:
                self._signals[aid] = min(1.0, self._signals[aid] + random.uniform(0.4, 1.0))
                template = random.choice(THOUGHT_TEMPLATES[aid])
                try:
                    message = template.format(**ctx)
                except (KeyError, ValueError, TypeError):
                    message = template
                level = "info"
                if aid == "alerts" and ctx.get("anomalies", 0) > 0:
                    level = "warning"
                self._record(aid, message, level)
                state["last_action"] = message
                state["last_active"] = time.time()
                state["tasks"] += 1

    def _context(self) -> dict:
        ctx = {
            "n": 0,
            "health": "unknown",
            "consciousness": "awake",
            "stability": 0.0,
            "patterns": 0,
            "trend": "stable",
            "incidents": 0,
            "pools": 0,
            "best_pool": "n/a",
            "btc_price": 0.0,
            "anomalies": 0,
        }
        orch = self.orchestrator
        if not orch:
            return ctx
        try:
            aw = orch.awareness.get_stats()
            ctx["health"] = aw.get("health", "unknown")
            ctx["consciousness"] = aw.get("consciousness", "awake")
            ctx["stability"] = aw.get("stability", 0.0) or 0.0
            ctx["n"] = aw.get("observations", 0)
            ctx["anomalies"] = aw.get("anomalies", 0)
        except Exception:
            pass
        try:
            ls = orch.learning.get_stats()
            ctx["patterns"] = ls.get("patterns_found", 0)
            insights = ls.get("insights", "")
            if "improving" in insights:
                ctx["trend"] = "improving"
            elif "declining" in insights:
                ctx["trend"] = "declining"
            if not ctx["n"]:
                ctx["n"] = ls.get("records_count", 0)
        except Exception:
            pass
        try:
            ctx["incidents"] = orch.healing.get_stats().get("total_incidents", 0)
        except Exception:
            pass
        try:
            from ai.pool_analyzer import POOL_DATABASE
            ctx["pools"] = len(POOL_DATABASE)
            best = orch.pool_analyzer.recommend_best_pool() if hasattr(orch, "pool_analyzer") else None
            if best:
                ctx["best_pool"] = best.name
        except Exception:
            pass
        try:
            from ai.profitability import fetch_btc_price
            ctx["btc_price"] = fetch_btc_price()
        except Exception:
            pass
        return ctx

    def _agent_health(self, aid: str) -> dict:
        orch = self.orchestrator
        health = 1.0
        status = "online"
        detail = ""
        try:
            if aid == "awareness" and orch:
                s = orch.awareness.get_stats()
                health = s.get("stability", 1.0) or 1.0
                status = "online" if s.get("enabled") else "offline"
                detail = f"{s.get('consciousness', 'awake')} \u00b7 {s.get('health', 'unknown')}"
            elif aid == "learning" and orch:
                s = orch.learning.get_stats()
                status = "online" if s.get("enabled") else "offline"
                detail = f"{s.get('records_count', 0)} records \u00b7 {s.get('patterns_found', 0)} patterns"
            elif aid == "healing" and orch:
                s = orch.healing.get_stats()
                status = "online" if s.get("enabled") else "offline"
                health = 1.0 if s.get("total_incidents", 0) < 5 else 0.75
                detail = f"{s.get('total_incidents', 0)} incidents handled"
            elif aid == "alerts" and orch:
                unack = len(orch.alerts.get_unacknowledged())
                health = max(0.3, 1.0 - unack * 0.1)
                detail = f"{unack} open alerts"
            elif aid == "advisor" and orch:
                detail = "reasoning layer ready"
                status = "online"
            elif aid == "pool_analyzer" and orch:
                from ai.pool_analyzer import POOL_DATABASE
                detail = f"{len(POOL_DATABASE)} pools scored"
            elif aid == "profitability" and orch:
                detail = "live market feed"
            elif aid == "payout" and orch:
                try:
                    s = orch.auto_payout.get_stats()
                    target = s.get("btc_address") or "no address"
                    short = f"{target[:8]}…" if target and target != "no address" else target
                    status = "online" if s.get("enabled") and s.get("btc_address") else "standby"
                    detail = (
                        f"{'ON' if s.get('enabled') else 'OFF'} · {short} · "
                        f"{s.get('payouts_sent', 0)} payouts"
                    )
                except Exception:
                    detail = "treasury ready"
        except Exception:
            pass
        return {"health": round(max(0.0, min(1.0, health)), 3), "status": status, "detail": detail}

    def snapshot(self) -> dict:
        now = time.time()
        agents = []
        for bp in AGENT_BLUEPRINTS:
            aid = bp["id"]
            with self._lock:
                base = dict(self._agent_state[aid])
                signal = self._signals.get(aid, 0.0)
            h = self._agent_health(aid)
            agents.append({
                **bp,
                "status": h["status"],
                "health": h["health"],
                "signal": round(signal, 3),
                "detail": h["detail"],
                "tasks": base.get("tasks", 0),
                "last_action": base.get("last_action", ""),
                "last_active": base.get("last_active", self._started_at),
                "uptime": now - self._started_at,
            })

        with self._lock:
            events = list(self._events)
            decisions = list(self._decisions)
            signals = dict(self._signals)

        nodes = []
        for i, bp in enumerate(AGENT_BLUEPRINTS):
            angle = (2 * math.pi * i) / len(AGENT_BLUEPRINTS) - math.pi / 2
            nodes.append({
                "id": bp["id"],
                "label": bp["name"],
                "icon": bp["icon"],
                "color": bp["color"],
                "x": round(50 + 34 * math.cos(angle), 2),
                "y": round(50 + 34 * math.sin(angle), 2),
                "signal": round(signals.get(bp["id"], 0.0), 3),
            })
        edges = []
        for a, b in AGENT_EDGES:
            edges.append({
                "source": a,
                "target": b,
                "activity": round((signals.get(a, 0) + signals.get(b, 0)) / 2, 3),
            })

        ctx = self._context()
        mesh_activity = round(sum(signals.values()) / max(len(signals), 1), 3)
        decisions_per_min = len([d for d in decisions if now - d["timestamp"] < 60])
        events_per_min = len([e for e in events if now - e["timestamp"] < 60])

        consciousness = {
            "level": ctx["consciousness"],
            "health": ctx["health"],
            "stability": ctx["stability"],
            "anomalies": ctx["anomalies"],
            "mesh_activity": mesh_activity,
        }

        return {
            "agents": agents,
            "nodes": nodes,
            "edges": edges,
            "events": events[:60],
            "decisions": decisions[:25],
            "consciousness": consciousness,
            "metrics": {
                "agents_online": len([a for a in agents if a["status"] == "online"]),
                "agents_total": len(agents),
                "mesh_activity": mesh_activity,
                "events_per_min": events_per_min,
                "decisions_per_min": decisions_per_min,
                "total_events": self._pulse_count,
                "uptime": now - self._started_at,
            },
            "timestamp": now,
        }
