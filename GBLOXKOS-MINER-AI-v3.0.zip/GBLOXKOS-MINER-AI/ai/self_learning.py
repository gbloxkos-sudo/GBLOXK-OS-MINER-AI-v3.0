import time
import json
import os
import threading
from typing import Optional
from dataclasses import dataclass, asdict
from config import AppConfig
from utils.logger import setup_logger

logger = setup_logger(__name__)

LEARNING_DATA_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "learning_data.json")


@dataclass
class LearningRecord:
    timestamp: float
    hash_rate: float
    difficulty: int
    workers: int
    cpu_usage: float
    memory_usage: float
    temperature: float
    blocks_found: int
    mode: str
    performance_score: float = 0.0


class SelfLearningEngine:
    def __init__(self, config: AppConfig):
        self.config = config
        self.enabled = True
        self.records: list[LearningRecord] = []
        self.patterns: dict = {
            "best_worker_counts": {},
            "best_difficulty_levels": {},
            "mode_performance": {},
            "time_of_day_analysis": {},
            "resource_patterns": [],
        }
        self._lock = threading.Lock()
        self._load()
        self._learning_thread = threading.Thread(target=self._learn_loop, daemon=True)
        self._learning_thread.start()
        logger.info("Self-Learning Engine activated")

    def _load(self):
        try:
            if os.path.exists(LEARNING_DATA_PATH):
                with open(LEARNING_DATA_PATH) as f:
                    data = json.load(f)
                self.records = [LearningRecord(**r) for r in data.get("records", [])]
                self.patterns = data.get("patterns", self.patterns)
                logger.info(f"Loaded {len(self.records)} learning records")
        except Exception as e:
            logger.warning(f"Could not load learning data: {e}")

    def _save(self):
        try:
            os.makedirs(os.path.dirname(LEARNING_DATA_PATH), exist_ok=True)
            with open(LEARNING_DATA_PATH, "w") as f:
                json.dump({
                    "records": [asdict(r) for r in self.records[-200:]],
                    "patterns": self.patterns,
                }, f, indent=2)
        except Exception as e:
            logger.warning(f"Could not save learning data: {e}")

    def record_observation(self, hash_rate: float, difficulty: int, workers: int,
                           cpu_usage: float, memory_usage: float, temperature: float,
                           blocks_found: int, mode: str):
        if not self.enabled:
            return
        score = self._compute_performance_score(hash_rate, cpu_usage, memory_usage, temperature)
        record = LearningRecord(
            timestamp=time.time(),
            hash_rate=hash_rate,
            difficulty=difficulty,
            workers=workers,
            cpu_usage=cpu_usage,
            memory_usage=memory_usage,
            temperature=temperature,
            blocks_found=blocks_found,
            mode=mode,
            performance_score=score,
        )
        with self._lock:
            self.records.append(record)
            if len(self.records) > 500:
                self.records = self.records[-300:]

    def _compute_performance_score(self, hash_rate: float, cpu: float, mem: float, temp: float) -> float:
        hr_score = min(1.0, hash_rate / 5000)
        cpu_penalty = max(0, (cpu - 50) / 50) * 0.3
        mem_penalty = max(0, (mem - 60) / 40) * 0.3
        temp_penalty = max(0, (temp - 60) / 30) * 0.4 if temp > 0 else 0
        return max(0, hr_score - cpu_penalty - mem_penalty - temp_penalty)

    def _learn_loop(self):
        while self.enabled:
            try:
                if len(self.records) >= 10:
                    self._analyze_patterns()
                    self._save()
                time.sleep(60)
            except Exception as e:
                logger.error(f"Learning error: {e}")
                time.sleep(120)

    def _analyze_patterns(self):
        with self._lock:
            if not self.records:
                return

            latest = self.records[-50:]
            grouped_by_workers: dict[int, list] = {}
            grouped_by_diff: dict[int, list] = {}
            grouped_by_mode: dict[str, list] = {}

            for r in latest:
                grouped_by_workers.setdefault(r.workers, []).append(r.performance_score)
                grouped_by_diff.setdefault(r.difficulty, []).append(r.performance_score)
                grouped_by_mode.setdefault(r.mode, []).append(r.performance_score)

            self.patterns["best_worker_counts"] = {
                str(k): sum(v) / len(v) for k, v in grouped_by_workers.items()
            }
            self.patterns["best_difficulty_levels"] = {
                str(k): sum(v) / len(v) for k, v in grouped_by_diff.items()
            }
            self.patterns["mode_performance"] = {
                k: sum(v) / len(v) for k, v in grouped_by_mode.items()
            }

            hour = time.localtime().tm_hour
            hour_group = [r for r in latest if abs(time.localtime(r.timestamp).tm_hour - hour) <= 1]
            if hour_group:
                self.patterns["time_of_day_analysis"][str(hour)] = {
                    "avg_score": sum(r.performance_score for r in hour_group) / len(hour_group),
                    "samples": len(hour_group),
                }

    def get_optimal_workers(self, mode: str) -> Optional[int]:
        if self.patterns["best_worker_counts"]:
            scored = sorted(
                [(int(k), v) for k, v in self.patterns["best_worker_counts"].items()],
                key=lambda x: x[1], reverse=True
            )
            if scored:
                return scored[0][0]
        return None

    def get_optimal_difficulty(self, mode: str) -> Optional[int]:
        if self.patterns["best_difficulty_levels"]:
            scored = sorted(
                [(int(k), v) for k, v in self.patterns["best_difficulty_levels"].items()],
                key=lambda x: x[1], reverse=True
            )
            if scored:
                return scored[0][0]
        return None

    def get_best_mode(self) -> Optional[str]:
        if self.patterns["mode_performance"]:
            scored = sorted(
                self.patterns["mode_performance"].items(),
                key=lambda x: x[1], reverse=True
            )
            if scored:
                return scored[0][0]
        return None

    def get_insights(self) -> str:
        insights = []
        if self.patterns["best_worker_counts"]:
            best_w = max(self.patterns["best_worker_counts"], key=self.patterns["best_worker_counts"].get)
            insights.append(f"Best worker count historically: {best_w}")
        if self.patterns["best_difficulty_levels"]:
            best_d = max(self.patterns["best_difficulty_levels"], key=self.patterns["best_difficulty_levels"].get)
            insights.append(f"Best difficulty historically: {best_d}")
        if self.patterns["mode_performance"]:
            best_m = max(self.patterns["mode_performance"], key=self.patterns["mode_performance"].get)
            insights.append(f"Best performing mode: {best_m}")
        if self.records:
            recent = self.records[-10:]
            trend = "improving" if recent[-1].performance_score > recent[0].performance_score else "declining"
            insights.append(f"Performance trend: {trend}")
        return " | ".join(insights) if insights else "Learning: insufficient data"

    def get_stats(self) -> dict:
        return {
            "enabled": self.enabled,
            "records_count": len(self.records),
            "patterns_found": len(self.patterns.get("best_worker_counts", {})),
            "insights": self.get_insights(),
        }
