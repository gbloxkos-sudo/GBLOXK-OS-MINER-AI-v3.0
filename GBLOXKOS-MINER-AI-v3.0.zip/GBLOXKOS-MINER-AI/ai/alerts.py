import time
from typing import Optional, Callable
from dataclasses import dataclass
from ai.analyzer import ResourceProfile
from utils.logger import setup_logger

logger = setup_logger(__name__)


@dataclass
class Alert:
    id: int
    severity: str
    message: str
    timestamp: float
    acknowledged: bool = False


class AlertManager:
    def __init__(self, on_alert: Optional[Callable] = None):
        self.on_alert = on_alert
        self.alerts: list[Alert] = []
        self._counter = 0
        self._thresholds = {
            "cpu_max": 85.0,
            "memory_max": 90.0,
            "temp_max": 80.0,
            "hashrate_min": 0.0,
            "acceptance_min": 50.0,
        }
        self._previous_profile: Optional[ResourceProfile] = None
        self._last_alert_time: dict[str, float] = {}
        self._alert_cooldown = 60.0

    def set_threshold(self, name: str, value: float):
        if name in self._thresholds:
            self._thresholds[name] = value

    def check(self, profile: Optional[ResourceProfile] = None, stats: Optional[dict] = None):
        checks = []
        now = time.time()

        if profile:
            if profile.cpu_percent > self._thresholds["cpu_max"]:
                checks.append(("warning", f"CPU usage critical: {profile.cpu_percent:.1f}%"))
            if profile.memory_percent > self._thresholds["memory_max"]:
                checks.append(("error", f"Memory usage critical: {profile.memory_percent:.1f}%"))
            if profile.temperature and profile.temperature > self._thresholds["temp_max"]:
                checks.append(("error", f"Temperature critical: {profile.temperature:.1f}°C"))

            if (self._previous_profile and
                abs(profile.cpu_percent - self._previous_profile.cpu_percent) > 20 and
                profile.cpu_percent > 70):
                checks.append(("info", f"CPU spike detected: {profile.cpu_percent:.1f}%"))

            self._previous_profile = profile

        if stats:
            hr = stats.get("hash_rate", 0)
            if 0 < hr < self._thresholds["hashrate_min"]:
                checks.append(("warning", f"Hash rate below threshold: {hr:.0f} H/s"))

            is_pool_mining = stats.get("pool") is not None
            acceptance = stats.get("acceptance_rate", 100)
            if is_pool_mining and acceptance < self._thresholds["acceptance_min"]:
                checks.append(("error", f"Share acceptance rate low: {acceptance:.1f}%"))

        for severity, msg in checks:
            if msg in self._last_alert_time:
                if now - self._last_alert_time[msg] < self._alert_cooldown:
                    continue
            self._last_alert_time[msg] = now
            self._counter += 1
            alert = Alert(id=self._counter, severity=severity, message=msg, timestamp=time.time())
            self.alerts.append(alert)
            logger.warning(f"ALERT [{severity.upper()}]: {msg}")
            if self.on_alert:
                self.on_alert(alert)

        if len(self.alerts) > 100:
            self.alerts = self.alerts[-50:]

    def get_unacknowledged(self) -> list:
        return [a for a in self.alerts if not a.acknowledged]

    def acknowledge(self, alert_id: int):
        for a in self.alerts:
            if a.id == alert_id:
                a.acknowledged = True
                break

    def acknowledge_all(self):
        for a in self.alerts:
            a.acknowledged = True
