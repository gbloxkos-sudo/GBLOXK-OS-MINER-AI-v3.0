import time
import secrets
from dataclasses import dataclass
from typing import Optional
from utils.logger import setup_logger

logger = setup_logger(__name__)


@dataclass
class StratumJob:
    job_id: str
    prev_hash: str
    coinbase1: str
    coinbase2: str
    merkle_branches: list
    version: str
    nbits: str
    ntime: str
    difficulty: int
    clean_jobs: bool = True


@dataclass
class StratumShare:
    worker_name: str
    job_id: str
    nonce: int
    hash: str
    time_submitted: float = 0.0
    accepted: bool = False


class StratumV2Simulator:
    def __init__(self, difficulty: int = 4):
        self.difficulty = difficulty
        self.current_job: Optional[StratumJob] = None
        self.shares: list[StratumShare] = []
        self.accepted_count = 0
        self.rejected_count = 0

    def create_job(self, transactions: str, previous_hash: str) -> StratumJob:
        self.current_job = StratumJob(
            job_id=secrets.token_hex(4),
            prev_hash=previous_hash,
            coinbase1=transactions.encode().hex(),
            coinbase2="",
            merkle_branches=[],
            version="20000000",
            nbits="1d00ffff",
            ntime=hex(int(time.time()))[2:],
            difficulty=self.difficulty,
            clean_jobs=True,
        )
        return self.current_job

    def submit_share(self, worker_name: str, nonce: int, block_hash: str) -> bool:
        prefix = "0" * self.difficulty
        accepted = block_hash.startswith(prefix)

        share = StratumShare(
            worker_name=worker_name,
            job_id=self.current_job.job_id if self.current_job else "",
            nonce=nonce,
            hash=block_hash,
            time_submitted=time.time(),
            accepted=accepted,
        )
        self.shares.append(share)
        if accepted:
            self.accepted_count += 1
        else:
            self.rejected_count += 1

        logger.debug(f"Share {'accepted' if accepted else 'rejected'} by {worker_name}")
        return accepted

    def get_stats(self) -> dict:
        return {
            "total_shares": len(self.shares),
            "accepted": self.accepted_count,
            "rejected": self.rejected_count,
            "acceptance_rate": (self.accepted_count / max(len(self.shares), 1)) * 100,
            "current_difficulty": self.difficulty,
        }
