#!/usr/bin/env python3
"""
GBLOXK OS · MINER AI v3.0
Autonomous AI Mining Operating System
Self-Healing · Self-Learning · Self-Awareness · Auto-Payout
"""

import sys
import os
import signal

_project_root = os.path.dirname(os.path.abspath(__file__))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)


_shutdown_in_progress = False


def shutdown_all(signum=None, frame=None):
    global _shutdown_in_progress
    if _shutdown_in_progress:
        return
    _shutdown_in_progress = True

    try:
        from rich.console import Console
        console = Console()
        console.print("\n[yellow]⏳ Graceful shutdown in progress...[/]")
    except:
        pass

    try:
        from cli.commands import MINING_SESSION, STRATUM_SERVER, API_SERVER, POOL_CLIENT
        if MINING_SESSION.get("running"):
            orch = MINING_SESSION.get("orchestrator")
            if orch:
                try:
                    orch.stop()
                except:
                    pass
            MINING_SESSION["running"] = False
            MINING_SESSION["orchestrator"] = None

        if STRATUM_SERVER:
            try:
                STRATUM_SERVER.stop()
            except:
                pass

        if POOL_CLIENT:
            try:
                POOL_CLIENT.disconnect()
            except:
                pass

        if API_SERVER:
            try:
                API_SERVER.stop()
            except:
                pass

        try:
            from api.server import stop_api
            stop_api()
        except:
            pass
    except:
        pass

    try:
        import psutil
        current = psutil.Process()
        for child in current.children(recursive=True):
            try:
                child.terminate()
            except:
                pass
        gone, alive = psutil.wait_procs(current.children(), timeout=3)
        for p in alive:
            try:
                p.kill()
            except:
                pass
    except:
        pass

    try:
        from rich.console import Console
        console = Console()
        console.print("[green]✅ All systems stopped. Goodbye![/]")
    except:
        pass

    os._exit(0)


signal.signal(signal.SIGINT, shutdown_all)
signal.signal(signal.SIGTERM, shutdown_all)

from cli.commands import cli as _cli

cli = _cli

if __name__ == "__main__":
    try:
        cli()
    except KeyboardInterrupt:
        shutdown_all()
    except SystemExit:
        shutdown_all()
    finally:
        shutdown_all()
