import sqlite3
import os
import threading
import json
import time
from typing import Optional


class DatabaseManager:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._lock = threading.RLock()
        os.makedirs(os.path.dirname(db_path) or ".", exist_ok=True)
        self._conn = sqlite3.connect(db_path, check_same_thread=False, timeout=10)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA busy_timeout=5000")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._init_db()

    def close(self):
        with self._lock:
            if self._conn:
                self._conn.close()
                self._conn = None

    def _init_db(self):
        with self._lock:
            self._conn.executescript("""
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    password_hash TEXT NOT NULL,
                    email TEXT,
                    created_at REAL NOT NULL,
                    last_login REAL,
                    is_admin INTEGER DEFAULT 0
                );
                CREATE TABLE IF NOT EXISTS mining_sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    start_time REAL NOT NULL,
                    end_time REAL,
                    blocks_found INTEGER DEFAULT 0,
                    total_hashes INTEGER DEFAULT 0,
                    avg_hash_rate REAL DEFAULT 0,
                    difficulty_level INTEGER DEFAULT 4,
                    status TEXT DEFAULT 'active',
                    FOREIGN KEY (user_id) REFERENCES users(id)
                );
                CREATE TABLE IF NOT EXISTS blocks_found (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id INTEGER,
                    block_index INTEGER,
                    block_hash TEXT,
                    nonce INTEGER,
                    difficulty INTEGER,
                    timestamp REAL,
                    reward REAL,
                    FOREIGN KEY (session_id) REFERENCES mining_sessions(id)
                );
                CREATE TABLE IF NOT EXISTS ai_advice (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id INTEGER,
                    timestamp REAL NOT NULL,
                    advice_type TEXT,
                    advice_text TEXT,
                    metrics_snapshot TEXT,
                    FOREIGN KEY (session_id) REFERENCES mining_sessions(id)
                );
                CREATE TABLE IF NOT EXISTS feedback (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    content TEXT NOT NULL,
                    rating INTEGER DEFAULT 5,
                    created_at REAL NOT NULL,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                );
                CREATE TABLE IF NOT EXISTS wallet (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER UNIQUE,
                    btc_address TEXT,
                    balance_satoshi INTEGER DEFAULT 0,
                    total_earned_satoshi INTEGER DEFAULT 0,
                    total_withdrawn_satoshi INTEGER DEFAULT 0,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                );
                CREATE TABLE IF NOT EXISTS withdrawal_requests (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    amount_satoshi INTEGER NOT NULL,
                    btc_address TEXT NOT NULL,
                    status TEXT DEFAULT 'pending',
                    created_at REAL NOT NULL,
                    completed_at REAL,
                    tx_hash TEXT,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                );
            """)
            self._ensure_column("wallet", "auto_payout_enabled", "INTEGER DEFAULT 0")
            self._ensure_column("wallet", "payout_threshold_satoshi", "INTEGER DEFAULT 100000")
            self._ensure_column("wallet", "last_payout_at", "REAL")
            self._conn.commit()

    def _ensure_column(self, table: str, column: str, ddl: str):
        """Add a missing column to an existing table (safe migration)."""
        try:
            cols = [r["name"] for r in self._conn.execute(f"PRAGMA table_info({table})").fetchall()]
            if column not in cols:
                self._conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}")
                self._conn.commit()
        except sqlite3.Error as e:
            raise RuntimeError(f"Migration failed for {table}.{column}: {e}") from e

    def authenticate_user(self, username: str, password: str) -> Optional[int]:
        with self._lock:
            row = self._conn.execute(
                "SELECT id, password_hash FROM users WHERE username = ?", (username,)
            ).fetchone()
            if row and row["password_hash"] == self._hash_password(password):
                user_id = row["id"]
                self._conn.execute("UPDATE users SET last_login = ? WHERE id = ?", (time.time(), user_id))
                self._conn.commit()
                return user_id
            return None

    def register_user(self, username: str, password: str, email: str = "") -> int | bool:
        with self._lock:
            try:
                cursor = self._conn.execute(
                    "INSERT INTO users (username, password_hash, email, created_at) VALUES (?, ?, ?, ?)",
                    (username, self._hash_password(password), email, time.time()),
                )
                self._conn.commit()
                return cursor.lastrowid
            except sqlite3.IntegrityError:
                return False

    def create_session(self, user_id: int, difficulty: int) -> int:
        with self._lock:
            cursor = self._conn.execute(
                "INSERT INTO mining_sessions (user_id, start_time, difficulty_level) VALUES (?, ?, ?)",
                (user_id, time.time(), difficulty),
            )
            session_id = cursor.lastrowid
            self._conn.commit()
            return session_id

    def end_session(self, session_id: int, stats: dict):
        with self._lock:
            self._conn.execute(
                """UPDATE mining_sessions SET end_time = ?, blocks_found = ?,
                   total_hashes = ?, avg_hash_rate = ?, status = 'completed' WHERE id = ?""",
                (time.time(), stats.get("blocks_found", 0),
                 stats.get("total_hashes", 0), stats.get("hash_rate", 0), session_id),
            )
            self._conn.commit()

    def save_block(self, session_id: int, block: dict, reward: float):
        with self._lock:
            self._conn.execute(
                """INSERT INTO blocks_found (session_id, block_index, block_hash,
                   nonce, difficulty, timestamp, reward) VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (session_id, block["index"], block["hash"],
                 block["nonce"], block["difficulty"], block["timestamp"], reward),
            )
            self._conn.commit()

    def save_ai_advice(self, session_id: int, advice_type: str, advice: str, metrics: dict):
        with self._lock:
            self._conn.execute(
                "INSERT INTO ai_advice (session_id, timestamp, advice_type, advice_text, metrics_snapshot) VALUES (?, ?, ?, ?, ?)",
                (session_id, time.time(), advice_type, advice, json.dumps(metrics)),
            )
            self._conn.commit()

    def save_feedback(self, user_id: int, content: str, rating: int = 5):
        with self._lock:
            self._conn.execute(
                "INSERT INTO feedback (user_id, content, rating, created_at) VALUES (?, ?, ?, ?)",
                (user_id, content, rating, time.time()),
            )
            self._conn.commit()

    def get_session_history(self, user_id: int) -> list:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM mining_sessions WHERE user_id = ? ORDER BY start_time DESC LIMIT 50",
                (user_id,),
            ).fetchall()
            return [dict(r) for r in rows]

    def get_user_by_id(self, user_id: int) -> Optional[dict]:
        with self._lock:
            row = self._conn.execute(
                "SELECT id, username, email, created_at, last_login, is_admin FROM users WHERE id = ?",
                (user_id,),
            ).fetchone()
            return dict(row) if row else None

    def get_wallet(self, user_id: int) -> dict:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM wallet WHERE user_id = ?", (user_id,)
            ).fetchone()
            if not row:
                self._conn.execute(
                    "INSERT INTO wallet (user_id, balance_satoshi) VALUES (?, 0)",
                    (user_id,),
                )
                self._conn.commit()
                return {"user_id": user_id, "btc_address": None, "balance_satoshi": 0,
                        "total_earned_satoshi": 0, "total_withdrawn_satoshi": 0}
            return dict(row)

    def credit_wallet(self, user_id: int, satoshi: int):
        with self._lock:
            self._conn.execute(
                "UPDATE wallet SET balance_satoshi = balance_satoshi + ?, "
                "total_earned_satoshi = total_earned_satoshi + ? WHERE user_id = ?",
                (satoshi, satoshi, user_id),
            )
            self._conn.commit()

    def withdraw_wallet(self, user_id: int, satoshi: int, btc_address: str) -> bool:
        with self._lock:
            row = self._conn.execute(
                "SELECT balance_satoshi FROM wallet WHERE user_id = ?", (user_id,)
            ).fetchone()
            if not row or row["balance_satoshi"] < satoshi:
                return False
            self._conn.execute(
                "UPDATE wallet SET balance_satoshi = balance_satoshi - ?, "
                "total_withdrawn_satoshi = total_withdrawn_satoshi + ? WHERE user_id = ?",
                (satoshi, satoshi, user_id),
            )
            self._conn.execute(
                "INSERT INTO withdrawal_requests (user_id, amount_satoshi, btc_address, "
                "status, created_at) VALUES (?, ?, ?, 'pending', ?)",
                (user_id, satoshi, btc_address, time.time()),
            )
            self._conn.commit()
            return True

    def set_wallet_address(self, user_id: int, btc_address: str) -> bool:
        """Save the crypto payout address for a user's wallet."""
        from utils.helpers import valid_crypto_address
        if not valid_crypto_address(btc_address):
            return False
        with self._lock:
            self.get_wallet(user_id)
            self._conn.execute(
                "UPDATE wallet SET btc_address = ? WHERE user_id = ?",
                (btc_address.strip(), user_id),
            )
            self._conn.commit()
        return True

    def set_auto_payout(self, user_id: int, enabled: bool, threshold_satoshi: int = 100000) -> bool:
        """Enable/disable automatic payouts and set the trigger threshold."""
        threshold = max(10000, int(threshold_satoshi))
        with self._lock:
            self.get_wallet(user_id)
            self._conn.execute(
                "UPDATE wallet SET auto_payout_enabled = ?, payout_threshold_satoshi = ? "
                "WHERE user_id = ?",
                (1 if enabled else 0, threshold, user_id),
            )
            self._conn.commit()
        return True

    def get_withdrawals(self, user_id: int) -> list:
        """Return the withdrawal/payout ledger for a user."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM withdrawal_requests WHERE user_id = ? "
                "ORDER BY created_at DESC LIMIT 100",
                (user_id,),
            ).fetchall()
            return [dict(r) for r in rows]

    def mark_withdrawal_completed(self, user_id: int, tx_hash: str = ""):
        """Complete the most recent pending withdrawal and stamp payout time."""
        with self._lock:
            row = self._conn.execute(
                "SELECT id FROM withdrawal_requests WHERE user_id = ? AND status = 'pending' "
                "ORDER BY id DESC LIMIT 1",
                (user_id,),
            ).fetchone()
            if row:
                self._conn.execute(
                    "UPDATE withdrawal_requests SET status = 'completed', completed_at = ?, "
                    "tx_hash = ? WHERE id = ?",
                    (time.time(), tx_hash, row["id"]),
                )
            self._conn.execute(
                "UPDATE wallet SET last_payout_at = ? WHERE user_id = ?",
                (time.time(), user_id),
            )
            self._conn.commit()

    def _hash_password(self, password: str) -> str:
        from hashlib import sha256
        return sha256(password.encode()).hexdigest()
